Advanced Oracle Troubleshooting course scripts by Tanel Poder

DON'T JUST RUN THE SCRIPTS HERE WITHOUT CHECKING WHAT THEY DO!
DON'T TEST THESE SCRIPTS IN PRODUCTION!

These scripts are designed to cause trouble, so that they could be troubleshooted.

