
-- Do INSERT SELECT where 1=0 on the script to create the table, then alter COL definitions
-- #############################################################
set heading off
set echo off
set long 9999999
select dbms_metadata.get_ddl('TABLE','AWR_IOWL','SYSTEM') from dual; 

  CREATE TABLE "AWR_IOWL"
   (    
        "INSTNAME"        CHAR(30 BYTE),
        "DB_ID"           CHAR(15 BYTE),
        "HOSTNAME"        CHAR(30 BYTE),
        "ID"              NUMBER,
        "TM"              TIMESTAMP(3),
        "INST"            NUMBER,
        "DUR"             NUMBER,
        "SIORS"           NUMBER,
        "MIORS"           NUMBER,
        "TIORMBS"         NUMBER,
        "SIOWS"           NUMBER,
        "MIOWS"           NUMBER,
        "TIOWMBS"         NUMBER,
        "IOREDO"          NUMBER,
        "REDOSIZESEC"     NUMBER,
        "FLASHCACHE"      NUMBER,
        "CELLPIOB"        NUMBER,
        "CELLPIOBSS"      NUMBER,
        "CELLPIOBPREOFF"  NUMBER,
        "CELLPIOBSI"      NUMBER,
        "CELLIOUNCOMB"    NUMBER,
        "CELLPIOBS"       NUMBER,
        "CELLPIOBSRMAN"   NUMBER
   );
		 
/*		  
-- Create External Table definition
-- #############################################################
	$ sqlldr system/oracle awr_iowl.ctl
	
	-- create the control file definition file with the options below
	options (external_table=generate_only)
	load data
	infile '/home/oracle/dba/awrscripts/stage/iowl-all.csv'
	badfile '/home/oracle/dba/awrscripts/stage/iowl-all.bad'
	discardfile '/home/oracle/dba/awrscripts/stage/iowl-all.discard'
	truncate
	into table awr_iowl
	fields terminated by ','
	trailing nullcols
	(
	        INSTNAME                        ,
	        DB_ID                           ,
	        HOSTNAME                        ,
	        ID                              ,
	        TM   date "MM/DD/YY HH24:MI:SS" ,
	        INST                            ,
	        DUR                             ,
	        SIORS                           ,
	        MIORS                           ,
	        TIORMBS                         ,
	        SIOWS                           ,
	        MIOWS                           ,
	        TIOWMBS                         ,
	        IOREDO                          ,
	        REDOSIZESEC                     ,
	        FLASHCACHE                      ,
	        CELLPIOB                        ,
	        CELLPIOBSS                      ,
	        CELLPIOBPREOFF                  ,
	        CELLPIOBSI                      ,
	        CELLIOUNCOMB                    ,
	        CELLPIOBS                       ,
	        CELLPIOBSRMAN                   
	)
*/
	

-- Create the External table from the generated .log file
-- #############################################################

		
		-- CREATE DIRECTORY statements needed for files
		------------------------------------------------------------------------
		CREATE OR REPLACE DIRECTORY AWR_STAGE_DIR AS '/home/oracle/dba/awrscripts/stage/';
		
		
		-- CREATE TABLE statement for external table:
		------------------------------------------------------------------------
		CREATE TABLE "AWR_IOWL_EXT"
		(
		  "INSTNAME" CHAR(30 BYTE),
		  "DB_ID" CHAR(15 BYTE),
		  "HOSTNAME" CHAR(30 BYTE),
		  "ID" NUMBER,
		  "TM" TIMESTAMP(3),
		  "INST" NUMBER,
		  "DUR" NUMBER,
		  "SIORS" NUMBER,
		  "MIORS" NUMBER,
		  "TIORMBS" NUMBER,
		  "SIOWS" NUMBER,
		  "MIOWS" NUMBER,
		  "TIOWMBS" NUMBER,
		  "IOREDO" NUMBER,
		  "REDOSIZESEC" NUMBER,
		  "FLASHCACHE" NUMBER,
		  "CELLPIOB" NUMBER,
		  "CELLPIOBSS" NUMBER,
		  "CELLPIOBPREOFF" NUMBER,
		  "CELLPIOBSI" NUMBER,
		  "CELLIOUNCOMB" NUMBER,
		  "CELLPIOBS" NUMBER,
		  "CELLPIOBSRMAN" NUMBER
		)
		ORGANIZATION external
		(
		  TYPE oracle_loader
		  DEFAULT DIRECTORY AWR_STAGE_DIR
		  ACCESS PARAMETERS
		  (
		    RECORDS DELIMITED BY NEWLINE CHARACTERSET US7ASCII
		    BADFILE 'AWR_STAGE_DIR':'iowl-all.bad'
		    DISCARDFILE 'AWR_STAGE_DIR':'iowl-all.discard'
		    LOGFILE 'AWR_STAGE_DIR':'iowl-all.log_xt'
		    READSIZE 1048576
		    FIELDS TERMINATED BY "," LDRTRIM
		    MISSING FIELD VALUES ARE NULL
		    REJECT ROWS WITH ALL NULL FIELDS
		    (
		      "INSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "DB_ID" CHAR(255)
		        TERMINATED BY ",",
		      "HOSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "ID" CHAR(255)
		        TERMINATED BY ",",
		      "TM" CHAR(255)
		        TERMINATED BY ","
		        DATE_FORMAT DATE MASK "MM/DD/YY HH24:MI:SS",
		      "INST" CHAR(255)
		        TERMINATED BY ",",
		      "DUR" CHAR(255)
		        TERMINATED BY ",",
		      "SIORS" CHAR(255)
		        TERMINATED BY ",",
		      "MIORS" CHAR(255)
		        TERMINATED BY ",",
		      "TIORMBS" CHAR(255)
		        TERMINATED BY ",",
		      "SIOWS" CHAR(255)
		        TERMINATED BY ",",
		      "MIOWS" CHAR(255)
		        TERMINATED BY ",",
		      "TIOWMBS" CHAR(255)
		        TERMINATED BY ",",
		      "IOREDO" CHAR(255)
		        TERMINATED BY ",",
		      "REDOSIZESEC" CHAR(255)
		        TERMINATED BY ",",
		      "FLASHCACHE" CHAR(255)
		        TERMINATED BY ",",
		      "CELLPIOB" CHAR(255)
		        TERMINATED BY ",",
		      "CELLPIOBSS" CHAR(255)
		        TERMINATED BY ",",
		      "CELLPIOBPREOFF" CHAR(255)
		        TERMINATED BY ",",
		      "CELLPIOBSI" CHAR(255)
		        TERMINATED BY ",",
		      "CELLIOUNCOMB" CHAR(255)
		        TERMINATED BY ",",
		      "CELLPIOBS" CHAR(255)
		        TERMINATED BY ",",
		      "CELLPIOBSRMAN" CHAR(255)
		        TERMINATED BY ","
		    )
		  )
		  location
		  (
		    'iowl-all.csv'
		  )
		)REJECT LIMIT UNLIMITED;
		

		-- statements to cleanup objects created by previous statements:
		------------------------------------------------------------------------
		/*
		DROP TABLE "AWR_IOWL_EXT";
		DROP DIRECTORY AWR_STAGE_DIR;
		DROP TABLE "AWR_IOWL" purge;
		*/
		
		
-- LOAD data on the staging table
-- #############################################################

		--truncate table AWR_IOWL;
		--select snap_id from AWR_IOWL;
		select count(*) from AWR_IOWL;
		select count(*) from AWR_IOWL_EXT;
		
    insert /*+ append */ into AWR_IOWL
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(SIORS),trim(MIORS),trim(TIORMBS),trim(SIOWS),trim(MIOWS),trim(TIOWMBS),trim(IOREDO),trim(REDOSIZESEC),trim(FLASHCACHE),trim(CELLPIOB),trim(CELLPIOBSS),trim(CELLPIOBPREOFF),trim(CELLPIOBSI),trim(CELLIOUNCOMB),trim(CELLPIOBS),trim(CELLPIOBSRMAN)
    from AWR_IOWL_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(SIORS),trim(MIORS),trim(TIORMBS),trim(SIOWS),trim(MIOWS),trim(TIOWMBS),trim(IOREDO),trim(REDOSIZESEC),trim(FLASHCACHE),trim(CELLPIOB),trim(CELLPIOBSS),trim(CELLPIOBPREOFF),trim(CELLPIOBSI),trim(CELLIOUNCOMB),trim(CELLPIOBS),trim(CELLPIOBSRMAN)
    from AWR_IOWL;
commit;


		set echo on
		select count(*) from AWR_IOWL;
		select count(*) from AWR_IOWL_EXT;
		
				


