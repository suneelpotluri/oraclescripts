create user oracle identified by oracle;
create user oracle2 identified by oracle2;
create user slob identified by slob;
alter user oracle identified by oracle;
alter user oracle2 identified by oracle2;
alter user slob identified by slob;
grant dba to oracle, oracle2, slob;

