set termout on
set echo off
set heading on

ttitle center '############### AWR_TOPEVENTS DIMENSION ###############' skip 2
    select count(*) count_awr_topevents from awr_topevents;
    select count(*) count_awr_topevents_ext from awr_topevents_ext;
    
    select count(*) diff_awr_topevents from
    (select trim(instname) instname, trim(db_id) dbid, trim(hostname) hostname, trim(snap_id) snap_id, trim(tm) tm, trim(inst) inst, trim(dur) dur, trim(event) event, trim(event_rank) event_rank, trim(waits) waits, trim(time) time, trim(avgwt) avgwt, trim(pctdbt) pctdbt, trim(aas) aas, trim(wait_class) wait_class
    from awr_topevents_ext
    minus
    select trim(instname) instname, trim(db_id) dbid, trim(hostname) hostname, trim(snap_id) snap_id, trim(tm) tm, trim(inst) inst, trim(dur) dur, trim(event) event, trim(event_rank) event_rank, trim(waits) waits, trim(time) time, trim(avgwt) avgwt, trim(pctdbt) pctdbt, trim(aas) aas, trim(wait_class) wait_class
    from awr_topevents);
    
    BREAK ON REPORT
    COMPUTE SUM OF count ON REPORT
    select count(*) count, INSTNAME, DB_ID, HOSTNAME, INST from awr_topevents group by  INSTNAME, DB_ID, HOSTNAME, INST;


ttitle center '############### AWR_CPUWL DIMENSION ###############' skip 2
    select count(*) count_awr_cpuwl from awr_cpuwl;
    select count(*) count_awr_cpuwl_ext from awr_cpuwl_ext;
    
    select count(*) diff_awr_cpuwl from
    (select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(CPU),trim(CAP),trim(DBT),trim(DBC),trim(BGC),trim(RMAN),trim(AAS),trim(TOTORA),trim(LOAD),trim(TOTOS),trim(ORACPUPCT),trim(RMANCPUPCT),trim(OSCPUPCT),trim(OSCPUUSR),trim(OSCPUSYS),trim(OSCPUIO)
    from AWR_CPUWL_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(CPU),trim(CAP),trim(DBT),trim(DBC),trim(BGC),trim(RMAN),trim(AAS),trim(TOTORA),trim(LOAD),trim(TOTOS),trim(ORACPUPCT),trim(RMANCPUPCT),trim(OSCPUPCT),trim(OSCPUUSR),trim(OSCPUSYS),trim(OSCPUIO)
    from AWR_CPUWL);
    
    BREAK ON REPORT
    COMPUTE SUM OF count ON REPORT
    select count(*) count, INSTNAME, DB_ID, HOSTNAME, INST from awr_cpuwl group by  INSTNAME, DB_ID, HOSTNAME, INST;

    
ttitle center '############### AWR_SYSSTAT DIMENSION ###############' skip 2
    select count(*) count_awr_sysstat from awr_sysstat;
    select count(*) count_awr_sysstat_ext from awr_sysstat_ext;
    
    select count(*) diff_awr_sysstat from
    (select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(MEMGB),trim(SGAGB),trim(PGAGB),trim(LOGONS),trim(EXS),trim(UCS),trim(UCOMS),trim(URS),trim(LIOS)
    from AWR_SYSSTAT_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(MEMGB),trim(SGAGB),trim(PGAGB),trim(LOGONS),trim(EXS),trim(UCS),trim(UCOMS),trim(URS),trim(LIOS)
    from AWR_SYSSTAT);
    
    BREAK ON REPORT
    COMPUTE SUM OF count ON REPORT
    select count(*) count, INSTNAME, DB_ID, HOSTNAME, INST from awr_sysstat group by  INSTNAME, DB_ID, HOSTNAME, INST;
    
    
ttitle center '############### AWR_TOPSQLX DIMENSION ###############' skip 2
    select count(*) count_awr_topsqlx from awr_topsqlx;
    select count(*) count_awr_topsqlx_ext from awr_topsqlx_ext;
    
    select count(*) diff_awr_topsqlx from
    (select    
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(SNAP_ID),trim(TM),trim(INST),trim(DUR),trim(AAS),trim(ELAP),trim(ELAPEXEC),trim(CPUT),trim(IOWAIT),trim(APPWAIT),trim(CONCURWAIT),trim(CLWAIT),trim(BGET),trim(DSKR),trim(DPATH),trim(ROWP),trim(EXEC),trim(PRSC),trim(PXEXEC),trim(ICBYTES),trim(OFFLOADBYTES),trim(OFFLOADRETURNBYTES),trim(FLASHCACHEREADS),trim(UNCOMPBYTES),trim(TIME_RANK),trim(SQL_ID),trim(PHV),trim(MODULE),trim(SQL_TEXT)
    from AWR_TOPSQLX_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(SNAP_ID),trim(TM),trim(INST),trim(DUR),trim(AAS),trim(ELAP),trim(ELAPEXEC),trim(CPUT),trim(IOWAIT),trim(APPWAIT),trim(CONCURWAIT),trim(CLWAIT),trim(BGET),trim(DSKR),trim(DPATH),trim(ROWP),trim(EXEC),trim(PRSC),trim(PXEXEC),trim(ICBYTES),trim(OFFLOADBYTES),trim(OFFLOADRETURNBYTES),trim(FLASHCACHEREADS),trim(UNCOMPBYTES),trim(TIME_RANK),trim(SQL_ID),trim(PHV),trim(MODULE),trim(SQL_TEXT)
    from AWR_TOPSQLX);
    
    BREAK ON REPORT
    COMPUTE SUM OF count ON REPORT
    select count(*) count, INSTNAME, DB_ID, HOSTNAME, INST from awr_topsqlx group by  INSTNAME, DB_ID, HOSTNAME, INST;

    
ttitle center '############### AWR_IOWL DIMENSION ###############' skip 2
    select count(*) count_awr_iowl from awr_iowl;
    select count(*) count_awr_iowl_ext from awr_iowl_ext;
    
    select count(*) diff_awr_iowl from
    (select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(SIORS),trim(MIORS),trim(TIORMBS),trim(SIOWS),trim(MIOWS),trim(TIOWMBS),trim(IOREDO),trim(REDOSIZESEC),trim(FLASHCACHE),trim(CELLPIOB),trim(CELLPIOBSS),trim(CELLPIOBPREOFF),trim(CELLPIOBSI),trim(CELLIOUNCOMB),trim(CELLPIOBS),trim(CELLPIOBSRMAN)
    from AWR_IOWL_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(SIORS),trim(MIORS),trim(TIORMBS),trim(SIOWS),trim(MIOWS),trim(TIOWMBS),trim(IOREDO),trim(REDOSIZESEC),trim(FLASHCACHE),trim(CELLPIOB),trim(CELLPIOBSS),trim(CELLPIOBPREOFF),trim(CELLPIOBSI),trim(CELLIOUNCOMB),trim(CELLPIOBS),trim(CELLPIOBSRMAN)
    from AWR_IOWL);
    
    BREAK ON REPORT
    COMPUTE SUM OF count ON REPORT
    select count(*) count, INSTNAME, DB_ID, HOSTNAME, INST from awr_iowl group by  INSTNAME, DB_ID, HOSTNAME, INST;

    



