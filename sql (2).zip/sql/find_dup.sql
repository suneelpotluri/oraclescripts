-- find_dup find duplicated rows which correspond to hash collisions
-- Luca May 2012
-- Usage: find_dup table
-- note to be used in conjunction with hash_birthday_sql and hash_birthday_signature scripts

--optionally define SQL1 and SQL2 as in the hash_birthday script if not already defined in sql*plus environment
--define SQL1='...'
--define SQL2='...'

col hashval for a8
col sql_type for 999
col sql_text for a130

define hashtable_name=&1
break on hashval

select hashval, sql_type, decode(sql_type,1,'&SQL1',2,'&SQL2',null) ||sql||';' sql_text
  from &hashtable_name
where hashval in (select hashval from &hashtable_name group by hashval having count(*)>1)
order by hashval;


--also this is possible but seems to use much more temp (beause of sql_text column) which can be an issue for the vary large tables
--select * from (
--  select lower(rawtohex(UTL_RAW.CAST_TO_RAW(hashval))) hashval, sql_type, count(*) over (partition by hashval) num_dup,
--         decode(sql_type,1,'&SQL1',2,'&SQL2',null) ||sql||';' sql_text
--  from &hashtable_name
--) where num_dup>1;
