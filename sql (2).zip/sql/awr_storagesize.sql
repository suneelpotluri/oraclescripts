-- awr_storagesize.sql
-- AWR Storage Forecast Report
-- Karl Arao, Oracle ACE (bit.ly/karlarao), OCP-DBA, RHCE
-- http://karlarao.wordpress.com
--

set feedback off pages 0 term off head on und off trimspool on echo off lines 4000 colsep ','

set arraysize 5000
set termout off
set echo off verify off

COLUMN blocksize NEW_VALUE _blocksize NOPRINT
select distinct block_size blocksize from v$datafile;

COLUMN dbid NEW_VALUE _dbid NOPRINT
select dbid from v$database;

COLUMN name NEW_VALUE _instname NOPRINT
select lower(instance_name) name from v$instance;

COLUMN name NEW_VALUE _hostname NOPRINT
select lower(host_name) name from v$instance;

COLUMN instancenumber NEW_VALUE _instancenumber NOPRINT
select instance_number instancenumber from v$instance;

-- ttitle center 'AWR Storage Forecast Report' skip 2
set pagesize 50000
set linesize 550


-- per day
spool awr_storagesize_summary-tableau-&_instname-&_hostname..csv
  SELECT 
    trim('&_instname') instname, 
    trim('&_dbid') db_id, 
    trim('&_hostname') hostname, 
    a.month,
    used_size_mb ,
    used_size_mb - LAG (used_size_mb,1) OVER (PARTITION BY a.name ORDER BY a.name,a.month) inc_used_size_mb
  FROM
    (SELECT TO_CHAR(sp.begin_interval_time,'MM/DD/YY') month ,
      ts.name ,
      MAX(ROUND((tsu.tablespace_usedsize* dt.block_size )/(1024*1024),2)) used_size_mb
    FROM DBA_HIST_TBSPC_SPACE_USAGE tsu,
      v$tablespace ts ,
      DBA_HIST_SNAPSHOT sp,
      DBA_TABLESPACES dt
    WHERE tsu.tablespace_id    = ts.ts#
    AND tsu.snap_id            = sp.snap_id
    AND ts.name              = dt.tablespace_name
    GROUP BY TO_CHAR(sp.begin_interval_time,'MM/DD/YY'),
      ts.name
    ORDER BY 
      month
    ) A;
spool off
host sed -n -i '2,$ p' awr_storagesize_summary-tableau-&_instname-&_hostname..csv


-- detail per snap_id
spool awr_storagesize_detail-tableau-&_instname-&_hostname..csv
select *  from 
(
SELECT 
  trim('&_instname') instname, 
  trim('&_dbid') db_id, 
  trim('&_hostname') hostname, 
  s0.snap_id id,
  TO_CHAR(s0.END_INTERVAL_TIME,'MM/DD/YY HH24:MI:SS') tm,
  ts.ts#, 
  ts.name tsname,
  MAX(ROUND((tsu0.tablespace_maxsize    * dt.block_size )/(1024*1024),2) ) max_size_MB ,
  MAX(ROUND((tsu0.tablespace_size       * dt.block_size )/(1024*1024),2) ) cur_size_MB ,
  MAX(ROUND((tsu0.tablespace_usedsize   * dt.block_size )/(1024*1024),2)) used_size_MB,
  MAX(ROUND(( (tsu1.tablespace_usedsize - tsu0.tablespace_usedsize)  * dt.block_size )/(1024*1024),2)) diff_used_size_MB
FROM 
  dba_hist_snapshot s0,
  dba_hist_snapshot s1,
  DBA_HIST_TBSPC_SPACE_USAGE tsu0,
  DBA_HIST_TBSPC_SPACE_USAGE tsu1,
  v$tablespace ts,
  DBA_TABLESPACES dt
WHERE s1.snap_id        = s0.snap_id + 1
AND tsu0.snap_id        = s0.snap_id
AND tsu1.snap_id        = s0.snap_id + 1
AND tsu0.tablespace_id   = ts.ts#
AND tsu1.tablespace_id   = ts.ts#
AND ts.name             = dt.tablespace_name
GROUP BY s0.snap_id, TO_CHAR(s0.END_INTERVAL_TIME,'MM/DD/YY HH24:MI:SS'), ts.ts#, ts.name
)
where 
tm > to_char(sysdate - 8, 'MM/DD/YY HH24:MI')
ORDER BY id asc;
spool off
host sed -n -i '2,$ p' awr_storagesize_detail-tableau-&_instname-&_hostname..csv



