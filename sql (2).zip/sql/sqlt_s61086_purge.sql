REM Purges statement_id 61086 from local SQLT repository. Just execute "@sqlt_s61086_purge.sql" from sqlplus.
SPO sqlt_s61086_purge.log;
SET SERVEROUT ON;
EXEC SQLTXADMIN.sqlt$a.purge_repository(61086, 61086);
SET SERVEROUT OFF;
SPO OFF;
