
exec dbms_lock.sleep(seconds => 15);

select sample_time, count(sid) from
(
select
     to_char(ash.sample_time,'MM/DD/YY HH24:MI:SS') sample_time,
     ash.session_id sid,
     ash.session_serial# serial#,
     ash.user_id user_id,
     ash.program,
     ash.sql_id,
     ash.sql_plan_hash_value,
     sum(decode(ash.session_state,'ON CPU',1,0))     "CPU",
     sum(decode(ash.session_state,'WAITING',1,0))    -
     sum(decode(ash.session_state,'WAITING',
        decode(wait_class,'User I/O',1, 0 ), 0))    "WAIT" ,
     sum(decode(ash.session_state,'WAITING',
        decode(wait_class,'User I/O',1, 0 ), 0))    "IO" ,
     sum(decode(session_state,'ON CPU',1,1))     "TOTAL"
from v$active_session_history ash
where ash.sample_time > sysdate - 1/(60*24)
group by sample_time, session_id,user_id,session_serial#,program,sql_id,sql_plan_hash_value
order by sum(decode(session_state,'ON CPU',1,1)) desc
)
group by sample_time
order by sample_time
/

exit


