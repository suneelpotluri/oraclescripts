set time on timing on echo on feedback on
spool deletepartion_FILES.log;

alter table DSP_SERVICES.FILES drop partition SYS_P69718;
alter table DSP_SERVICES.FILES drop partition SYS_P69726;
alter table DSP_SERVICES.FILES drop partition SYS_P69768;
alter table DSP_SERVICES.FILES drop partition SYS_P69784;
alter table DSP_SERVICES.FILES drop partition SYS_P69815;
alter table DSP_SERVICES.FILES drop partition SYS_P69873;
alter table DSP_SERVICES.FILES drop partition SYS_P69894;
alter table DSP_SERVICES.FILES drop partition SYS_P69918;
alter table DSP_SERVICES.FILES drop partition SYS_P70057;
alter table DSP_SERVICES.FILES drop partition SYS_P70073;
alter table DSP_SERVICES.FILES drop partition SYS_P70083;
alter table DSP_SERVICES.FILES drop partition SYS_P70139;
alter table DSP_SERVICES.FILES drop partition SYS_P70174;
alter table DSP_SERVICES.FILES drop partition SYS_P70211;
alter table DSP_SERVICES.FILES drop partition SYS_P70238;
alter table DSP_SERVICES.FILES drop partition SYS_P70246;
alter table DSP_SERVICES.FILES drop partition SYS_P70272;
alter table DSP_SERVICES.FILES drop partition SYS_P70293;
alter table DSP_SERVICES.FILES drop partition SYS_P70305;
alter table DSP_SERVICES.FILES drop partition SYS_P70372;

spool off;
exit;
