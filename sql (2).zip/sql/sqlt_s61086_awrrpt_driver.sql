REM $Header: 215187.1 sqlt_s61086_awrrpt_driver.sql 12.1.160429 2017/03/13 abel.macias $
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('-> AWR Reports Driver','L',' drivers');
SPO OFF;
VAR dbid NUMBER;
VAR inst_num NUMBER;
VAR bid NUMBER;
VAR eid NUMBER;
VAR rpt_options NUMBER;
EXEC :rpt_options := 0;
SET ECHO OFF FEED OFF VER OFF SHOW OFF HEA OFF LIN 2000 NEWP NONE PAGES 0 LONG 2000000 LONGC 2000 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF ARRAY 100 NUMF "" SQLP SQL> SUF sql BLO . RECSEP OFF APPI OFF AUTOT OFF;
EXEC :dbid := 3512507542;
EXEC :inst_num := 1;
EXEC :bid := 35418;
EXEC :eid := 35419;
SET TERM ON;
PRO ... generating sqlt_s61086_awrrpt_0001_1_35418_35419.html ...
SET TERM OFF;
SPO sqlt_s61086_awrrpt_0001_1_35418_35419.html;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT column_value FROM TABLE(sqltxadmin.sqlt$a.awr_report_html(:dbid, :inst_num, :bid, :eid, :rpt_options));
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
EXEC :dbid := 3512507542;
EXEC :inst_num := 1;
EXEC :bid := 35419;
EXEC :eid := 35420;
SET TERM ON;
PRO ... generating sqlt_s61086_awrrpt_0002_1_35419_35420.html ...
SET TERM OFF;
SPO sqlt_s61086_awrrpt_0002_1_35419_35420.html;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT column_value FROM TABLE(sqltxadmin.sqlt$a.awr_report_html(:dbid, :inst_num, :bid, :eid, :rpt_options));
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
EXEC :dbid := 3512507542;
EXEC :inst_num := 1;
EXEC :bid := 35424;
EXEC :eid := 35425;
SET TERM ON;
PRO ... generating sqlt_s61086_awrrpt_0003_1_35424_35425.html ...
SET TERM OFF;
SPO sqlt_s61086_awrrpt_0003_1_35424_35425.html;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT column_value FROM TABLE(sqltxadmin.sqlt$a.awr_report_html(:dbid, :inst_num, :bid, :eid, :rpt_options));
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
--
HOS zip -m sqlt_s61086_awrrpt_0003 sqlt_s61086_awrrpt_*.html
--
HOS zip -m sqlt_s61086_driver sqlt_s61086_awrrpt_driver.sql
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('<- AWR Reports Driver','L',' drivers');
SPO OFF;
