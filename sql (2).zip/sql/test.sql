select '########################################################################################################################' from dual;
show con_name
select instance_name from v$instance;
select table_name from user_tables;
select sum(bytes)/1024/1024 MB from user_segments where segment_name = 'IOSATURATIONTOOLKIT';
