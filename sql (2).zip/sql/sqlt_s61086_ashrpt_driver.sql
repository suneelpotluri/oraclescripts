REM $Header: 215187.1 sqlt_s61086_ashrpt_driver.sql 12.1.160429 2017/03/13 abel.macias $
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('-> ASH Reports Driver','L',' drivers');
SPO OFF;
VAR dbid         NUMBER;
VAR inst_num     NUMBER;
VAR btime        VARCHAR2(14);
VAR etime        VARCHAR2(14);
VAR options      NUMBER;
VAR slot_width   NUMBER;
VAR sid          NUMBER;
VAR sql_id       VARCHAR2(13);
VAR wait_class   VARCHAR2(64);
VAR service_hash NUMBER;
VAR module       VARCHAR2(64);
VAR action       VARCHAR2(64);
VAR client_id    VARCHAR2(64);
VAR plsql_entry  VARCHAR2(64);
VAR data_src     NUMBER;
EXEC :dbid := 3512507542;
EXEC :options := 0;
EXEC :slot_width := 0;
EXEC :sid := NULL;
EXEC :sql_id := '43296tc92qx9x';
EXEC :wait_class := NULL;
EXEC :service_hash := NULL;
EXEC :module := NULL;
EXEC :action := NULL;
EXEC :client_id := NULL;
EXEC :plsql_entry := NULL;
SET ECHO OFF FEED OFF VER OFF SHOW OFF HEA OFF LIN 2000 NEWP NONE PAGES 0 LONG 2000000 LONGC 2000 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF ARRAY 100 NUMF "" SQLP SQL> SUF sql BLO . RECSEP OFF APPI OFF AUTOT OFF;
EXEC :data_src := 1;
EXEC :data_src := 2;
EXEC :inst_num := 1;
EXEC :btime := '20170313230009';
EXEC :etime := '20170313231917';
SET TERM ON;
PRO ... generating sqlt_s61086_ashrpt_0001_awr_1_0313_2319.html ...
SET TERM OFF;
SPO sqlt_s61086_ashrpt_0001_awr_1_0313_2319.html;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT column_value FROM TABLE(sqltxadmin.sqlt$a.ash_report_html_11(:dbid, :inst_num, TO_DATE(:btime, 'YYYYMMDDHH24MISS'), TO_DATE(:etime, 'YYYYMMDDHH24MISS'), :options, :slot_width, :sid, :sql_id, :wait_class, :service_hash, :module, :action, :client_id, :plsql_entry, :data_src));
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
EXEC :inst_num := 1;
EXEC :btime := '20170313170009';
EXEC :etime := '20170313171337';
SET TERM ON;
PRO ... generating sqlt_s61086_ashrpt_0002_awr_1_0313_1713.html ...
SET TERM OFF;
SPO sqlt_s61086_ashrpt_0002_awr_1_0313_1713.html;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT column_value FROM TABLE(sqltxadmin.sqlt$a.ash_report_html_11(:dbid, :inst_num, TO_DATE(:btime, 'YYYYMMDDHH24MISS'), TO_DATE(:etime, 'YYYYMMDDHH24MISS'), :options, :slot_width, :sid, :sql_id, :wait_class, :service_hash, :module, :action, :client_id, :plsql_entry, :data_src));
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
EXEC :inst_num := 1;
EXEC :btime := '20170313164511';
EXEC :etime := '20170313165959';
SET TERM ON;
PRO ... generating sqlt_s61086_ashrpt_0003_awr_1_0313_1659.html ...
SET TERM OFF;
SPO sqlt_s61086_ashrpt_0003_awr_1_0313_1659.html;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT column_value FROM TABLE(sqltxadmin.sqlt$a.ash_report_html_11(:dbid, :inst_num, TO_DATE(:btime, 'YYYYMMDDHH24MISS'), TO_DATE(:etime, 'YYYYMMDDHH24MISS'), :options, :slot_width, :sid, :sql_id, :wait_class, :service_hash, :module, :action, :client_id, :plsql_entry, :data_src));
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
EXEC :inst_num := 1;
EXEC :btime := '20170313225407';
EXEC :etime := '20170313225959';
SET TERM ON;
PRO ... generating sqlt_s61086_ashrpt_0004_awr_1_0313_2259.html ...
SET TERM OFF;
SPO sqlt_s61086_ashrpt_0004_awr_1_0313_2259.html;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT column_value FROM TABLE(sqltxadmin.sqlt$a.ash_report_html_11(:dbid, :inst_num, TO_DATE(:btime, 'YYYYMMDDHH24MISS'), TO_DATE(:etime, 'YYYYMMDDHH24MISS'), :options, :slot_width, :sid, :sql_id, :wait_class, :service_hash, :module, :action, :client_id, :plsql_entry, :data_src));
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
--
HOS zip -m sqlt_s61086_ashrpt_0004 sqlt_s61086_ashrpt_*.html
--
HOS zip -m sqlt_s61086_driver sqlt_s61086_ashrpt_driver.sql
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('<- ASH Reports Driver','L',' drivers');
SPO OFF;
