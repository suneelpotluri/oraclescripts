CL SCR;

SPO spmdemo.txt;

SET ECHO ON VER OFF PAGES 2000 LIN 180;

REM create spmdemo user

CONN / AS SYSDBA;

ACC spm_demo_user PROMPT 'SPM Demo User and Password (case sensitive): ';

--DROP USER &&spm_demo_user. CASCADE;

GRANT DBA TO &&spm_demo_user. IDENTIFIED BY &&spm_demo_user.;

REM replicate sh.sales into spmdemo user

CREATE TABLE &&spm_demo_user..sales AS SELECT * FROM sh.sales;

CREATE INDEX &&spm_demo_user..sales_channel ON &&spm_demo_user..sales(channel_id);

CREATE INDEX &&spm_demo_user..sales_promo ON &&spm_demo_user..sales(promo_id);

CREATE INDEX &&spm_demo_user..sales_cust ON &&spm_demo_user..sales(cust_id);

REM gather stats in all columns then histograms on channel_id and promo_id

EXEC DBMS_STATS.GATHER_TABLE_STATS('&&spm_demo_user.', 'sales', -
METHOD_OPT => 'FOR ALL COLUMNS SIZE 1, FOR COLUMNS SIZE 254 channel_id, promo_id');

REM data distribution on channel_id and promo_id

select channel_id, count(*)
from &&spm_demo_user..sales
group by channel_id
order by 2;

select promo_id, count(*)
from &&spm_demo_user..sales
group by promo_id
order by 2;

REM frequency histograms on channel_id and promo_id

select column_name, num_distinct, histogram, num_buckets
from dba_tab_columns
where owner = UPPER('&&spm_demo_user.') and table_name = 'SALES'
order by column_id;

SET ECHO OFF VER ON PAGES 24 LIN 80;

SPO OFF;
