
/* Set variable ccf_owner */

set heading off
set verify off
set define on

select ' ' from dual;

select '</******** java grants ********>' from dual;

define ccf_owner = CCF_ADMIN

begin
dbms_java.grant_permission('&ccf_owner','java.util.PropertyPermission','*','read,write');
dbms_java.grant_permission('&ccf_owner','java.net.SocketPermission','*','connect, resolve');
dbms_java.grant_permission('&ccf_owner', 'java.io.FilePermission', 'c:\\temp\\*', 'read,write,delete'); 
dbms_java.grant_permission('&ccf_owner', 'java.io.FilePermission', 'c:\\temp\\', 'write'); 
dbms_java.grant_permission('&ccf_owner', 'java.io.FilePermission', '//var//tmp//*', 'read,write,delete'); 
dbms_java.grant_permission('&ccf_owner', 'java.io.FilePermission', '//var//tmp//', 'write'); 
dbms_java.grant_permission('&ccf_owner', 'java.io.FilePermission', '/var/tmp/*', 'read,write,delete'); 
dbms_java.grant_permission('&ccf_owner', 'java.io.FilePermission', '/var/tmp/', 'write'); 
commit;
end;
/

-- To remove the password limit that is new in Oracle 11, this will be removed when security is changed
-- in SP.
begin
	execute immediate 'ALTER PROFILE DEFAULT LIMIT FAILED_LOGIN_ATTEMPTS UNLIMITED PASSWORD_LIFE_TIME UNLIMITED';
end;
/

show errors;

select '</******** java grants ********>' from dual;
/

EXIT;
/