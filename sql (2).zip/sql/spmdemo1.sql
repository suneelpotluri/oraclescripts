CL SCR;

SPO spmdemo16.txt;

SET ECHO OFF VER OFF PAGES 2000 LIN 180;

CONN &&spm_demo_user./&&spm_demo_user.

REM flush shared pool

@@flush.sql
@@flush.sql

alter session set events '10507 trace name context forever, level 511';

REM generate plan statistics

ALTER SESSION SET statistics_level = ALL;

REM bind variable declaration

VAR b1 NUMBER;
VAR b2 NUMBER;

EXEC :b1 := 2;
EXEC :b2 := 4;

@binds2.sql


EXEC :b1 := 100000;
EXEC :b2 := 100005;

@binds2.sql


EXEC :b1 := 10000;
EXEC :b2 := 100000;

@binds2.sql

EXEC :b1 := 1;
EXEC :b2 := 200000;

@binds2.sql

EXEC :b1 := 100000;
EXEC :b2 := 100005;

@binds2.sql

EXEC :b1 := 10000;
EXEC :b2 := 100000;

@binds2.sql
@@spmdemo2.sql

SET ECHO OFF VER ON PAGES 24 LIN 80;

SPO OFF;
