-- metric extension extract
-- Karl Arao, Oracle ACE (bit.ly/karlarao), OCP-DBA, RHCE
-- http://karlarao.wordpress.com
--

set feedback off pages 0 term off head on und off trimspool on echo off lines 4000 colsep ','

set arraysize 5000
set termout off
set echo off verify off

COLUMN blocksize NEW_VALUE _blocksize NOPRINT
select distinct block_size blocksize from v$datafile;

COLUMN dbid NEW_VALUE _dbid NOPRINT
select dbid from v$database;

COLUMN name NEW_VALUE _instname NOPRINT
select lower(instance_name) name from v$instance;

COLUMN name NEW_VALUE _hostname NOPRINT
select lower(host_name) name from v$instance;

COLUMN instancenumber NEW_VALUE _instancenumber NOPRINT
select instance_number instancenumber from v$instance;

COL ecr_dbid NEW_V ecr_dbid;
SELECT 'get_dbid', TO_CHAR(dbid) ecr_dbid FROM v$database;
COL ecr_instance_number NEW_V ecr_instance_number;
SELECT 'get_instance_number', TO_CHAR(instance_number) ecr_instance_number FROM v$instance;
COL ecr_min_snap_id NEW_V ecr_min_snap_id;
SELECT 'get_min_snap_id', TO_CHAR(MIN(snap_id)) ecr_min_snap_id 
FROM dba_hist_snapshot WHERE dbid = &&ecr_dbid. 
and to_date(to_char(END_INTERVAL_TIME,'MM/DD/YY HH24:MI:SS'),'MM/DD/YY HH24:MI:SS') > sysdate - 100;

-- ttitle center 'metric extension extract' skip 2
set pagesize 50000
set linesize 550

spool cell_iops_all.csv

select 
TO_CHAR(collection_time,'MM/DD/YY HH24:MI:SS') collection_time,
entity_name,
metric_column_name, 
avg_value
from 
sysman.gc$metric_values_hourly 
where metric_group_name = 'ME$CELLSRV_IOPS_ALL'
and key_part_1 = 'CS'
and entity_name like 'x01p%'
order by collection_time asc;         
  
spool off
host sed -n -i '2,$ p' cell_iops_all.csv
host tar -cvf cell_iops_all.tar cell_iops_all.csv

