column	table_owner new_value table_owner
column	table_name new_value table_name

set termout off

select	table_owner, table_name
from	all_synonyms
where	owner = 'PUBLIC'
and	table_name = upper('&1')
union all
select	table_owner, table_name
from	user_synonyms
where	table_name = upper('&1')
union all
select	user, table_name
from	user_tables
where	table_name = upper('&1')
/

set termout on
set pagesize 0
set feedback off

select	decode
	(
		last_analyzed
	,	null
	,	'[31m'||table_name || ' has not been analyzed!!![0m'
	,	table_name || ' last analyzed ' ||
		to_char(last_analyzed, 'DD-MON-YYYY')
	)
from	dba_tables
where	owner = '&table_owner'
and	table_name = '&table_name'
/

select	'[31mPartition ' || partition_name ||
	' of ' || table_name || ' not analyzed![0m'
from	dba_tab_partitions
where	table_owner = '&table_owner'
and	table_name = '&table_name'
and	last_analyzed is null
/

select	decode
	(
		last_analyzed
	,	null
	,	'[31m'||index_name || ' has not been analyzed!!![0m'
	,	index_name || ' last analyzed ' ||
		to_char(last_analyzed, 'DD-MON-YYYY')
	)
from	dba_indexes
where	table_owner = '&table_owner'
and	table_name = '&table_name'
/

select	'[31mPartition ' || partition_name ||
	' of ' || index_name || ' not analyzed![0m'
from	dba_ind_partitions
where	(index_owner, index_name) in (
	select	owner, index_name
	from	dba_indexes
	where	table_owner = '&table_owner'
	and	table_name = '&table_name')
and	last_analyzed is null
/

prompt
column boiler format a30
column val format a30

column num_distinct format a14 justify right
column density format a14
column num_nulls format a18

set pages 50000


select	column_name
,	nvl(to_char(num_distinct), '[31m***[0m') num_distinct
,	nvl(to_char(density,'FM9999.999999'), '[31mNOT[0m') density
,	nvl(to_char(num_nulls), '[31mANALYZED[0m') num_nulls
from	dba_tab_columns
where	owner = '&table_owner'
and	table_name = '&table_name'
/

prompt


set pages 0

select	'Table:'	boiler, table_name val
,	'# Rows:'	boiler, to_char(NUM_ROWS) val
,	'# Blocks:'	boiler, to_char(BLOCKS) val
,	'# Empty Blocks:'	boiler, to_char(EMPTY_BLOCKS) val
,	'Ave Space:'	boiler, to_char(AVG_SPACE) val
,	'Chain Count:'	boiler, to_char(CHAIN_CNT) val
,	'Sample Size:'	boiler, to_char(SAMPLE_SIZE) val
from	dba_tables
where	owner = '&table_owner'
and	table_name = '&table_name'
and	last_analyzed is not null
/

select	'Index:'	boiler, index_name val
,	'B-tree level:'	boiler,	to_char(blevel) val
,	'Leaf Blocks:'	boiler, to_char(leaf_blocks) val
,	'Distinct Keys:'	boiler, to_char(distinct_keys) val
,	'Leaf blocks/key:'	boiler, to_char(avg_leaf_blocks_per_key) val
,	'Clustering Factor:'	boiler,	to_char(clustering_factor) val
from	dba_indexes
where	table_owner = '&table_owner'
and	table_name = '&table_name'
and	last_analyzed is not null
/

clear col
clear break
set pagesize 24
set feedback on
