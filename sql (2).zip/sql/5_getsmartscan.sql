
col start_mb new_value start_mb
col end_mb new_value end_mb
col instance_name new_value instname
COLUMN container NEW_VALUE _container
select SYS_CONTEXT('USERENV', 'CON_NAME') container FROM DUAL;
COLUMN usern NEW_VALUE _usern
select SYS_CONTEXT('USERENV', 'CURRENT_USER') usern FROM DUAL;

set echo off
set heading off
select instance_name from v$instance;

select a.value/1024/1024 start_mb from v$sysstat a
where name = 'cell physical IO bytes eligible for predicate offload';

COLUMN dur NEW_VALUE _dur NOPRINT
SELECT 2 dur from dual;
exec dbms_lock.sleep(seconds => &_dur);

select a.value/1024/1024 end_mb from v$sysstat a
where name = 'cell physical IO bytes eligible for predicate offload';


set heading on
set verify off
set lines 300
set colsep ','
col instname format a10
col container format a10
col MBs format 99999990
select a.*, rpad(' '|| rpad ('@',round(a.mbs/200,0), '@'),70,' ') "IO_GRAPH"
from (select '%' x, '&&instname' instname, '&&_container' container, '&&_usern' usern, TO_CHAR(SYSDATE,'MM/DD/YY HH24:MI:SS') tm, (&&end_mb - &&start_mb) / &_dur  MBs from dual) a;

