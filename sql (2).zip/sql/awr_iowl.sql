-- awr_iowl.sql
-- AWR IO Workload Report
-- Karl Arao, Oracle ACE (bit.ly/karlarao), OCP-DBA, RHCE
-- http://karlarao.wordpress.com
--
-- NOTE: 
-- 
-- Changes: 
-- 

set feedback off pages 0 term off head on und off trimspool on echo off lines 4000 colsep ','

set arraysize 5000
set termout off
set echo off verify off

COLUMN blocksize NEW_VALUE _blocksize NOPRINT
select distinct block_size blocksize from v$datafile;

COLUMN dbid NEW_VALUE _dbid NOPRINT
select dbid from v$database;

COLUMN name NEW_VALUE _instname NOPRINT
select lower(instance_name) name from v$instance;

COLUMN name NEW_VALUE _hostname NOPRINT
select lower(host_name) name from v$instance;

COLUMN instancenumber NEW_VALUE _instancenumber NOPRINT
select instance_number instancenumber from v$instance;

-- ttitle center 'AWR IO Workload Report' skip 2
set pagesize 50000
set linesize 550

col instname       format a15              heading instname            -- instname
col hostname       format a30              heading hostname            -- hostname
col tm             format a17              heading tm                  -- "tm"
col id             format 99999            heading id                  -- "snapid"
col inst           format 90               heading inst                -- "inst"
col dur            format 999990.00        heading dur                 -- "dur"
col cpu            format 90               heading cpu                 -- "cpu"
col cap            format 9999990.00       heading cap                 -- "capacity"
col dbt            format 999990.00        heading dbt                 -- "DBTime"
col dbc            format 99990.00         heading dbc                 -- "DBcpu"
col bgc            format 99990.00         heading bgc                 -- "BGcpu"
col rman           format 9990.00          heading rman                -- "RMANcpu"
col aas            format 990.0            heading aas                 -- "AAS"
col totora         format 9999990.00       heading totora              -- "TotalOracleCPU"
col busy           format 9999990.00       heading busy                -- "BusyTime"
col load           format 990.00           heading load                -- "OSLoad"
col totos          format 9999990.00       heading totos               -- "TotalOSCPU"
col mem            format 999990.00        heading mem                 -- "PhysicalMemorymb"
col IORs           format 99990.000        heading IORs                -- "IOPsr"
col IOWs           format 99990.000        heading IOWs                -- "IOPsw"
col IORedo         format 99990.000        heading IORedo              -- "IOPsredo"
col IORmbs         format 99990.000        heading IORmbs              -- "IOrmbs"
col IOWmbs         format 99990.000        heading IOWmbs              -- "IOwmbs"
col redosizesec    format 99990.000        heading redosizesec         -- "Redombs"
col logons         format 990              heading logons              -- "Sess"
col logone         format 990              heading logone              -- "SessEnd"
col exsraw         format 99990.000        heading exsraw              -- "Execrawdelta"
col exs            format 9990.000         heading exs                 -- "Execs"
col oracpupct      format 990              heading oracpupct           -- "OracleCPUPct"
col rmancpupct     format 990              heading rmancpupct          -- "RMANCPUPct"
col oscpupct       format 990              heading oscpupct            -- "OSCPUPct"
col oscpuusr       format 990              heading oscpuusr            -- "USRPct"
col oscpusys       format 990              heading oscpusys            -- "SYSPct"
col oscpuio        format 990              heading oscpuio             -- "IOPct"
col SIORs          format 99990.000        heading SIORs               -- "IOPsSingleBlockr"
col MIORs          format 99990.000        heading MIORs               -- "IOPsMultiBlockr"
col TIORmbs        format 99990.000        heading TIORmbs             -- "Readmbs"
col SIOWs          format 99990.000        heading SIOWs               -- "IOPsSingleBlockw"
col MIOWs          format 99990.000        heading MIOWs               -- "IOPsMultiBlockw"
col TIOWmbs        format 99990.000        heading TIOWmbs             -- "Writembs"
col TIOR           format 99990.000        heading TIOR                -- "TotalIOPsr"
col TIOW           format 99990.000        heading TIOW                -- "TotalIOPsw"
col TIOALL         format 99990.000        heading TIOALL              -- "TotalIOPsALL"
col ALLRmbs        format 99990.000        heading ALLRmbs             -- "TotalReadmbs"
col ALLWmbs        format 99990.000        heading ALLWmbs             -- "TotalWritembs"
col GRANDmbs       format 99990.000        heading GRANDmbs            -- "TotalmbsALL"
col readratio      format 990              heading readratio           -- "ReadRatio"
col writeratio     format 990              heading writeratio          -- "WriteRatio"
col diskiops       format 99990.000        heading diskiops            -- "HWDiskIOPs"
col numdisks       format 99990.000        heading numdisks            -- "HWNumofDisks"
col flashcache     format 990              heading flashcache          -- "FlashCacheHitsPct"
col cellpiob       format 99990.000        heading cellpiob            -- "CellPIOICmbs"
col cellpiobss     format 99990.000        heading cellpiobss          -- "CellPIOICSmartScanmbs"
col cellpiobpreoff format 99990.000        heading cellpiobpreoff      -- "CellPIOpredoffloadmbs"
col cellpiobsi     format 99990.000        heading cellpiobsi          -- "CellPIOstorageindexmbs"
col celliouncomb   format 99990.000        heading celliouncomb        -- "CellIOuncompmbs"
col cellpiobs      format 99990.000        heading cellpiobs           -- "CellPIOsavedfilecreationmbs"
col cellpiobsrman  format 99990.000        heading cellpiobsrman       -- "CellPIOsavedRMANfilerestorembs"

spool awr_iowl-tableau-exa-&_instname-&_hostname..csv
SELECT * FROM
( 
  SELECT trim('&_instname') instname, 
         trim('&_dbid') db_id, 
         trim('&_hostname') hostname, 
         s0.snap_id id,
         TO_CHAR(s0.END_INTERVAL_TIME,'MM/DD/YY HH24:MI:SS') tm,
         s0.instance_number inst,
  round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2) dur,
   (((s20t1.value - s20t0.value) - (s21t1.value - s21t0.value)) / ((round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2))*60)
    ) as SIORs,
   ((s21t1.value - s21t0.value) / ((round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2))*60)
    ) as MIORs,
   (((s23t1.value - s23t0.value) - (s24t1.value - s24t0.value)) / ((round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2))*60)
    ) as SIOWs,
   ((s24t1.value - s24t0.value) / ((round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2))*60)
    ) as MIOWs,
   ((s13t1.value - s13t0.value)  / ((round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2))*60)
    ) as IORedo, 
   (((s14t1.value - s14t0.value)/1024/1024)  / ((round(EXTRACT(DAY FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 1440 
                                  + EXTRACT(HOUR FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) * 60 
                                  + EXTRACT(MINUTE FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) 
                                  + EXTRACT(SECOND FROM s1.END_INTERVAL_TIME - s0.END_INTERVAL_TIME) / 60, 2))*60)
    ) as redosizesec
FROM dba_hist_snapshot s0,
  dba_hist_snapshot s1,
  dba_hist_sysstat s13t0,       -- redo writes, diffed
  dba_hist_sysstat s13t1,
  dba_hist_sysstat s14t0,       -- redo size, diffed
  dba_hist_sysstat s14t1,
  dba_hist_sysstat s20t0,       -- physical read total IO requests, diffed
  dba_hist_sysstat s20t1,
  dba_hist_sysstat s21t0,       -- physical read total multi block requests, diffed
  dba_hist_sysstat s21t1,  
  dba_hist_sysstat s23t0,       -- physical write total IO requests, diffed
  dba_hist_sysstat s23t1,
  dba_hist_sysstat s24t0,       -- physical write total multi block requests, diffed
  dba_hist_sysstat s24t1
WHERE s0.dbid            = &_dbid    -- CHANGE THE DBID HERE!
AND s1.dbid              = s0.dbid
AND s13t0.dbid            = s0.dbid
AND s13t1.dbid            = s0.dbid
AND s14t0.dbid            = s0.dbid
AND s14t1.dbid            = s0.dbid
AND s20t0.dbid            = s0.dbid
AND s20t1.dbid            = s0.dbid
AND s21t0.dbid            = s0.dbid
AND s21t1.dbid            = s0.dbid
AND s23t0.dbid            = s0.dbid
AND s23t1.dbid            = s0.dbid
AND s24t0.dbid            = s0.dbid
AND s24t1.dbid            = s0.dbid
--AND s0.instance_number   = &_instancenumber   -- CHANGE THE INSTANCE_NUMBER HERE!
AND s1.instance_number   = s0.instance_number
AND s13t0.instance_number = s0.instance_number
AND s13t1.instance_number = s0.instance_number
AND s14t0.instance_number = s0.instance_number
AND s14t1.instance_number = s0.instance_number
AND s20t0.instance_number = s0.instance_number
AND s20t1.instance_number = s0.instance_number
AND s21t0.instance_number = s0.instance_number
AND s21t1.instance_number = s0.instance_number
AND s23t0.instance_number = s0.instance_number
AND s23t1.instance_number = s0.instance_number
AND s24t0.instance_number = s0.instance_number
AND s24t1.instance_number = s0.instance_number
AND s1.snap_id            = s0.snap_id + 1
AND s13t0.snap_id         = s0.snap_id
AND s13t1.snap_id         = s0.snap_id + 1
AND s14t0.snap_id         = s0.snap_id
AND s14t1.snap_id         = s0.snap_id + 1
AND s20t0.snap_id         = s0.snap_id
AND s20t1.snap_id         = s0.snap_id + 1
AND s21t0.snap_id         = s0.snap_id
AND s21t1.snap_id         = s0.snap_id + 1
AND s23t0.snap_id         = s0.snap_id
AND s23t1.snap_id         = s0.snap_id + 1
AND s24t0.snap_id         = s0.snap_id
AND s24t1.snap_id         = s0.snap_id + 1
AND s13t0.stat_name       = 'redo writes'
AND s13t1.stat_name       = s13t0.stat_name
AND s14t0.stat_name       = 'redo size'
AND s14t1.stat_name       = s14t0.stat_name
AND s20t0.stat_name       = 'physical read total IO requests'
AND s20t1.stat_name       = s20t0.stat_name
AND s21t0.stat_name       = 'physical read total multi block requests'
AND s21t1.stat_name       = s21t0.stat_name
AND s23t0.stat_name       = 'physical write total IO requests'
AND s23t1.stat_name       = s23t0.stat_name
AND s24t0.stat_name       = 'physical write total multi block requests'
AND s24t1.stat_name       = s24t0.stat_name
)
WHERE 
tm > to_char(sysdate - 8, 'MM/DD/YY HH24:MI')
-- id  in (select snap_id from (select * from r2toolkit.r2_regression_data union all select * from r2toolkit.r2_outlier_data))
-- id in (338)
-- aas > 1
-- oscpuio > 50
-- rmancpupct > 0
-- AND TO_CHAR(s0.END_INTERVAL_TIME,'D') >= 1     -- Day of week: 1=Sunday 7=Saturday
-- AND TO_CHAR(s0.END_INTERVAL_TIME,'D') <= 7
-- AND TO_CHAR(s0.END_INTERVAL_TIME,'HH24MI') >= 0900     -- Hour
-- AND TO_CHAR(s0.END_INTERVAL_TIME,'HH24MI') <= 1800
-- AND s0.END_INTERVAL_TIME >= TO_DATE('2010-jan-17 00:00:00','yyyy-mon-dd hh24:mi:ss')     -- Data range
-- AND s0.END_INTERVAL_TIME <= TO_DATE('2010-aug-22 23:59:59','yyyy-mon-dd hh24:mi:ss')
ORDER BY id ASC;
spool off
host sed -n -i '2,$ p' awr_iowl-tableau-exa-&_instname-&_hostname..csv