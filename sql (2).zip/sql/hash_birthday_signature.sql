-- hash_birthday_signature.sql  runs a simple birthday attack against hash_value or sql_id to find collisions
-- Luca May 2012
-- Usage @hash_birthday_signature tabel_name iterations 
-- Example @hash_birthday_signature hash_1 500000  run a birth attack to find collisions on sql_id (64 bits)
--                                                 Note multiple copies of the script can run concurrently, also in RAC, 
--                                                just use different table names then put all together with a view
-- Prereq: create and/or customize tablespace_name (see below define tbsname)

define hashtable_name=&1
define num_steps=&2
define bytes=8
define tbsname=hashcalc 
define innerloop=10000
define SQL1='SELECT TABLE_NAME FROM USER_TABLES --'
define SQL2='SELECT INDEX_NAME FROM USER_INDEXES --'

drop table &hashtable_name purge;

create table &hashtable_name
  (hashval varchar2(20), sql_type number(2), sql varchar2(500))
tablespace &tbsname;    

create or replace procedure calchash_&hashtable_name
as
  TYPE hashtab is TABLE OF varchar2(200) INDEX BY PLS_INTEGER;
  t_hashval1 hashtab;
  t_hashval2 hashtab;
  t_rndstrng hashtab;
begin
   for i in 1..&num_steps loop
     for j in 1..&innerloop loop
        t_rndstrng(j) := dbms_random.string('X',32);  
        t_hashval1(j):= substr(DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT_STRING =>'&SQL1'||t_rndstrng(j)),17-&bytes,&bytes); -- hash SQL+random all capital letters 
        t_hashval2(j):= substr(DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT_STRING =>'&SQL2'||t_rndstrng(j)),17-&bytes,&bytes);
     end loop;
   FORALL i IN 1..&innerloop    -- bulk insert 
     insert into &hashtable_name values (t_hashval1(i),1,t_rndstrng(i)); 
   FORALL i IN 1..&innerloop 
     insert into &hashtable_name values (t_hashval2(i),2,t_rndstrng(i)); 

   commit write nowait batch; -- commit and proceed with next batch of rows
   end loop; 

end;
/

set timing on
exec calchash_&hashtable_name

