CREATE MATERIALIZED VIEW ICSREAD.FEES_MV3 
TABLESPACE DATA
PCTUSED    0
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          200M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOCACHE
LOGGING
NOCOMPRESS
NOPARALLEL
BUILD DEFERRED
USING INDEX
            TABLESPACE DATA
            PCTFREE    10
            INITRANS   2
            MAXTRANS   255
            STORAGE    (
                        INITIAL          50M
                        NEXT             1M
                        MINEXTENTS       1
                        MAXEXTENTS       UNLIMITED
                        PCTINCREASE      0
                        FREELISTS        1
                        FREELIST GROUPS  1
                        BUFFER_POOL      DEFAULT
                       )
REFRESH FAST ON DEMAND
WITH PRIMARY KEY
AS 
/* Formatted on 1/29/2018 7:08:08 PM (QP5 v5.269.14213.34769) */
SELECT CUSTOMER_ID,
       SEQNO,
       FEE_TYPE,
       AMOUNT,
       REMARK,
       ENTDATE,
       PERIOD,
       USERNAME,
       VALID_FROM,
       BILL_FMT,
       CO_ID,
       AMOUNT_GROSS,
       TMCODE,
       SPCODE,
       SNCODE BILLING_ACCOUNT_ID
  FROM FEES
 WHERE NVL (AMOUNT_GROSS, 0) != 0;


COMMENT ON MATERIALIZED VIEW ICSREAD.FEES_MV3 IS 'SNAPSHOT TABLE FOR SNAPSHOT FEES_MV3';

CREATE UNIQUE INDEX ICSREAD.PKFEES ON ICSREAD.FEES_MV3
(CUSTOMER_ID, SEQNO)
LOGGING
TABLESPACE DATA
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          50M
            NEXT             1M
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;
