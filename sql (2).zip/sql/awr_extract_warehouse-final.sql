def _client="&1"

set feedback off term off head on und off trimspool on echo off lines 4000 colsep ','

spool top_events-allx.csv
select INSTNAME, DB_ID, HOSTNAME, SNAP_ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, EVENT, EVENT_RANK, WAITS, TIME, AVGWT, PCTDBT, AAS, WAIT_CLASS
from awr_topevents_&_client
order by snap_id;
spool off
host sed -n -i '2,$ p' top_events-allx.csv

spool cpuwl-allx.csv
select INSTNAME, DB_ID, HOSTNAME, ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, CPU, CAP, DBT, DBC, BGC, RMAN, AAS, TOTORA, LOAD, TOTOS, ORACPUPCT , RMANCPUPCT, OSCPUPCT, OSCPUUSR, OSCPUSYS, OSCPUIO
from awr_cpuwl_&_client
order by id asc;
spool off
host sed -n -i '2,$ p' cpuwl-allx.csv

spool sysstat-allx.csv
select INSTNAME, DB_ID, HOSTNAME, ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, MEMGB, SGAGB, PGAGB, LOGONS, EXS, UCS, UCOMS, URS, round(((UCOMS + URS)/(DUR*60)),6) as TRX, LIOS
from awr_sysstat_&_client
order by id asc;
spool off
host sed -n -i '2,$ p' sysstat-allx.csv

spool topsqlx-allx.csv
select INSTNAME, DB_ID, HOSTNAME, SNAP_ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, AAS, ELAP, ELAPEXEC, CPUT, IOWAIT, APPWAIT, CONCURWAIT, CLWAIT, BGET, DSKR, DPATH, ROWP, EXEC, PRSC, PXEXEC, ICBYTES, OFFLOADBYTES, OFFLOADRETURNBYTES, FLASHCACHEREADS, UNCOMPBYTES, TIME_RANK, SQL_ID, PHV, MODULE, SQL_TEXT
from awr_topsqlx_&_client
order by snap_id asc;
spool off
host sed -n -i '2,$ p' topsqlx-allx.csv

spool iowl-allx.csv
select INSTNAME, DB_ID, HOSTNAME, ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, SIORS, MIORS, TIORMBS, SIOWS, MIOWS, TIOWMBS, IOREDO, REDOSIZESEC, 
	(SIORs + MIORs) as TIOR,
	(SIOWs + MIOWs + IORedo) as TIOW,
	((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) as TIOALL,
	TIORmbs as ALLRMBS,
	(TIOWmbs + redosizesec) as ALLWMBS,
	((TIORmbs) + (TIOWmbs + redosizesec)) as GRANDMBS,
	((SIORs + MIORs) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 100 as READRATIO,
	((SIOWs + MIOWs + IORedo) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 100 as WRITERATIO,
	( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo))  * ((SIORs + MIORs) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) )
	+ ( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIOWs + MIOWs + IORedo) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 2 ) as DISKIOPS_N,
	( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIORs + MIORs) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) )
	+ ( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIOWs + MIOWs + IORedo) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 3 ) as DISKIOPS_H,
	(( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIORs + MIORs) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) )
	+ ( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIOWs + MIOWs + IORedo) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 2 )) / 180 as NUMDISKS_N,
	(( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIORs + MIORs) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) )
	+ ( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIOWs + MIOWs + IORedo) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 3 )) / 180 as NUMDISKS_H,
	((( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIORs + MIORs) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) )
	+ ( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIOWs + MIOWs + IORedo) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 2 )) / 180) / 12 as NUMCELLS_N,
	((( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIORs + MIORs) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) )
	+ ( ((SIORs + MIORs) + (SIOWs + MIOWs + IORedo)) * ((SIOWs + MIOWs + IORedo) / ( (SIORs + MIORs) + (SIOWs + MIOWs + IORedo) )) * 3 )) / 180) / 12 as NUMCELLS_H,
	FLASHCACHE, CELLPIOB, CELLPIOBSS, CELLPIOBPREOFF, CELLPIOBSI, CELLIOUNCOMB, CELLPIOBS, CELLPIOBSRMAN
from awr_iowl_&_client
order by id asc;
spool off
host sed -n -i '2,$ p' iowl-allx.csv
    
set termout on
set echo on verify on

