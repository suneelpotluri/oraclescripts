-- md5.sql computes md5 hash and rearranges bytes for printing on Linux (Little Endian)
--         compare result with signature hash as in DBMS_SQLTUNE.SQLTEXT_TO_SIGNATURE
-- Luca May 2012
-- Note user need execute on DBMS_OBFUSCATION_TOOLKIT
-- usage @md5 'string'
--          @md5 "'SELECT 1 FROM DUAL'"         
-- calculated

with calc as (
 select lower(rawtohex(UTL_RAW.CAST_TO_RAW(DBMS_OBFUSCATION_TOOLKIT.MD5(INPUT_STRING =>'&1')))) md5hash from dual
 )
select substr(md5hash,7,2)||substr(md5hash,5,2)||substr(md5hash,3,2)||substr(md5hash,1,2)||
       substr(md5hash,15,2)||substr(md5hash,13,2)||substr(md5hash,11,2)||substr(md5hash,9,2)||
       substr(md5hash,23,2)||substr(md5hash,21,2)||substr(md5hash,19,2)||substr(md5hash,17,2)||
       substr(md5hash,31,2)||substr(md5hash,29,2)||substr(md5hash,27,2)||substr(md5hash,25,2) calculated_full_hash
       from calc;

