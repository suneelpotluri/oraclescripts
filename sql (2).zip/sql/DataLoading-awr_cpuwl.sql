
-- Do INSERT SELECT where 1=0 on the script to create the table, then alter COL definitions
-- #############################################################
set heading off
set echo off
set long 9999999
select dbms_metadata.get_ddl('TABLE','AWR_CPUWL','SYSTEM') from dual; 

  CREATE TABLE "AWR_CPUWL"
   (    
        "INSTNAME"      CHAR(30 BYTE),
        "DB_ID"         CHAR(15 BYTE),
        "HOSTNAME"      CHAR(30 BYTE),
        "ID"            NUMBER,
        "TM"            TIMESTAMP(3),
        "INST"          NUMBER,
        "DUR"           NUMBER,
        "CPU"           NUMBER,
        "CAP"           NUMBER,
        "DBT"           NUMBER,
        "DBC"           NUMBER,
        "BGC"           NUMBER,
        "RMAN"          NUMBER,
        "AAS"           NUMBER,
        "TOTORA"        NUMBER,
        "LOAD"          NUMBER,
        "TOTOS"         NUMBER,
        "ORACPUPCT"     NUMBER,
        "RMANCPUPCT"    NUMBER,
        "OSCPUPCT"      NUMBER,
        "OSCPUUSR"      NUMBER,
        "OSCPUSYS"      NUMBER,
        "OSCPUIO"       NUMBER
   );

		 
/*		  
-- Create External Table definition
-- #############################################################
	$ sqlldr system/oracle awr_cpuwl.ctl
	
	-- create the control file definition file with the options below
	options (external_table=generate_only)
	load data
	infile '/home/oracle/dba/awrscripts/stage/cpuwl-all.csv'
	badfile '/home/oracle/dba/awrscripts/stage/cpuwl-all.bad'
	discardfile '/home/oracle/dba/awrscripts/stage/cpuwl-all.discard'
	truncate
	into table AWR_CPUWL
	fields terminated by ','
	trailing nullcols
	(
        "INSTNAME"                        ,
        "DB_ID"                           ,
        "HOSTNAME"                        ,
        "ID"                              ,
        "TM"   date "MM/DD/YY HH24:MI:SS" ,
        "INST"                            ,
        "DUR"                             ,
        "CPU"                             ,
        "CAP"                             ,
        "DBT"                             ,
        "DBC"                             ,
        "BGC"                             ,
        "RMAN"                            ,
        "AAS"                             ,
        "TOTORA"                          ,
        "LOAD"                            ,
        "TOTOS"                           ,
        "ORACPUPCT"                       ,
        "RMANCPUPCT"                      ,
        "OSCPUPCT"                        ,
        "OSCPUUSR"                        ,
        "OSCPUSYS"                        ,
        "OSCPUIO"                         
	)
*/
	

-- Create the External table from the generated .log file
-- #############################################################

		
		-- CREATE DIRECTORY statements needed for files
		------------------------------------------------------------------------
		CREATE OR REPLACE DIRECTORY AWR_STAGE_DIR AS '/home/oracle/dba/awrscripts/stage/';
		
		
		-- CREATE TABLE statement for external table:
		------------------------------------------------------------------------
		CREATE TABLE "AWR_CPUWL_EXT"
		(
		  "INSTNAME" CHAR(30 BYTE),
		  "DB_ID" CHAR(15 BYTE),
		  "HOSTNAME" CHAR(30 BYTE),
		  "ID" NUMBER,
		  "TM" TIMESTAMP(3),
		  "INST" NUMBER,
		  "DUR" NUMBER,
		  "CPU" NUMBER,
		  "CAP" NUMBER,
		  "DBT" NUMBER,
		  "DBC" NUMBER,
		  "BGC" NUMBER,
		  "RMAN" NUMBER,
		  "AAS" NUMBER,
		  "TOTORA" NUMBER,
		  "LOAD" NUMBER,
		  "TOTOS" NUMBER,
		  "ORACPUPCT" NUMBER,
		  "RMANCPUPCT" NUMBER,
		  "OSCPUPCT" NUMBER,
		  "OSCPUUSR" NUMBER,
		  "OSCPUSYS" NUMBER,
		  "OSCPUIO" NUMBER
		)
		ORGANIZATION external
		(
		  TYPE oracle_loader
		  DEFAULT DIRECTORY AWR_STAGE_DIR
		  ACCESS PARAMETERS
		  (
		    RECORDS DELIMITED BY NEWLINE CHARACTERSET US7ASCII
		    BADFILE 'AWR_STAGE_DIR':'cpuwl-all.bad'
		    DISCARDFILE 'AWR_STAGE_DIR':'cpuwl-all.discard'
		    LOGFILE 'AWR_STAGE_DIR':'cpuwl-all.log_xt'
		    READSIZE 1048576
		    FIELDS TERMINATED BY "," LDRTRIM
		    MISSING FIELD VALUES ARE NULL
		    REJECT ROWS WITH ALL NULL FIELDS
		    (
		      "INSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "DB_ID" CHAR(255)
		        TERMINATED BY ",",
		      "HOSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "ID" CHAR(255)
		        TERMINATED BY ",",
		      "TM" CHAR(255)
		        TERMINATED BY ","
		        DATE_FORMAT DATE MASK "MM/DD/YY HH24:MI:SS",
		      "INST" CHAR(255)
		        TERMINATED BY ",",
		      "DUR" CHAR(255)
		        TERMINATED BY ",",
		      "CPU" CHAR(255)
		        TERMINATED BY ",",
		      "CAP" CHAR(255)
		        TERMINATED BY ",",
		      "DBT" CHAR(255)
		        TERMINATED BY ",",
		      "DBC" CHAR(255)
		        TERMINATED BY ",",
		      "BGC" CHAR(255)
		        TERMINATED BY ",",
		      "RMAN" CHAR(255)
		        TERMINATED BY ",",
		      "AAS" CHAR(255)
		        TERMINATED BY ",",
		      "TOTORA" CHAR(255)
		        TERMINATED BY ",",
		      "LOAD" CHAR(255)
		        TERMINATED BY ",",
		      "TOTOS" CHAR(255)
		        TERMINATED BY ",",
		      "ORACPUPCT" CHAR(255)
		        TERMINATED BY ",",
		      "RMANCPUPCT" CHAR(255)
		        TERMINATED BY ",",
		      "OSCPUPCT" CHAR(255)
		        TERMINATED BY ",",
		      "OSCPUUSR" CHAR(255)
		        TERMINATED BY ",",
		      "OSCPUSYS" CHAR(255)
		        TERMINATED BY ",",
		      "OSCPUIO" CHAR(255)
		        TERMINATED BY ","
		    )
		  )
		  location
		  (
		    'cpuwl-all.csv'
		  )
		)REJECT LIMIT UNLIMITED;
		

		-- statements to cleanup objects created by previous statements:
		------------------------------------------------------------------------
		/*
		DROP TABLE "AWR_CPUWL_EXT";
		DROP DIRECTORY AWR_STAGE_DIR;
		DROP TABLE "AWR_CPUWL" purge;
		*/				

		
-- LOAD data on the staging table
-- #############################################################

		--truncate table AWR_CPUWL;
		--select snap_id from AWR_CPUWL;
		select count(*) from AWR_CPUWL;
		select count(*) from AWR_CPUWL_EXT;
		
    insert /*+ append */ into AWR_CPUWL
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(CPU),trim(CAP),trim(DBT),trim(DBC),trim(BGC),trim(RMAN),trim(AAS),trim(TOTORA),trim(LOAD),trim(TOTOS),trim(ORACPUPCT),trim(RMANCPUPCT),trim(OSCPUPCT),trim(OSCPUUSR),trim(OSCPUSYS),trim(OSCPUIO)
    from AWR_CPUWL_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(CPU),trim(CAP),trim(DBT),trim(DBC),trim(BGC),trim(RMAN),trim(AAS),trim(TOTORA),trim(LOAD),trim(TOTOS),trim(ORACPUPCT),trim(RMANCPUPCT),trim(OSCPUPCT),trim(OSCPUUSR),trim(OSCPUSYS),trim(OSCPUIO)
    from AWR_CPUWL;
commit;
		
		set echo on
		select count(*) from AWR_CPUWL;
		select count(*) from AWR_CPUWL_EXT;
		
		


