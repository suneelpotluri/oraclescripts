BREAK ON REPORT
COMPUTE SUM OF usme ON REPORT
COMPUTE SUM OF alme ON REPORT 
COMPUTE SUM OF frme ON REPORT
COMPUTE SUM OF mame ON REPORT 
COLUMN alme     HEADING "Alloc MB" FORMAT 99999
COLUMN usme     HEADING "Used MB"      FORMAT 99999
COLUMN frme     HEADING "Freeable MB"  FORMAT 99999
COLUMN mame     HEADING "Max MB"       FORMAT 99999
COLUMN username                        FORMAT a10
COLUMN program                         FORMAT a22
COLUMN sid                             FORMAT a5
COLUMN spid                            FORMAT a8
col inst format 99
set pages 3000
SET LINESIZE 3000
set echo on
set feedback on
alter session set nls_date_format='MM/DD/YY HH24:MI:SS'; 

SELECT s.sql_id, 
       ROUND(pga_used_mem/1024/1024) usme,
       ROUND(pga_alloc_mem/1024/1024) alme,
       ROUND(pga_freeable_mem/1024/1024) frme,
       ROUND(pga_max_mem/1024/1024) mame,
       sysdate, s.username, SUBSTR(s.sid,1,5) sid, p.spid, logon_time,
       SUBSTR(s.program,1,22) program , s.process pid_remote,
       decode(a.IO_CELL_OFFLOAD_ELIGIBLE_BYTES,0,'No','Yes') Offload, 
       s.inst_id inst
FROM  gv$session s,gv$process p, gv$sql a
WHERE s.paddr=p.addr
and s.sql_id=a.sql_id
and s.inst_id = p.inst_id
and s.inst_id = a.inst_id
ORDER BY pga_max_mem, logon_time;

exit
