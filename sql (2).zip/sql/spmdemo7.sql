col sql_handle new_v sql_handle
col plan_name new_v plan_name

select sql_text, sql_handle, plan_name, enabled, accepted from dba_sql_plan_baselines where sql_text like '%BIND_AWARE%' order by last_modified desc;

var disabled_plans number;
 
PAU

exec :disabled_plans := dbms_spm.alter_sql_plan_baseline('&sql_handle',attribute_name => 'enabled', attribute_value => 'yes');

select sql_text, sql_handle, plan_name, enabled, accepted from dba_sql_plan_baselines where sql_text like '%BIND_AWARE%';
