REM Deletes CBO histograms from data dictionary for TC schema. Just execute "@sqlt_s61086_del_hgrm.sql" from sqlplus.
SPO sqlt_s61086_del_hgrm.log;
SET SERVEROUT ON;
EXEC SQLTXADMIN.sqlt$s.delete_schema_hgrm('&&tc_user.',TRUE,TRUE);
SET SERVEROUT OFF;
SPO OFF;
