create or replace view hash_all as 
select * from hash_01
union all
select * from hash_02
union all
select * from hash_03
union all
select * from hash_04
union all
select * from hash_05
union all
select * from hash_06
union all
select * from hash_07
union all
select * from hash_08
union all
select * from hash_09
union all
select * from hash_10
union all
select * from hash_11
union all
select * from hash_12
union all
select * from hash_13
union all
select * from hash_14
union all
select * from hash_15
union all
select * from hash_16
union all
select * from hash_17
union all
select * from hash_18
union all
select * from hash_19
union all
select * from hash_20;