-- run this as...........  while : ; do sqlplus "/ as sysdba" @filestat.sql ; echo "---" ; done
-----------------------------------------------------
-- FIRST SNAP
drop table ioms;
create table ioms as select 
                                      file#
                                      , nvl(b.phyrds,0)   phyrds
                                      , nvl(b.readtim,0)  readtim
                                      , nvl(b.writetim,0) writetim 
                                      , nvl(b.phywrts,0)  phywrts
                                      , nvl(b.phyblkrd,0) phyblkrd
                                      , nvl(b.phyblkwrt,0) phyblkwrt
from v$filestat b;

drop table iomstemp;
create table iomstemp as select 
                                      file#
                                      , nvl(b.phyrds,0)   phyrds
                                      , nvl(b.readtim,0)  readtim
                                      , nvl(b.writetim,0) writetim 
                                      , nvl(b.phywrts,0)  phywrts
                                      , nvl(b.phyblkrd,0) phyblkrd
                                      , nvl(b.phyblkwrt,0) phyblkwrt
from v$tempstat b;
-----------------------------------------------------
-- INTERVAL.. CHANGE THIS TIME VALUE FOR THE SNAP DURATION

COLUMN dur NEW_VALUE _dur NOPRINT
SELECT 5 dur from dual;    

exec dbms_lock.sleep(seconds => &_dur);  

-----------------------------------------------------
-- GET DELTA
define FileName=metrics

COLUMN dbname NEW_VALUE _dbname NOPRINT
SELECT name dbname FROM v$database;

COLUMN spool_time NEW_VALUE _spool_time NOPRINT
SELECT TO_CHAR(SYSDATE,'YYMMDDHH24MISS') spool_time FROM dual;

prompt "RUNNING..."
spool &FileName._&_dbname._&_spool_time..txt

set lines 300
col snap_id     format 99999            heading "Snap|ID"
col tm          format 99999999999999   heading "Snap|Time"
col inst        format 90               heading "i|n|s|t|#"
col dur         format 999990.00        heading "Snap|Dur|(m)"
col tsname      format a20              heading "TS"
col file#       format 990              heading "File#"
col filename    format a60              heading "Filename"
col io_rank     format 90               heading "IO|Rank"
col readtim     format 9999999          heading "Read|Time"
col reads       format 9999999          heading "Reads"
col atpr        format 9990.0           heading "Av|Rd(ms)"
col rps         format 9999999          heading "IOPS|Av|Reads/s"
col bpr         format 990.0            heading "Av|Blks/Rd"
col writetim    format 9999999          heading "Write|Time"
col writes      format 9999999          heading "Writes"
col atpw        format 9990.0           heading "Av|Wt(ms)"
col wps         format 9999999          heading "IOPS|Av|Writes/s"
col bpw         format 990.0            heading "Av|Blks/Wrt"
col waits       format 9999999          heading "Buffer|Waits"
col atpwt       format 990.0            heading "Av Buf|Wt(ms)"
col ios         format 9999999          heading "Total|IO R+W"
col iops        format 9999999          heading "IOPS|Total|R+W"

select 
                                      &_spool_time tm
                                      , f.tablespace_name tsname
                                      , e.file#
                                      , f.file_name filename
                                      , e.readtim  - nvl(i.readtim,0)  readtim
                                      , e.phyrds - i.phyrds                       reads
                                      , decode ((e.phyrds - nvl(i.phyrds, 0)), 0, to_number(NULL), ((e.readtim  - nvl(i.readtim,0)) / (e.phyrds   - nvl(i.phyrds,0)))*10)         atpr
                                      , (e.phyrds - nvl(i.phyrds,0))/ &_dur                rps
                                      , decode ((e.phyrds - nvl(i.phyrds, 0)), 0, to_number(NULL), (e.phyblkrd - nvl(i.phyblkrd,0)) / (e.phyrds   - nvl(i.phyrds,0)) )             bpr
                                      , e.writetim  - nvl(i.writetim,0)                 writetim
                                      , e.phywrts - nvl(i.phywrts,0)                    writes
                                      , decode ((e.phywrts - nvl(i.phywrts, 0)), 0, to_number(NULL), ((e.writetim  - nvl(i.writetim,0)) / (e.phywrts   - nvl(i.phywrts,0)))*10)         atpw
                                      , (e.phywrts - nvl(i.phywrts,0))/ &_dur             wps
                                      , decode ((e.phywrts - nvl(i.phywrts, 0)), 0, to_number(NULL), (e.phyblkwrt - nvl(i.phyblkwrt,0)) / (e.phywrts   - nvl(i.phywrts,0)) )             bpw
                                      , (e.phyrds  - nvl(i.phyrds,0)) + (e.phywrts - nvl(i.phywrts,0))                     ios,
                                     ((e.phyrds  - nvl(i.phyrds,0)) + (e.phywrts - nvl(i.phywrts,0))) / &_dur iops     
from v$filestat e, ioms i, dba_data_files  f
where f.file_id = i.file#
and f.file_id = e.file#
and e.file# = i.file#
union all
select 
                                      &_spool_time tm
                                      , f.tablespace_name tsname
                                      , e.file#
                                      , f.file_name filename
                                      , e.readtim  - nvl(i.readtim,0)  readtim
                                      , e.phyrds - i.phyrds                       reads
                                      , decode ((e.phyrds - nvl(i.phyrds, 0)), 0, to_number(NULL), ((e.readtim  - nvl(i.readtim,0)) / (e.phyrds   - nvl(i.phyrds,0)))*10)         atpr
                                      , (e.phyrds - nvl(i.phyrds,0))/ &_dur                rps
                                      , decode ((e.phyrds - nvl(i.phyrds, 0)), 0, to_number(NULL), (e.phyblkrd - nvl(i.phyblkrd,0)) / (e.phyrds   - nvl(i.phyrds,0)) )             bpr
                                      , e.writetim  - nvl(i.writetim,0)                 writetim
                                      , e.phywrts - nvl(i.phywrts,0)                    writes
                                      , decode ((e.phywrts - nvl(i.phywrts, 0)), 0, to_number(NULL), ((e.writetim  - nvl(i.writetim,0)) / (e.phywrts   - nvl(i.phywrts,0)))*10)         atpw
                                      , (e.phywrts - nvl(i.phywrts,0))/ &_dur             wps
                                      , decode ((e.phywrts - nvl(i.phywrts, 0)), 0, to_number(NULL), (e.phyblkwrt - nvl(i.phyblkwrt,0)) / (e.phywrts   - nvl(i.phywrts,0)) )             bpw
                                      , (e.phyrds  - nvl(i.phyrds,0)) + (e.phywrts - nvl(i.phywrts,0))                     ios,
                                     ((e.phyrds  - nvl(i.phyrds,0)) + (e.phywrts - nvl(i.phywrts,0))) / &_dur iops     
from v$tempstat e, iomstemp i, dba_temp_files  f
where f.file_id = i.file#
and f.file_id = e.file#
and e.file# = i.file#
order by atpr asc;


exit