set timing on
set time on
alter session disable parallel dml;
alter session disable parallel query;
insert /*+ APPEND */ into iosaturationtoolkit select * from iosaturationtoolkit;
commit;

