REM skip test case builder TCB file copy (review log for details)
HOS zip -m sqlt_s61086_driver sqlt_s61086_tcb_driver.sql
