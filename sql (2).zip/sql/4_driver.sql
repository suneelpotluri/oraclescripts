alter session force parallel query parallel 2;

COLUMN name NEW_VALUE _instname
select lower(instance_name) name from v$instance;
COLUMN container NEW_VALUE _container
select SYS_CONTEXT('USERENV', 'CON_NAME') container FROM DUAL;
COLUMN usern NEW_VALUE _usern
select SYS_CONTEXT('USERENV', 'CURRENT_USER') usern FROM DUAL;

col time1 new_value time1
col time2 new_value time2
col total_time new_value total_time
col mb_per_sec new_value mb_per_sec
col start_time new_value start_time

select TO_CHAR(SYSDATE,'MM/DD/YY HH24:MI:SS') start_time from dual;
select to_char(sysdate, 'SSSSS') time1 from dual;
select count(*) from iosaturationtoolkit;
select to_char(sysdate, 'SSSSS') time2 from dual;
select &&time2 - &&time1 total_time from dual;

select (sum(s.bytes)/1024/1024)/(&&time2 - &&time1) mb_per_sec
from sys.dba_segments s
where segment_name='IOSATURATIONTOOLKIT';

set colsep ','
col instname format a10
col container format a10
col mbs format 999990
col benchmark format a10
select a.*, rpad(' '|| rpad ('@',round(a.mbs/200,0), '@'),70,' ') "IO_GRAPH"
from (select 'benchmark' benchmark, trim('&_instname') INSTNAME, trim('&_container') CONTAINER, trim('&_usern') USERN, '&&start_time' "START", TO_CHAR(SYSDATE,'MM/DD/YY HH24:MI:SS') "END", &&total_time elapsed, &&mb_per_sec mbs from dual) a;

undef time1
undef time2

