startup force
