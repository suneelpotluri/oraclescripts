-- read from sql_monitor
-- Luca March 2012

@@monitor_details status='EXECUTING'

