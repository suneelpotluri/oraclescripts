REM sql_id and child number executed

set echo on

COL sql_id NEW_V sql_id;
SELECT prev_sql_id sql_id, prev_child_number child_number
FROM v$session
WHERE sid = SYS_CONTEXT('USERENV', 'SID') AND status = 'ACTIVE';

REM execution plans

COL execution_plan FOR A180
SELECT s.child_number, plan_hash_value,  is_bind_sensitive, is_bind_aware, is_shareable
FROM v$sql s
WHERE s.sql_id = '&&sql_id.';


