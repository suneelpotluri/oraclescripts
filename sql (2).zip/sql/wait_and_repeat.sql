-- wait_and_reapeat.sql
-- this is part of PyLatencyMap package, Luca.Canali@cern.ch Aug 2013
-- service script used to produce the results of a loop execution for SQL and PL/SQL scripts
--
-- usage: @wait_and_reapeat.sql <wait_time_in_sec>
-- Example: @wait_and_repeat 3
--

define wait_time=&1

exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exec dbms_lock.sleep(&wait_time)
/
exit

