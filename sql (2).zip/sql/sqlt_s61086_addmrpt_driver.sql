REM $Header: 215187.1 sqlt_s61086_addmrpt_driver.sql 12.1.160429 2017/03/13 abel.macias $
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('-> ADDM Reports Driver','L',' drivers');
SPO OFF;
VAR dbid NUMBER;
VAR inst_num NUMBER;
VAR bid NUMBER;
VAR eid NUMBER;
VAR task_name VARCHAR2(100);
SET ECHO OFF FEED OFF VER OFF SHOW OFF HEA OFF LIN 2000 NEWP NONE PAGES 0 LONG 2000000 LONGC 2000 SQLC MIX TAB ON TRIMS ON TI OFF TIMI OFF ARRAY 100 NUMF "" SQLP SQL> SUF sql BLO . RECSEP OFF APPI OFF AUTOT OFF;
EXEC :dbid := 3512507542;
EXEC :inst_num := 1;
EXEC :bid := 35418;
EXEC :eid := 35419;
SET TERM ON;
PRO ... generating sqlt_s61086_addmrpt_0001_1_35418_35419.txt ...
SET TERM OFF;
EXEC :task_name := SQLTXADMIN.sqlt$a.dbms_addm_analyze_inst(p_dbid => :dbid, p_inst_num => :inst_num, p_bid => :bid, p_eid => :eid);
SPO sqlt_s61086_addmrpt_0001_1_35418_35419.txt;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT SYS.DBMS_ADVISOR.GET_TASK_REPORT(:task_name, 'TEXT', 'TYPICAL') FROM SYS.DUAL;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
EXEC :dbid := 3512507542;
EXEC :inst_num := 1;
EXEC :bid := 35419;
EXEC :eid := 35420;
SET TERM ON;
PRO ... generating sqlt_s61086_addmrpt_0002_1_35419_35420.txt ...
SET TERM OFF;
EXEC :task_name := SQLTXADMIN.sqlt$a.dbms_addm_analyze_inst(p_dbid => :dbid, p_inst_num => :inst_num, p_bid => :bid, p_eid => :eid);
SPO sqlt_s61086_addmrpt_0002_1_35419_35420.txt;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT SYS.DBMS_ADVISOR.GET_TASK_REPORT(:task_name, 'TEXT', 'TYPICAL') FROM SYS.DUAL;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
EXEC :dbid := 3512507542;
EXEC :inst_num := 1;
EXEC :bid := 35424;
EXEC :eid := 35425;
SET TERM ON;
PRO ... generating sqlt_s61086_addmrpt_0003_1_35424_35425.txt ...
SET TERM OFF;
EXEC :task_name := SQLTXADMIN.sqlt$a.dbms_addm_analyze_inst(p_dbid => :dbid, p_inst_num => :inst_num, p_bid => :bid, p_eid => :eid);
SPO sqlt_s61086_addmrpt_0003_1_35424_35425.txt;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SELECT SYS.DBMS_ADVISOR.GET_TASK_REPORT(:task_name, 'TEXT', 'TYPICAL') FROM SYS.DUAL;
SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
SPO OFF;
--
HOS zip -m sqlt_s61086_addmrpt_0003 sqlt_s61086_addmrpt_*.txt
--
HOS zip -m sqlt_s61086_driver sqlt_s61086_addmrpt_driver.sql
SPO sqltxtract.log APPEND;
EXEC ^^tool_administer_schema..sqlt$a.write_log('<- ADDM Reports Driver','L',' drivers');
SPO OFF;
