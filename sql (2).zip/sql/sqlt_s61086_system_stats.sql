SPO sqlt_s61086_system_stats.log;
SET ECHO ON TERM ON;
REM
REM $Header: 215187.1 sqlt_s61086_system_stats.sql 12.1.160429 2017/03/13 abel.macias $
REM
REM Copyright (c) 2000-2015, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   abel.macias@oracle.com
REM
REM SCRIPT
REM   sqlt_s61086_system_stats.sql
REM
REM SOURCE
REM   Host    : meyicmlvdb2
REM   DB Name : ICMIPR
REM   Platform: Solaris
REM   Product : Oracle Database 11g Enterprise Edition (64bit Production)
REM   Version : 11.2.0.3.0
REM   Language: US:AMERICAN_AMERICA.AL32UTF8
REM   EBS     : NO
REM   Siebel  : NO
REM   PSFT    : NO
REM
REM DESCRIPTION
REM   This script is generated automatically by the SQLT tool.
REM   It contains the SQL*Plus commands to set the CBO System
REM   Statistics as found on meyicmlvdb2
REM   at the time SQL 43296tc92qx9x was analyzed by SQLT.
REM
REM PARAMETERS
REM   None.
REM
REM EXAMPLE
REM   SQL> START sqlt_s61086_system_stats.sql;
REM
REM NOTES
REM   1. Should be run as SYSTEM or SYSDBA.
REM

EXEC SYS.DBMS_STATS.DELETE_SYSTEM_STATS;
EXEC SYS.DBMS_STATS.SET_SYSTEM_STATS('CPUSPEEDNW', 680.062426843543);
EXEC SYS.DBMS_STATS.SET_SYSTEM_STATS('IOSEEKTIM', 10);
EXEC SYS.DBMS_STATS.SET_SYSTEM_STATS('IOTFRSPEED', 4096);
REM Remember IO Calibrate needs an instance restart
DELETE SYS.RESOURCE_IO_CALIBRATE$;
INSERT INTO SYS.RESOURCE_IO_CALIBRATE$(START_TIME,END_TIME,MAX_IOPS,MAX_MBPS,MAX_PMBPS,LATENCY,NUM_DISKS) VALUES (SYSTIMESTAMP,SYSTIMESTAMP,9018,1502,123,7,746);

SPO OFF;
