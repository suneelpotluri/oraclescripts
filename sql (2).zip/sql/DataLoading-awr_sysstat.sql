
-- Do INSERT SELECT where 1=0 on the script to create the table, then alter COL definitions
-- #############################################################
set heading off
set echo off
set long 9999999
select dbms_metadata.get_ddl('TABLE','AWR_SYSSTAT','SYSTEM') from dual; 

  CREATE TABLE "AWR_SYSSTAT"
   (    
        "INSTNAME"      CHAR(30 BYTE),
        "DB_ID"         CHAR(15 BYTE),
        "HOSTNAME"      CHAR(30 BYTE),
        "ID"            NUMBER,
        "TM"            TIMESTAMP(3),
        "INST"          NUMBER,
        "DUR"           NUMBER,
        "MEMGB"         NUMBER,
        "SGAGB"         NUMBER,
        "PGAGB"         NUMBER,
        "LOGONS"        NUMBER,
        "EXS"           NUMBER,
        "UCS"           NUMBER,
        "UCOMS"         NUMBER,
        "URS"           NUMBER,
        "LIOS"          NUMBER
   );

		 
/*		  
-- Create External Table definition
-- #############################################################
	$ sqlldr system/oracle awr_sysstat.ctl
	
	-- create the control file definition file with the options below
	options (external_table=generate_only)
	load data
	infile '/home/oracle/dba/awrscripts/stage/sysstat-all.csv'
	badfile '/home/oracle/dba/awrscripts/stage/sysstat-all.bad'
	discardfile '/home/oracle/dba/awrscripts/stage/sysstat-all.discard'
	truncate
	into table AWR_SYSSTAT
	fields terminated by ','
	trailing nullcols
	(       
        "INSTNAME"                        ,
        "DB_ID"                           ,
        "HOSTNAME"                        ,
        "ID"                              ,
        "TM"   date "MM/DD/YY HH24:MI:SS" ,
        "INST"                            ,
        "DUR"                             ,
        "MEMGB"                           ,
        "SGAGB"                           ,
        "PGAGB"                           ,
        "LOGONS"                          ,
        "EXS"                             ,
        "UCS"                             ,
        "UCOMS"                           ,
        "URS"                             ,
        "LIOS"                            
	)
*/
	

-- Create the External table from the generated .log file
-- #############################################################

		
		-- CREATE DIRECTORY statements needed for files
		------------------------------------------------------------------------
		CREATE OR REPLACE DIRECTORY AWR_STAGE_DIR AS '/home/oracle/dba/awrscripts/stage/';
		
		
		-- CREATE TABLE statement for external table:
		------------------------------------------------------------------------
        CREATE TABLE "AWR_SYSSTAT_EXT"
        (
          "INSTNAME" CHAR(30),
          "DB_ID" CHAR(15),
          "HOSTNAME" CHAR(30),
          "ID" NUMBER,
          "TM" TIMESTAMP(3),
          "INST" NUMBER,
          "DUR" NUMBER,
          "MEMGB" NUMBER,
          "SGAGB" NUMBER,
          "PGAGB" NUMBER,
          "LOGONS" NUMBER,
          "EXS" NUMBER,
          "UCS" NUMBER,
          "UCOMS" NUMBER,
          "URS" NUMBER,
          "LIOS" NUMBER
        )
        ORGANIZATION external
        (
          TYPE oracle_loader
          DEFAULT DIRECTORY AWR_STAGE_DIR
          ACCESS PARAMETERS
          (
            RECORDS DELIMITED BY NEWLINE CHARACTERSET US7ASCII
            BADFILE 'AWR_STAGE_DIR':'sysstat-all.bad'
            DISCARDFILE 'AWR_STAGE_DIR':'sysstat-all.discard'
            LOGFILE 'AWR_STAGE_DIR':'awr_sysstat.log_xt'
            READSIZE 1048576
            FIELDS TERMINATED BY "," LDRTRIM
            MISSING FIELD VALUES ARE NULL
            REJECT ROWS WITH ALL NULL FIELDS
            (
              "INSTNAME" CHAR(255)
                TERMINATED BY ",",
              "DB_ID" CHAR(255)
                TERMINATED BY ",",
              "HOSTNAME" CHAR(255)
                TERMINATED BY ",",
              "ID" CHAR(255)
                TERMINATED BY ",",
              "TM" CHAR(255)
                TERMINATED BY ","
                DATE_FORMAT DATE MASK "MM/DD/YY HH24:MI:SS",
              "INST" CHAR(255)
                TERMINATED BY ",",
              "DUR" CHAR(255)
                TERMINATED BY ",",
              "MEMGB" CHAR(255)
                TERMINATED BY ",",
              "SGAGB" CHAR(255)
                TERMINATED BY ",",
              "PGAGB" CHAR(255)
                TERMINATED BY ",",
              "LOGONS" CHAR(255)
                TERMINATED BY ",",
              "EXS" CHAR(255)
                TERMINATED BY ",",
              "UCS" CHAR(255)
                TERMINATED BY ",",
              "UCOMS" CHAR(255)
                TERMINATED BY ",",
              "URS" CHAR(255)
                TERMINATED BY ",",
              "LIOS" CHAR(255)
                TERMINATED BY ","
            )
          )
          location
          (
            'sysstat-all.csv'
          )
        )REJECT LIMIT UNLIMITED;
		

		-- statements to cleanup objects created by previous statements:
		------------------------------------------------------------------------
		/*
		DROP TABLE "AWR_SYSSTAT_EXT";
		DROP DIRECTORY AWR_STAGE_DIR;
		DROP TABLE "AWR_SYSSTAT" purge;
		*/				

		
-- LOAD data on the staging table
-- #############################################################

		--truncate table AWR_SYSSTAT;
		--select snap_id from AWR_SYSSTAT;
		select count(*) from AWR_SYSSTAT;
		select count(*) from AWR_SYSSTAT_EXT;
		
    insert /*+ append */ into AWR_SYSSTAT
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(MEMGB),trim(SGAGB),trim(PGAGB),trim(LOGONS),trim(EXS),trim(UCS),trim(UCOMS),trim(URS),trim(LIOS)
    from AWR_SYSSTAT_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(ID),trim(TM),trim(INST),trim(DUR),trim(MEMGB),trim(SGAGB),trim(PGAGB),trim(LOGONS),trim(EXS),trim(UCS),trim(UCOMS),trim(URS),trim(LIOS)
    from AWR_SYSSTAT;
commit;
		
		set echo on
		select count(*) from AWR_SYSSTAT;
		select count(*) from AWR_SYSSTAT_EXT;
		
		


