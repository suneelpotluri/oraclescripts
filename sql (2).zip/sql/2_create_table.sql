create bigfile tablespace ts_iosaturationtoolkit;
create table iosaturationtoolkit tablespace ts_iosaturationtoolkit parallel nologging as select * from sys.dba_objects where rownum <= 10000;
commit;

