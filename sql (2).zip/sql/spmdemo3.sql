
REM Loading just the first execution plan for the SQL


var loaded_plans number;
col plan_hash_value new_v plan_hash_value;
select sql_id, plan_hash_Value
  from v$sql
 where sql_id = '&sql_id'
   and child_number = 0;

exec :loaded_plans := dbms_spm.load_plans_from_cursor_cache('&sql_id',&plan_hash_value);

print loaded_plans
