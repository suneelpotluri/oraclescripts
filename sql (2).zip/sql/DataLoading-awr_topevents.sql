
-- Do INSERT SELECT where 1=0 on the script to create the table, then alter COL definitions
-- #############################################################
set heading off
set echo off
set long 9999999
select dbms_metadata.get_ddl('TABLE','AWR_TOPEVENTS','SYSTEM') from dual; 

		CREATE TABLE "AWR_TOPEVENTS"
		  (
		    "INSTNAME"   CHAR(30 BYTE),
		    "DB_ID"      CHAR(15 BYTE),
		    "HOSTNAME"   CHAR(30 BYTE),
		    "SNAP_ID"    NUMBER,
		    "TM"         TIMESTAMP(3),
		    "INST"       NUMBER,
		    "DUR"        NUMBER,
		    "EVENT"      VARCHAR2(64 BYTE),
		    "EVENT_RANK" NUMBER,
		    "WAITS"      NUMBER,
		    "TIME"       NUMBER,
		    "AVGWT"      NUMBER,
		    "PCTDBT"     NUMBER,
		    "AAS"        NUMBER,
		    "WAIT_CLASS" VARCHAR2(30 BYTE)
		  );
		 
/*  
	-- Create External Table definition
	-- #############################################################
	$ sqlldr system/oracle awr_topevents.ctl
	
	-- create the control file definition file with the options below
	options (external_table=generate_only)
	load data
	infile '/home/oracle/dba/awrscripts/stage/top_events-all.csv'
	badfile '/home/oracle/dba/awrscripts/stage/top_events-all.bad'
	discardfile '/home/oracle/dba/awrscripts/stage/top_events-all.discard'
	truncate
	into table awr_topevents
	fields terminated by ','
	trailing nullcols
	(
	    INSTNAME                        ,
	    DB_ID                           ,
	    HOSTNAME                        ,
	    SNAP_ID                         ,
	    TM   date "MM/DD/YY HH24:MI:SS" ,
	    INST                            ,
	    DUR                             ,
	    EVENT                           ,
	    EVENT_RANK                      ,
	    WAITS                           ,
	    TIME                            ,
	    AVGWT                           ,
	    PCTDBT                          ,
	    AAS                             ,
	    WAIT_CLASS                   
	)
*/


-- Create the External table from the generated .log file
-- #############################################################

		
		-- CREATE DIRECTORY statements needed for files
		------------------------------------------------------------------------
		CREATE OR REPLACE DIRECTORY AWR_STAGE_DIR AS '/home/oracle/dba/awrscripts/stage/';
		
		
		-- CREATE TABLE statement for external table:
		------------------------------------------------------------------------
		CREATE TABLE "AWR_TOPEVENTS_EXT"
		(
		  "INSTNAME" CHAR(30),
		  "DB_ID" CHAR(15),
		  "HOSTNAME" CHAR(30),
		  "SNAP_ID" NUMBER,
		  "TM" TIMESTAMP(3),
		  "INST" NUMBER,
		  "DUR" NUMBER,
		  "EVENT" VARCHAR2(64),
		  "EVENT_RANK" NUMBER,
		  "WAITS" NUMBER,
		  "TIME" NUMBER,
		  "AVGWT" NUMBER,
		  "PCTDBT" NUMBER,
		  "AAS" NUMBER,
		  "WAIT_CLASS" VARCHAR2(30)
		)
		ORGANIZATION external
		(
		  TYPE oracle_loader
		  DEFAULT DIRECTORY AWR_STAGE_DIR
		  ACCESS PARAMETERS
		  (
		    RECORDS DELIMITED BY NEWLINE CHARACTERSET US7ASCII
		    BADFILE 'AWR_STAGE_DIR':'top_events-all.bad'
		    DISCARDFILE 'AWR_STAGE_DIR':'top_events-all.discard'
		    LOGFILE 'AWR_STAGE_DIR':'top_events-all.log_xt'
		    READSIZE 1048576
		    FIELDS TERMINATED BY "," LDRTRIM
		    MISSING FIELD VALUES ARE NULL
		    REJECT ROWS WITH ALL NULL FIELDS
		    (
		      "INSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "DB_ID" CHAR(255)
		        TERMINATED BY ",",
		      "HOSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "SNAP_ID" CHAR(255)
		        TERMINATED BY ",",
		      "TM" CHAR(255)
		        TERMINATED BY ","
		        DATE_FORMAT DATE MASK "MM/DD/YY HH24:MI:SS",
		      "INST" CHAR(255)
		        TERMINATED BY ",",
		      "DUR" CHAR(255)
		        TERMINATED BY ",",
		      "EVENT" CHAR(255)
		        TERMINATED BY ",",
		      "EVENT_RANK" CHAR(255)
		        TERMINATED BY ",",
		      "WAITS" CHAR(255)
		        TERMINATED BY ",",
		      "TIME" CHAR(255)
		        TERMINATED BY ",",
		      "AVGWT" CHAR(255)
		        TERMINATED BY ",",
		      "PCTDBT" CHAR(255)
		        TERMINATED BY ",",
		      "AAS" CHAR(255)
		        TERMINATED BY ",",
		      "WAIT_CLASS" CHAR(255)
		        TERMINATED BY ","
		    )
		  )
		  location
		  (
		    'top_events-all.csv'
		  )
		)REJECT LIMIT UNLIMITED;


		-- statements to cleanup objects created by previous statements:
		------------------------------------------------------------------------
		/*
		DROP TABLE "AWR_TOPEVENTS_EXT";
		DROP DIRECTORY AWR_STAGE_DIR;
		DROP TABLE "AWR_TOPEVENTS" purge;
		*/
		
		
-- LOAD data on the staging table
-- #############################################################

		--truncate table awr_topevents;
		--select snap_id from awr_topevents;
		select count(*) from awr_topevents;
		select count(*) from AWR_TOPEVENTS_EXT;
		
insert /*+ append */ into awr_topevents
select 
trim(instname) instname, trim(db_id) dbid, trim(hostname) hostname, trim(snap_id) snap_id, trim(tm) tm, trim(inst) inst, trim(dur) dur, trim(event) event, trim(event_rank) event_rank, trim(waits) waits, trim(time) time, trim(avgwt) avgwt, trim(pctdbt) pctdbt, trim(aas) aas, trim(wait_class) wait_class
from AWR_TOPEVENTS_EXT
minus
select 
trim(instname) instname, trim(db_id) dbid, trim(hostname) hostname, trim(snap_id) snap_id, trim(tm) tm, trim(inst) inst, trim(dur) dur, trim(event) event, trim(event_rank) event_rank, trim(waits) waits, trim(time) time, trim(avgwt) avgwt, trim(pctdbt) pctdbt, trim(aas) aas, trim(wait_class) wait_class
from awr_topevents;
commit;	
	
		set echo on
		select count(*) from awr_topevents;
		select count(*) from AWR_TOPEVENTS_EXT;

		



