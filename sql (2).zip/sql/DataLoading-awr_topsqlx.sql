
-- Do INSERT SELECT where 1=0 on the script to create the table, then alter COL definitions
-- #############################################################
set heading off
set echo off
set long 9999999
select dbms_metadata.get_ddl('TABLE','AWR_TOPSQLX','SYSTEM') from dual; 

  CREATE TABLE "AWR_TOPSQLX"
   (    "INSTNAME"              CHAR(30 BYTE),
        "DB_ID"                 CHAR(15 BYTE),
        "HOSTNAME"              CHAR(30 BYTE),
        "SNAP_ID"               NUMBER,
        "TM"                    TIMESTAMP(3),
        "INST"                  NUMBER,
        "DUR"                   NUMBER,
        "AAS"                   NUMBER,
        "ELAP"                  NUMBER,
        "ELAPEXEC"              NUMBER,
        "CPUT"                  NUMBER,
        "IOWAIT"                NUMBER,
        "APPWAIT"               NUMBER,
        "CONCURWAIT"            NUMBER,
        "CLWAIT"                NUMBER,
        "BGET"                  NUMBER,
        "DSKR"                  NUMBER,
        "DPATH"                 NUMBER,
        "ROWP"                  NUMBER,
        "EXEC"                  NUMBER,
        "PRSC"                  NUMBER,
        "PXEXEC"                NUMBER,
        "ICBYTES"               NUMBER,
        "OFFLOADBYTES"          NUMBER,
        "OFFLOADRETURNBYTES"    NUMBER,
        "FLASHCACHEREADS"       NUMBER,
        "UNCOMPBYTES"           NUMBER,
        "TIME_RANK"             NUMBER,
        "SQL_ID"                VARCHAR2(30 BYTE),
        "PHV"                   NUMBER,
        "MODULE"                VARCHAR2(64 BYTE),
        "SQL_TEXT"              VARCHAR2(30 BYTE)
   );

		 
/*		  
-- Create External Table definition
-- #############################################################
	$ sqlldr system/oracle awr_topsqlx.ctl
	
	-- create the control file definition file with the options below
	options (external_table=generate_only)
	load data
	infile '/home/oracle/dba/awrscripts/stage/topsqlx-all.csv'
	badfile '/home/oracle/dba/awrscripts/stage/topsqlx-all.bad'
	discardfile '/home/oracle/dba/awrscripts/stage/topsqlx-all.discard'
	truncate
	into table AWR_TOPSQLX
	fields terminated by ','
	trailing nullcols
	(
        "INSTNAME"                        ,
        "DB_ID"                           ,
        "HOSTNAME"                        ,
        "SNAP_ID"                         ,
        "TM"   date "MM/DD/YY HH24:MI:SS" ,
        "INST"                            ,
        "DUR"                             ,
        "AAS"                             ,
        "ELAP"                            ,
        "ELAPEXEC"                        ,
        "CPUT"                            ,
        "IOWAIT"                          ,
        "APPWAIT"                         ,
        "CONCURWAIT"                      ,
        "CLWAIT"                          ,
        "BGET"                            ,
        "DSKR"                            ,
        "DPATH"                           ,
        "ROWP"                            ,
        "EXEC"                            ,
        "PRSC"                            ,
        "PXEXEC"                          ,
        "ICBYTES"                         ,
        "OFFLOADBYTES"                    ,
        "OFFLOADRETURNBYTES"              ,
        "FLASHCACHEREADS"                 ,
        "UNCOMPBYTES"                     ,
        "TIME_RANK"                       ,
        "SQL_ID"                          ,
        "PHV"                             ,
        "MODULE"                          ,
        "SQL_TEXT"                        
	)   
*/
	

-- Create the External table from the generated .log file
-- #############################################################

		
		-- CREATE DIRECTORY statements needed for files
		------------------------------------------------------------------------
		CREATE OR REPLACE DIRECTORY AWR_STAGE_DIR AS '/home/oracle/dba/awrscripts/stage/';
		
		
		-- CREATE TABLE statement for external table:
		------------------------------------------------------------------------
		CREATE TABLE "AWR_TOPSQLX_EXT"
		(
		  "INSTNAME" CHAR(30),
		  "DB_ID" CHAR(15),
		  "HOSTNAME" CHAR(30),
		  "SNAP_ID" NUMBER,
		  "TM" TIMESTAMP(3),
		  "INST" NUMBER,
		  "DUR" NUMBER,
		  "AAS" NUMBER,
		  "ELAP" NUMBER,
		  "ELAPEXEC" NUMBER,
		  "CPUT" NUMBER,
		  "IOWAIT" NUMBER,
		  "APPWAIT" NUMBER,
		  "CONCURWAIT" NUMBER,
		  "CLWAIT" NUMBER,
		  "BGET" NUMBER,
		  "DSKR" NUMBER,
		  "DPATH" NUMBER,
		  "ROWP" NUMBER,
		  "EXEC" NUMBER,
		  "PRSC" NUMBER,
		  "PXEXEC" NUMBER,
		  "ICBYTES" NUMBER,
		  "OFFLOADBYTES" NUMBER,
		  "OFFLOADRETURNBYTES" NUMBER,
		  "FLASHCACHEREADS" NUMBER,
		  "UNCOMPBYTES" NUMBER,
		  "TIME_RANK" NUMBER,
		  "SQL_ID" VARCHAR2(30),
		  "PHV" NUMBER,
		  "MODULE" VARCHAR2(64),
		  "SQL_TEXT" VARCHAR2(30)
		)
		ORGANIZATION external
		(
		  TYPE oracle_loader
		  DEFAULT DIRECTORY AWR_STAGE_DIR
		  ACCESS PARAMETERS
		  (
		    RECORDS DELIMITED BY NEWLINE CHARACTERSET US7ASCII
		    BADFILE 'AWR_STAGE_DIR':'topsqlx-all.bad'
		    DISCARDFILE 'AWR_STAGE_DIR':'topsqlx-all.discard'
		    LOGFILE 'AWR_STAGE_DIR':'topsqlx-all.log_xt'
		    READSIZE 1048576
		    FIELDS TERMINATED BY "," LDRTRIM
		    MISSING FIELD VALUES ARE NULL
		    REJECT ROWS WITH ALL NULL FIELDS
		    (
		      "INSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "DB_ID" CHAR(255)
		        TERMINATED BY ",",
		      "HOSTNAME" CHAR(255)
		        TERMINATED BY ",",
		      "SNAP_ID" CHAR(255)
		        TERMINATED BY ",",
		      "TM" CHAR(255)
		        TERMINATED BY ","
		        DATE_FORMAT DATE MASK "MM/DD/YY HH24:MI:SS",
		      "INST" CHAR(255)
		        TERMINATED BY ",",
		      "DUR" CHAR(255)
		        TERMINATED BY ",",
		      "AAS" CHAR(255)
		        TERMINATED BY ",",
		      "ELAP" CHAR(255)
		        TERMINATED BY ",",
		      "ELAPEXEC" CHAR(255)
		        TERMINATED BY ",",
		      "CPUT" CHAR(255)
		        TERMINATED BY ",",
		      "IOWAIT" CHAR(255)
		        TERMINATED BY ",",
		      "APPWAIT" CHAR(255)
		        TERMINATED BY ",",
		      "CONCURWAIT" CHAR(255)
		        TERMINATED BY ",",
		      "CLWAIT" CHAR(255)
		        TERMINATED BY ",",
		      "BGET" CHAR(255)
		        TERMINATED BY ",",
		      "DSKR" CHAR(255)
		        TERMINATED BY ",",
		      "DPATH" CHAR(255)
		        TERMINATED BY ",",
		      "ROWP" CHAR(255)
		        TERMINATED BY ",",
		      "EXEC" CHAR(255)
		        TERMINATED BY ",",
		      "PRSC" CHAR(255)
		        TERMINATED BY ",",
		      "PXEXEC" CHAR(255)
		        TERMINATED BY ",",
		      "ICBYTES" CHAR(255)
		        TERMINATED BY ",",
		      "OFFLOADBYTES" CHAR(255)
		        TERMINATED BY ",",
		      "OFFLOADRETURNBYTES" CHAR(255)
		        TERMINATED BY ",",
		      "FLASHCACHEREADS" CHAR(255)
		        TERMINATED BY ",",
		      "UNCOMPBYTES" CHAR(255)
		        TERMINATED BY ",",
		      "TIME_RANK" CHAR(255)
		        TERMINATED BY ",",
		      "SQL_ID" CHAR(255)
		        TERMINATED BY ",",
		      "PHV" CHAR(255)
		        TERMINATED BY ",",
		      "MODULE" CHAR(255)
		        TERMINATED BY ",",
		      "SQL_TEXT" CHAR(255)
		        TERMINATED BY ","
		    )
		  )
		  location
		  (
		    'topsqlx-all.csv'
		  )
		)REJECT LIMIT UNLIMITED;
				

		-- statements to cleanup objects created by previous statements:
		------------------------------------------------------------------------
		/*
		DROP TABLE "AWR_TOPSQLX_EXT";
		DROP DIRECTORY AWR_STAGE_DIR;
		DROP TABLE "AWR_TOPSQLX" purge;
		*/				

		
-- LOAD data on the staging table
-- #############################################################

		--truncate table AWR_TOPSQLX;
		--select snap_id from AWR_TOPSQLX;
		select count(*) from AWR_TOPSQLX;
		select count(*) from AWR_TOPSQLX_EXT;
		
    insert /*+ append */ into AWR_TOPSQLX
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(SNAP_ID),trim(TM),trim(INST),trim(DUR),trim(AAS),trim(ELAP),trim(ELAPEXEC),trim(CPUT),trim(IOWAIT),trim(APPWAIT),trim(CONCURWAIT),trim(CLWAIT),trim(BGET),trim(DSKR),trim(DPATH),trim(ROWP),trim(EXEC),trim(PRSC),trim(PXEXEC),trim(ICBYTES),trim(OFFLOADBYTES),trim(OFFLOADRETURNBYTES),trim(FLASHCACHEREADS),trim(UNCOMPBYTES),trim(TIME_RANK),trim(SQL_ID),trim(PHV),trim(MODULE),trim(SQL_TEXT)
    from AWR_TOPSQLX_EXT
    minus
    select
    trim(INSTNAME),trim(DB_ID),trim(HOSTNAME),trim(SNAP_ID),trim(TM),trim(INST),trim(DUR),trim(AAS),trim(ELAP),trim(ELAPEXEC),trim(CPUT),trim(IOWAIT),trim(APPWAIT),trim(CONCURWAIT),trim(CLWAIT),trim(BGET),trim(DSKR),trim(DPATH),trim(ROWP),trim(EXEC),trim(PRSC),trim(PXEXEC),trim(ICBYTES),trim(OFFLOADBYTES),trim(OFFLOADRETURNBYTES),trim(FLASHCACHEREADS),trim(UNCOMPBYTES),trim(TIME_RANK),trim(SQL_ID),trim(PHV),trim(MODULE),trim(SQL_TEXT)
    from AWR_TOPSQLX;
commit;
		
		set echo on
		select count(*) from AWR_TOPSQLX;
		select count(*) from AWR_TOPSQLX_EXT;
		
		


