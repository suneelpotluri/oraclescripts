column	table_owner new_value table_owner
column	table_name new_value table_name

set termout off

select	table_owner, table_name
from	all_synonyms
where	owner = 'PUBLIC'
and	table_name = upper('&1')
union all
select	table_owner, table_name
from	user_synonyms
where	table_name = upper('&1')
union all
select	user, table_name
from	user_tables
where	table_name = upper('&1')
/

set termout on

prompt
prompt [1m&table_owner..&table_name[0m

desc &table_owner..&table_name
prompt

column column_name format a40
column partitioning format a12
column unq format a1
break on index_name skip 1

select	index_name, uniqueness,
	decode
	(
		p.table_name
		, NULL, NULL
		, decode(i.partitioned, 'YES', 'LOCAL', 'GLOBAL')
	) partitioning
from	dba_indexes i
,	dba_part_tables p
where	i.table_owner = '&table_owner'
and	i.table_name = '&table_name'
and	i.table_owner = p.owner (+)
and	i.table_name = p.table_name (+)
order
by	1
/

select  index_name, column_name
from    dba_ind_columns
where   table_owner = '&table_owner'
and     table_name = '&table_name'
order
by      index_name, column_position
/

column partitions format a30

select	partition_count || ' ' ||
	partitioning_type || ' PARTITIONS ON ' PARTITIONS
,	c.column_name
from	dba_part_tables t
,	dba_part_key_columns c
where	t.owner = '&table_owner'
and	t.table_name = '&table_name'
and	t.owner = c.owner
and	t.table_name = c.name
order
by	column_position
/


clear col
clear break
