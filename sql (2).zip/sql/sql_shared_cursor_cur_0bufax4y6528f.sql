SELECT /* sqlhc.sql Cursor Sharing List */
ROWNUM "#", v.* FROM (
SELECT /*+ NO_MERGE */
inst_id
, child_number
FROM gv$sql_shared_cursor
WHERE :shared_cursor = 'Y'
AND sql_id = '0bufax4y6528f'
ORDER BY 1, 2) v;
