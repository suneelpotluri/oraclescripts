	-- -----------------------------------------------------------------------------
    --   Component: Database                       
    --   Delivered By : ATOS                       
    --   Developer : Sandip Girase       
    --   Date: 09-sept-2017                        
    --   Customer: EITC - DU                       
    -- -----------------------------------------------------------------------------------------------------------------------  
    --   General Instructions :                                                                                             --
    --   1. Change the value of the Migration startscript variables filename,version,track, what,description        --
    --      in the section Bugzilla tracking variables   
    --
    --   2. Please name your SQL script filename according to the naming convention below:                    --
    --      <Project_name>-<Date:YYYYMMDD>-<Version#>-<LHS running number>-Bug<Bugzilla report#>-<Step#>.sql        --
    --      i.e.             EITC-v*-20061110-XXXX-BugXXXX-Step*.sql                            --
    --                      EITC-v1-20061110-1000-Bug1200-Step1.sql                                --
    --                      EITC-v1-20061110-1000-Bug1200-Step1.sql                                --
    --      LHS running number XXXX to increase from 1000.                                    --
    --      Version numbers v* to be increased for New versions of the same script.                        --
    --      Once a Script Has been applied to a Database, it cannot be changed.                        --
    --      The Script version should be an Increasing Numeric.                                --
    --      Step# is needed if there is more than one script for that Bugzilla report.                    --
    --      Note please DO NOT put any description in the filename!!!!!                            --
    --      e.g.   EITC-v1-20160614-PE-DIG-1692-BZ14161-Step04.sql     
    --
    --   3. Change the types,constants and variables in their respective sections with suitable comments
    --
    --   4. Change the matrix values in the respective section with comments about the input fields    
    --
    --   5. Change the Step no and purpose of the script in the comment section above    
    --
    --   6. DO NOT MODIFY/DELETE the functions GetField,GetFmtStr,splitstring and procedures PrintLog,CloseScript,InitScript
    --
    --   7. Put your code logic in the correct place between the tags                            --
    --      --- START OF CODE                                                --
    --      and                                                        --
    --      --- END OF CODE        
    --
    --                                                                          --   
    -- ----------------------------------------------------------------------------------------------------------------------- 

    set define '~'
    set timing on
    set feedback on
    set echo on
    set lines 150
    set autocommit off
    -- format wrapped added to keep leading spaces on line
    -- set serveroutput on
    set serveroutput on format wrapped

    WHENEVER SQLERROR EXIT 1 ROLLBACK;
    WHENEVER OSERROR  EXIT 2 ROLLBACK;



    ------------------------------------------------------------------------------------------------------------                             
    --                                                                                                        --
    --                 AMEND the Migration.StartScript variables below with the appropriate values            --
    --                                                                                                        -- 
    ------------------------------------------------------------------------------------------------------------


    ------------------------ Start Of Bugzilla Tracking Variables ----------------------------------------------
    
    -- the filename of this SQL script WITHOUT the ".sql" suffix/extension
    define filename="EITC-v1-20170928-PSD-ENT-VAT-BZXXXXX-D2_Step10"

    -- the version of your script
    define version="/main/V1"

    -- do not chage.
    define track="SQL"


    -- put the Bugzilla report number here
    define what="BZXXXXX"

    -- the summary of the Bugzilla report
    define description="VAT Disable Contraints on MPULKEGM"
    -------------------- End Of Bugzilla Tracking Variables --------------------------------------------------

    -- DEFINE VERSION CONTROL ERROR MESSAGE
    DEFINE version_err="VERSION CONFLICT: "

    -- Define timestamp vaiable for log file suffix
    column ts new_value ts noprint;
    select to_char(sysdate, 'YYYYMMDDHH24MISS') ts from dual;

    -- spool to logfile in format filename_timestamp.sql 
    -- i.e. EITC-v1-20061110-1000-Bug1200-Step1_20100901154505.sql
    -- In this way new log files will be produced for each run
    spool ~filename._~ts..log

    -- **** PUT ANY DDL HERE 

	--Table Creation:

--MPULKEGM


	
ALTER TABLE SYSADM.MPULKEGM DISABLE CONSTRAINTS MPUEGMSE;

--MPULKTMB

ALTER TABLE SYSADM.MPULKTMB DISABLE CONSTRAINTS MPUTMBAC; 

--MPULLKTMB ACC Codes

ALTER TABLE SYSADM.MPULKTMB DISABLE CONSTRAINTS MPUTMBUS; 

--MPULLKTMB USG Codes

ALTER TABLE SYSADM.MPULKTMB DISABLE CONSTRAINTS MPUTMBSU; 

--MPULLKTMB SUB Codes
	
--Mpulktm1

ALTER TABLE SYSADM.MPULKTM1 DISABLE CONSTRAINTS MPUTM1AC;

ALTER TABLE SYSADM.MPULKTM1 DISABLE CONSTRAINTS MPUTM1US;

ALTER TABLE SYSADM.MPULKTM1 DISABLE CONSTRAINTS MPUTM1SU; 


--ALTER TABLE SYSADM.MPULKEGM ENABLE CONSTRAINTS MPUEGMSE;

--ALTER TABLE SYSADM.MPULKTMB ENABLE CONSTRAINTS MPUTMBAC; --MPULLKTMB ACC Codes

--ALTER TABLE SYSADM.MPULKTMB ENABLE CONSTRAINTS MPUTMBUS; --MPULLKTMB USG Codes

--ALTER TABLE SYSADM.MPULKTMB ENABLE CONSTRAINTS MPUTMBSU; --MPULLKTMB SUB Codes
	
--Mpulktm1

--ALTER TABLE SYSADM.MPULKTM1 ENABLE CONSTRAINTS MPUTM1AC;

--ALTER TABLE SYSADM.MPULKTM1 ENABLE CONSTRAINTS MPUTM1US;

--ALTER TABLE SYSADM.MPULKTM1 ENABLE CONSTRAINTS MPUTM1SU;

	
    ----------------------------------------------------------------------------------------------------------
    --                                                                                                      --
    --                            BEGINNING OF PL/SQL BLOCK                                                 --
    --                                                                                                      --
    ----------------------------------------------------------------------------------------------------------

    ----------------------------------------------------------------------------------------------------------
    --                                                                                                      --
    --                            MIGRATION SCRIPT PARAMETERS                                               --
    --                                                                                                      --
    ----------------------------------------------------------------------------------------------------------
    DECLARE
       v_mig_script_id  dmfadm.mig_script.mig_script_id%TYPE;
       errpos                   BINARY_INTEGER;
       
    BEGIN
       /* New MIG functionality, need to pre-store the script before it can be executed by StartScript */
       SELECT NVL (MAX (mig_script_id), 0)
         INTO v_mig_script_id
         FROM dmfadm.mig_script;
      
       INSERT INTO dmfadm.mig_script
               (mig_script_id, mig_script_name
               )
        VALUES (v_mig_script_id + 1, '~filename' || '.sql'
               );

       BEGIN
          Migration.StartScript
        ( piosScriptName    => '~filename' ||'.sql',
          piosTrack         => '~track',
          piosScriptVersion => '~version',
          piosScriptWhat    => '~what', /* Short Decription of SQL; Bill, Bug, Rat, CC for example */
          piobReentrantInd  => TRUE,
          piosDescription   => '~description'
        );
       END;

    ------------------------------------------------------------------------------------------------------------------------
    --                                                              --
    -- INDIVIDUAL PROCEDURES TO BE INCLUDED BETWEEN THE TAGS "---START OF CODE---" AND THE "----END OF CODE----" TAG ONLY --
    --                                                              --
    ------------------------------------------------------------------------------------------------------------------------
    --START OF CODE

    DECLARE    
         
     -------------------------------------------------------------------------------------------------------------------
     --                                               TYPES                                                           --                                                                          
     -------------------------------------------------------------------------------------------------------------------

     /* Type declaration */
     SUBTYPE tpstring IS CLOB; /* use CLOB to store large statements */
          
     TYPE tpchar IS TABLE OF tpstring
         INDEX BY BINARY_INTEGER;

     TYPE matrixtype IS TABLE OF VARCHAR2(200) ;

          
     -------------------------------------------------------------------------------------------------------------------
     --                                               CONSTANTS                                                       --                                                                          
    -------------------------------------------------------------------------------------------------------------------
      
    C_NORMAL             CONSTANT NUMBER                 := 0;
    C_WARNING            CONSTANT NUMBER                 := 1;
    C_ERROR              CONSTANT NUMBER                 := 2;
    C_DEBUG              CONSTANT NUMBER                 := 3;
    C_TRACE              BOOLEAN                         := TRUE; 

    ------------------------------------------------------------------------------------------------------------------
    --                                                VARIABLES                                                     --                                                 
    ------------------------------------------------------------------------------------------------------------------   
      
      /* Variable used for creating rollback script */
      v_rollback           tpchar;
      

      
           
            V_COUNT_NUM             NUMBER :=0;   
            v_spcode_shdes          MPUSNTAB.SHDES%TYPE;
            v_sncode_shdes          MPUSNTAB.DES%TYPE;
            v_rec_version           varchar2(8);         --RATEPLAN_VERSION.REC_VERSION%TYPE
			v_TAXCODE_NAME 			SYSADM.TAX_CODE.TAXCODE_NAME%type;
			v_TAXCODE  				SYSADM.TAX_CODE.TAXCODE%type;
			v_time   NUMBER;
			v_msg    VARCHAR2 (600);
                   
       /* Cursor to select the rate plans */
      ---------------------------------------------------------------------------------------------------------
      -- Matrix used as input of the script for new rate plan version                                        -- 
      -- The fields for each row are:           
      --
      -- The Spcode Short Description                                                                        --
      -- The Sncode Short Description                                                                        --
      --------------------------------------------------------------------------------------------------------- 
       
         a_ser_sp_pak          matrixtype
         :=  matrixtype (
                       -- 'HUKP4|SR001',
						
						/*'OCCEB|HDOC1',
						'OCCEB|HDOC2',
						'OCCEB|HDOC3',
						'OCCEB|HDOC4',
						'OCCEB|HDOC5',*/
						
					'Five Tax|5'

						
                        );
         
      /*------------------------------------------------------------
      ** FUCTION: GetFmtStr
      **------------------------------------------------------------
      */   
      FUNCTION GetFmtStr (p_input VARCHAR2) RETURN VARCHAR2 IS
      BEGIN
         IF p_input IS NULL
         THEN
            RETURN 'NULL';
         ELSE
            RETURN ''''||p_input||'''';
         END IF;
      END;
   
      FUNCTION GetFmtStr (p_input NUMBER) RETURN VARCHAR2 IS
      BEGIN
         IF p_input IS NULL
         THEN 
            RETURN 'NULL';
         ELSE
            RETURN TO_CHAR(p_input);
         END IF;
      END;    
      
      FUNCTION GetFmtStr (p_input DATE) RETURN VARCHAR2 IS
      BEGIN
         IF p_input IS NULL
         THEN
            RETURN 'NULL';
         ELSE
            RETURN 'TO_DATE('''||TO_CHAR(p_input, 'YYYY-MM-DD HH24:MI:SS')||''',''YYYY-MM-DD HH24:MI:SS'')';
         END IF;
      END;    

      /*---------------------------------------------------------------------
      ** PROCEDURE: PrintLog
      **---------------------------------------------------------------------
      */
      PROCEDURE PrintLog (pionLevel IN NUMBER, piosLogMsg IN VARCHAR2) IS
         v_label     VARCHAR2(50);
      BEGIN
         CASE pionLevel
            WHEN C_NORMAL
            THEN
               v_label := '';
            WHEN C_WARNING
            THEN
               v_label := 'WARNING: ';
            WHEN C_ERROR
            THEN
               v_label := 'ERROR: ';
            WHEN C_DEBUG
            THEN
               IF C_TRACE = FALSE
               THEN
                   RETURN;
               ELSE
                   v_label := 'DEBUG: ';
               END IF;
            ELSE
               v_label := '';
         END CASE;
   
         DBMS_OUTPUT.PUT_LINE(TO_CHAR (SYSDATE, 'DD-MM-YYYY HH24:MI:SS')
                              || ' - ' || v_label || piosLogMsg);
      END; /* PrintLog */

      /*----------------------------------------------------------------
      ** PROCEDURE: SplitString
      ** Split a string in an array of string
      ** based on delimited passed
      **----------------------------------------------------------------
      */
      FUNCTION SplitString (p_in_string tpstring, p_delim VARCHAR2)
         RETURN tpchar
      IS
         i                 NUMBER   := 0;
         v_pos             NUMBER   := 0;
         v_finished        BOOLEAN  := FALSE;
         v_wrk_string      tpstring := p_in_string;
         p_tbstrings_out   tpchar;
      BEGIN
         -- while not finished continue processing
         WHILE NOT v_finished
         LOOP
            -- increment counter
            i := i + 1;
            -- determine position of first occurence of delimited
            -- in input string starting from position 1 in the string
            v_pos := INSTR (v_wrk_string, p_delim, 1);
   
            -- if position = 0 then last row
            IF v_pos = 0
            THEN
               -- array element = input string
               p_tbstrings_out (i) := v_wrk_string;
               -- exit from function
               v_finished := TRUE;
            ELSE
               -- create array element taking substring
               -- until the first position of delimiter
               -- excluding the delimited (pos-1)
               p_tbstrings_out (i) := SUBSTR (v_wrk_string, 1, v_pos - 1);
               -- remove extracted string from input_string
               v_wrk_string :=
                         SUBSTR (v_wrk_string, v_pos + 1, LENGTH (v_wrk_string));
            END IF;
         END LOOP;
   
         -- at the end of the loop return array
         RETURN p_tbstrings_out;
      END SplitString;

      /*---------------------------------------------------------------------------
      ** PROCEDURE: CloseScript
      **---------------------------------------------------------------------------
      */
      PROCEDURE CloseScript IS
         tblines       tpchar;
      BEGIN
      
         PrintLog (C_NORMAL, 'Process Completed');
      
         DBMS_OUTPUT.PUT_LINE ('-- Rollback script is:');
         DBMS_OUTPUT.PUT_LINE ('------------- cut here -------------------');
      
         DBMS_OUTPUT.PUT_LINE ('WHENEVER SQLERROR EXIT 1 ROLLBACK;');
         DBMS_OUTPUT.PUT_LINE ('WHENEVER OSERROR EXIT 2 ROLLBACK;');
      
         -- Enable unlimited DBMS_OUTPUT
         DBMS_OUTPUT.ENABLE(NULL);
      
         /* flush rollback file before closing */
         FOR i IN REVERSE 1 .. NVL (v_rollback.LAST, 0)
         LOOP
            -- split the line in case new line chars are present
            tblines := SplitString(v_rollback(i), CHR(10));
            FOR n in tblines.FIRST .. tblines.LAST
            LOOP
               DBMS_OUTPUT.PUT_LINE (tblines(n));
            END LOOP;
         END LOOP;
      
         DBMS_OUTPUT.PUT_LINE ('------------- cut here -------------------');
         DBMS_OUTPUT.PUT_LINE ('-- End of Rollback script');

      END CloseScript;
      
      /*---------------------------------------------------------------------------
      ** PROCEDURE: InitScript
      **---------------------------------------------------------------------------
      */
      PROCEDURE InitScript IS
      BEGIN
      
         /* Add file-trailer commit and delete in MIG_PROCESS and MIG_SCRIPT */
         PrintLog (C_NORMAL, 'Process Started');
         
         -- Preparing the rollback script         
         v_rollback (NVL (v_rollback.LAST, 0) + 1) := 'COMMIT;';
         v_rollback (NVL (v_rollback.LAST, 0) + 1) := 'DELETE dmf.mig_script  WHERE mig_script_name = ''~filename' ||'.sql'''||';';
         v_rollback (NVL (v_rollback.LAST, 0) + 1) := 'DELETE dmf.mig_process WHERE script_name = ''~filename' ||'.sql'''||';';
         DBMS_OUTPUT.enable(NULL);
         -- In case the command DBMS_METADATA_GET_DDL 
         -- is used within the script set the correct SQL terminator
         -- in order to be executed in a rollback script
         DBMS_METADATA.SET_TRANSFORM_PARAM(DBMS_METADATA.SESSION_TRANSFORM,'SQLTERMINATOR',true);         
      END InitScript; /* InitScript */ 

      /*---------------------------------------------------------------------------------------------
      ** FUCTION: GetField
      ** Extract field from a matrix
      ** Parameters:
      ** p_input    = string containing the fields
      ** p_field_no = position of the field to extract
      ** p_sep      = separator (default | )
      ** p_trim     = Trim field on output, default TRUE
      **---------------------------------------------------------------------------------------------
      */   
      FUNCTION GetField(p_input     VARCHAR2,
                        p_field_no  PLS_INTEGER,
                        p_sep       VARCHAR2 := '|',
                        p_trim      BOOLEAN  := TRUE) 
      RETURN VARCHAR2 IS      
         v_from_pos  PLS_INTEGER;
         v_to_pos    PLS_INTEGER;  
      BEGIN
         
         IF p_field_no = 1
         THEN
            v_from_pos  := 1;
            v_to_pos    := INSTR(p_input, p_sep, 1, p_field_no) - 1;
         ELSE
            v_from_pos  := INSTR(p_input, p_sep, 1, p_field_no - 1) + 1;
            v_to_pos    := INSTR(p_input, p_sep, 1, p_field_no) - v_from_pos;
            
            IF v_to_pos < 0
            THEN 
               /* last field */            
               v_to_pos    := LENGTH(p_input) - v_from_pos + 1;
            END IF;
            
         END IF;
         
                     
         IF p_trim 
         THEN
            RETURN TRIM(SUBSTR(p_input, v_from_pos, v_to_pos));
         ELSE
            RETURN SUBSTR(p_input, v_from_pos, v_to_pos);
         END IF;
      END GetField;

     
       ---------------------------------------------------------------------------------------------------------------
       
       ---  MAIN BODY OF THE PROGRAM

       ---------------------------------------------------------------------------------------------------------------

    BEGIN
      
        InitScript();
				
		v_rollback (NVL (v_rollback.LAST, 0) + 1) := 'DROP TABLE DUADM.ZERO_FEES_PERIOD_1;'; 

        CloseScript ();
      

        END;
   
   -- END OF CODE  

      --------------------------------------------------------------------------------------------------------
    -- IMPORTANT NOTE                                                                                     --
    -- No commit is to be included in the code itself                                                     --
    -- The FinishScript Procedure carries out a commit, If the Block Has been successfull                 --  
    --------------------------------------------------------------------------------------------------------

    BEGIN
        Migration.FinishScript ( piosScriptName => '~filename'||'.sql');
    END;

    --------------------------------------------------------------------------------------------------------
    --                                                                                                    --
    -- Exception handling for the script                                                                  --
    -- Rollback, print error messages and raise error                                                     --
    -- Raise is trapped by initial statement WHENEVER SQLERROR                                            --
    --                                                                                                    --   
    --------------------------------------------------------------------------------------------------------
   
    EXCEPTION
        WHEN OTHERS 
        THEN
        BEGIN
            ROLLBACK;
            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('IMPORTANT NOTICE!!! IMPORTANT NOTICE!!! IMPORTANT NOTICE!!!');
            DBMS_OUTPUT.PUT_LINE('***********************************************************');
            DBMS_OUTPUT.PUT_LINE('FAILURE!!! FAILURE!!! FAILURE!!! FAILURE!!! FAILURE!!!');
            DBMS_OUTPUT.PUT_LINE('......................................................');
            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('There was an ERROR in this script!!! Please correct the codes and rerun!!');

            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('The error message is below:');

            DBMS_OUTPUT.PUT_LINE('Error :' || SQLERRM);
            DBMS_OUTPUT.PUT_LINE('ERROR STACK:'||DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);

            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('.');
            DBMS_OUTPUT.PUT_LINE('Please ignore the "PL/SQL procedure successfully completed." message below!');
            RAISE; /* Raise error to exit script with error code */
          END;
       /* End of Common exception handling */
    END; 
    /
    EXIT
     