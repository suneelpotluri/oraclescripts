grant resource, advisor to ccf_admin;
grant create synonym to ccf_admin;
grant create procedure to ccf_admin;
grant create sequence to ccf_admin;
grant CREATE TABLE to ccf_admin;
grant CREATE TRIGGER to ccf_admin;
grant CREATE TYPE to ccf_admin;
grant CREATE INDEXTYPE to ccf_admin;
grant CREATE VIEW to ccf_admin;
grant CREATE PUBLIC SYNONYM to ccf_admin;
grant CREATE DATABASE LINK to ccf_admin;
grant CREATE PUBLIC DATABASE LINK to ccf_admin;
grant CREATE JOB to ccf_admin;
grant CREATE MATERIALIZED VIEW to ccf_admin;
grant create job to ccf_admin;
grant create materialized view to ccf_admin;
grant select on dba_errors to ccf_admin;
grant select on dba_jobs to ccf_admin;
grant select on dba_jobs_running to ccf_admin;
grant select on v_$logmnr_contents to ccf_admin;
grant select on v_$logmnr_parameters to ccf_admin;
grant select on v_$logmnr_logs to ccf_admin;
grant select on v_$archived_log to ccf_admin;
grant execute on dbms_logmnr to ccf_admin;
GRANT SELECT ON SYS.DBA_HIST_DATABASE_INSTANCE TO ccf_admin;
GRANT SELECT ON SYS.DBA_HIST_SNAPSHOT TO ccf_admin;
grant logmining to ccf_admin;
grant  execute_catalog_role, select any dictionary, select any transaction to ccf_admin;
grant create job to ccf_admin;
grant create materialized view to ccf_admin;
grant select on dba_errors to ccf_admin;
grant select on dba_directories to ccf_admin;
grant select on dba_jobs to ccf_admin;
grant select on dba_jobs_running to ccf_admin;
grant execute on dbms_crypto to ccf_admin;
grant execute on dbms_ijob to ccf_admin; 
grant execute on dbms_job to ccf_admin;
grant execute on dbms_lob to ccf_admin;
grant execute on dbms_lock to ccf_admin;
grant execute on dbms_random to ccf_admin;
grant execute on dbms_utility to ccf_admin;
grant execute on dbms_xmldom to ccf_admin;
grant execute on dbms_xmlparser to ccf_admin;
grant execute on dbms_workload_repository to ccf_admin;
grant drop public database link to ccf_admin;
grant drop public synonym to ccf_admin; 
grant select any transaction to ccf_admin;
grant select on user_objects to ccf_admin;
grant select on user_synonyms to ccf_admin;
grant select on v_$database to ccf_admin;
grant select on v_$instance to ccf_admin;
grant select on v_$parameter to ccf_admin;
grant select on v_$session to ccf_admin;
grant select on v_$tablespace to ccf_admin;
grant select on dba_data_files to ccf_admin;
grant select on dba_temp_files to ccf_admin;
grant select on v_$log to ccf_admin;
grant create session to ccf_admin;
grant create session to ccf_batch;
grant analyze any to ccf_admin;
grant create library to ccf_admin;
grant select on DBA_SYS_PRIVS to ccf_admin;
grant select on DBA_ROLE_PRIVS to ccf_admin;
grant select on DBA_TAB_PRIVS to ccf_admin;
grant select on DBA_OBJECTS to ccf_admin;
grant select on DBA_SYNONYMS to ccf_admin;
grant select on DBA_TAB_COLUMNS to ccf_admin;
grant select on DBA_TAB_PARTITIONS to ccf_admin;
grant select on USER_OBJECTS to ccf_admin;
grant select on USER_SYNONYMS to ccf_admin;
grant QUERY REWRITE to ccf_admin;
grant UNLIMITED TABLESPACE to ccf_admin;
grant select on dba_jobs to ccf_user;
grant select on dba_jobs_running to ccf_user;
grant execute on dbms_crypto to ccf_user; 
grant execute on dbms_ijob to ccf_user;
grant execute on dbms_lob to ccf_user;
grant select on user_objects to ccf_user;
grant select on user_synonyms to ccf_user;
grant select on v_$instance to ccf_user;
grant select on v_$mystat to ccf_user;
grant create session to ccf_user;
grant create session to ccf_customer;
grant create session to ccf_interface;
grant create session to tcs_interface;
grant select on dba_errors to ccf_batch; 
grant select on dba_jobs to ccf_batch;
grant execute on dbms_crypto to ccf_batch;
grant execute on dbms_ijob to ccf_batch; 
grant execute on dbms_job to ccf_batch;
grant execute on dbms_lob to ccf_batch;
grant select on user_objects to ccf_batch;
grant select on user_synonyms to ccf_batch;
grant select on v_$instance to ccf_batch;
grant select on v_$mystat to ccf_batch;
/
begin
   dbms_network_acl_admin.create_acl (
   acl             => 'Ascade_Job_Access.xml',      -- Name of the access control list XML file
   description     => '',  -- Brief description
   principal       => 'CCF_ADMIN',               -- First user account or role being granted or denied permission
                                                 --   this is case sensitive,
                                                 --   but typically user names and roles are stored in upper-case letters
   is_grant        => TRUE,                      -- TRUE = granted, FALSE = denied
   privilege       => 'connect',                 -- connect or resolve, this setting is case sensitive,
                                                 --   so always enter it in lowercase
                                                 --    connect if user uses the UTL_TCP, UTL_HTTP, UTL_SMTP, and UTL_MAIL
                                                 --    resolve if user uses the UTL_INADDR
   start_date      => null,                      -- optional, null is the default
                                                 --   in format of timestamp_with_time_zone (YYYY-MM-DD HH:MI:SS.FF TZR)
                                                 --   for example, '2008-02-28 06:30:00.00 US/Pacific'
   end_date        => null                       -- optional, null is the default
   );
   commit;
exception when others then
   if SQLCODE = -31003 OR SQLCODE = -46212 then
   -- the acl already exists
      null;
   else
      raise;
   end if;   
end;
/
begin
	dbms_network_acl_admin.assign_acl (
	acl           => 'Ascade_Job_Access.xml', -- Name of the access control list XML file to be modified
	host          => '*',                   -- Network host to which this access control list will be assigned
														 -- This a host name or IP address or wild card name
	lower_port    => null,                  -- (optional)
	upper_port    => null);                 -- (optional)
	commit;
end;
/
begin
	-- really ensure that ccf_admin gets connect grant
   DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE('Ascade_Job_Access.xml', 'CCF_ADMIN', true, 'connect');	
	commit;
end;
/
-- Make sure we only gather automatic statistics for DB entities owned by ORACLE. We do custom statistics for our own entities.
BEGIN
  dbms_auto_task_admin.enable('auto optimizer stats collection', operation => NULL, window_name => NULL);
  dbms_stats.set_param('AUTOSTATS_TARGET', 'ORACLE');
END;
/
begin
dbms_java.grant_permission('CCF_ADMIN','java.util.PropertyPermission','*','read,write');
dbms_java.grant_permission('CCF_ADMIN','java.net.SocketPermission','*','connect, resolve');
dbms_java.grant_permission('CCF_ADMIN', 'java.io.FilePermission', 'c:\\temp\\*', 'read,write,delete'); 
dbms_java.grant_permission('CCF_ADMIN', 'java.io.FilePermission', 'c:\\temp\\', 'write'); 
dbms_java.grant_permission('CCF_ADMIN', 'java.io.FilePermission', '//var//tmp//*', 'read,write,delete'); 
dbms_java.grant_permission('CCF_ADMIN', 'java.io.FilePermission', '//var//tmp//', 'write'); 
dbms_java.grant_permission('CCF_ADMIN', 'java.io.FilePermission', '/var/tmp/*', 'read,write,delete'); 
dbms_java.grant_permission('CCF_ADMIN', 'java.io.FilePermission', '/var/tmp/', 'write'); 
commit;
end;
/


