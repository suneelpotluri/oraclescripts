@@sqlt_s61086_system_stats.sql
DEF TC_USER_SUFFIX = "";
@@sqlt_s61086_metadata.sql
HOS imp TC61086/TC61086 FILE=cbo_stat_tab_4tc.dmp LOG=cbo_stat_tab_4tc.log TABLES=cbo_stat_tab_4tc IGNORE=Y
CONN TC61086/TC61086
REM Ignore errors by UPGRADE_STAT_TABLE api call below:
EXEC SYS.DBMS_STATS.UPGRADE_STAT_TABLE(USER,'CBO_STAT_TAB_4TC');
EXEC SYS.DBMS_STATS.IMPORT_SCHEMA_STATS(USER,'CBO_STAT_TAB_4TC');
@@sqlt_s61086_set_cbo_env.sql
@@tc.sql
