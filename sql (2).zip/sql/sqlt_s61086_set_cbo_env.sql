SPO sqlt_s61086_set_cbo_env.log;
SET ECHO ON TERM ON;
REM
REM $Header: 215187.1 sqlt_s61086_set_cbo_env.sql 12.1.160429 2017/03/13 abel.macias $
REM
REM Copyright (c) 2000-2015, Oracle Corporation. All rights reserved.
REM
REM AUTHOR
REM   abel.macias@oracle.com
REM
REM SCRIPT
REM   sqlt_s61086_set_cbo_env.sql
REM
REM SOURCE
REM   Host    : meyicmlvdb2
REM   DB Name : ICMIPR
REM   Platform: Solaris
REM   Product : Oracle Database 11g Enterprise Edition (64bit Production)
REM   Version : 11.2.0.3.0
REM   Language: US:AMERICAN_AMERICA.AL32UTF8
REM   EBS     : NO
REM   Siebel  : NO
REM   PSFT    : NO
REM
REM DESCRIPTION
REM   This script is generated automatically by the SQLT tool.
REM   It contains the SQL*Plus commands to set the CBO environment
REM   for your test case. Use this script prior to the execution
REM   of SQLT for the SQL being analyzed.
REM
REM PARAMETERS
REM   None.
REM
REM EXAMPLE
REM   SQL> START sqlt_s61086_set_cbo_env.sql;
REM
REM NOTES
REM   1. Review and edit if needed.
REM   2. Should be run as the test case user.
REM

/*************************************************************************************/

ALTER SESSION SET optimizer_features_enable = '11.2.0.3';

SET ECHO OFF;
PRO
--PAU Press ENTER to execute ALTER SYSTEM/SESSION commands to set CBO env.
SET ECHO ON;

/*************************************************************************************/

REM Non-Default or Modified Parameters

-- Maximum size of the PGA memory for one process. isdefault="FALSE" ismodified="SYSTEM_MOD" issys_modifiable="IMMEDIATE"
ALTER SYSTEM SET "_pga_max_size" = 2147483648 SCOPE=MEMORY;

-- Target size for the aggregate PGA memory consumed by the instance. isdefault="FALSE" ismodified="SYSTEM_MOD" issys_modifiable="IMMEDIATE"
-- ALTER SYSTEM SET pga_aggregate_target = 4294967296 SCOPE=MEMORY;

-- number of parallel execution threads per CPU. isdefault="FALSE" ismodified="FALSE" issys_modifiable="IMMEDIATE"
ALTER SYSTEM SET parallel_threads_per_cpu = 1 SCOPE=MEMORY;

-- automatic capture of SQL plan baselines for repeatable statements. isdefault="FALSE" ismodified="FALSE"
ALTER SESSION SET optimizer_capture_sql_plan_baselines = FALSE;

-- use of SQL plan baselines for captured sql statements. isdefault="FALSE" ismodified="FALSE"
ALTER SESSION SET optimizer_use_sql_plan_baselines = FALSE;

-- cursor sharing mode. isdefault="FALSE" ismodified="FALSE"
ALTER SESSION SET cursor_sharing = 'EXACT';

/*************************************************************************************/

REM Non-Default Bug Fix Control



/*************************************************************************************/

REM Default Unmodified Parameters

-- enable/disable PQ NUMA support issys_modifiable="FALSE"
-- name:"_px_numa_support_enabled" value:"TRUE" skip:"non-modifiable";

-- maximum memory allow for BITMAP MERGE issys_modifiable="FALSE"
-- name:"bitmap_merge_area_size" value:"1048576" skip:"non-modifiable";

-- Control DML frequency tracking issys_modifiable="IMMEDIATE"
ALTER SYSTEM SET "_dml_frequency_tracking" = FALSE SCOPE=MEMORY;

-- enable modification monitoring issys_modifiable="IMMEDIATE"
ALTER SYSTEM SET "_dml_monitoring_enabled" = TRUE SCOPE=MEMORY;

-- optimizer secure view merging and predicate pushdown/movearound issys_modifiable="IMMEDIATE"
ALTER SYSTEM SET optimizer_secure_view_merging = TRUE SCOPE=MEMORY;

-- number of CPUs for this instance issys_modifiable="IMMEDIATE"
ALTER SYSTEM SET cpu_count = 320 SCOPE=MEMORY;

-- db block to be read each IO
ALTER SESSION SET db_file_multiblock_read_count = 128;

-- multiblock read count for regular clients
ALTER SESSION SET "_db_file_optimizer_read_count" = 8;

-- add stale mv to dependency list
ALTER SESSION SET "_add_stale_mv_to_dependency_list" = TRUE;

-- allow level without connect by
ALTER SESSION SET "_allow_level_without_connect_by" = FALSE;

-- always favor use of star transformation
ALTER SESSION SET "_always_star_transformation" = FALSE;

-- allow partition pruning based on multiple mechanisms
ALTER SESSION SET "_and_pruning_enabled" = TRUE;

-- enable the use of bitmap plans for tables w. only B-tree indexes
ALTER SESSION SET "_b_tree_bitmap_plans" = TRUE;

-- enables or disables bloom filter
ALTER SESSION SET "_bloom_filter_enabled" = TRUE;

-- Enable folding of bloom filter
ALTER SESSION SET "_bloom_folding_enabled" = TRUE;

-- enable or disable bloom min max filtering
ALTER SESSION SET "_bloom_minmax_enabled" = TRUE;

-- enables or disables bloom filter predicate pushdown
ALTER SESSION SET "_bloom_predicate_enabled" = TRUE;

-- enables or disables bloom filter predicate pushdown to storage
ALTER SESSION SET "_bloom_predicate_pushdown_to_storage" = TRUE;

-- Enable partition pruning using bloom filtering
ALTER SESSION SET "_bloom_pruning_enabled" = TRUE;

-- allow rewrites with multiple MVs and base tables
ALTER SESSION SET "_bt_mmv_query_rewrite_enabled" = TRUE;

-- enable complex view merging
ALTER SESSION SET "_complex_view_merging" = TRUE;

-- enables conversion of set operator to join
ALTER SESSION SET "_convert_set_to_join" = FALSE;

-- enables costing of equality semi-join
ALTER SESSION SET "_cost_equality_semi_join" = TRUE;

-- sanity check on default selectivity for like/range predicate
ALTER SESSION SET "_default_non_equality_sel_check" = TRUE;

-- control dimension skip when null feature
ALTER SESSION SET "_dimension_skip_null" = TRUE;

-- disable datalayer sampling
ALTER SESSION SET "_disable_datalayer_sampling" = FALSE;

-- disable function-based index matching
ALTER SESSION SET "_disable_function_based_index" = FALSE;

-- Disable parallel conventional loads
ALTER SESSION SET "_disable_parallel_conventional_load" = FALSE;

-- enables unnesting of in subquery into distinct view
ALTER SESSION SET "_distinct_view_unnesting" = FALSE;

-- enables elimination of common sub-expressions
ALTER SESSION SET "_eliminate_common_subexpr" = TRUE;

-- enable dml lock escalation against partitioned tables if TRUE
ALTER SESSION SET "_enable_dml_lock_escalation" = TRUE;

-- mv rewrite on remote table/view
ALTER SESSION SET "_enable_query_rewrite_on_remote_objs" = TRUE;

-- use the row shipping optimization for wide table selects
ALTER SESSION SET "_enable_row_shipping" = TRUE;

-- enable type dependent selectivity estimates
ALTER SESSION SET "_enable_type_dep_selectivity" = TRUE;

-- do runtime pruning in iterator if set to TRUE
ALTER SESSION SET "_extended_pruning_enabled" = TRUE;

-- enable/disable index fast full scan
ALTER SESSION SET "_fast_full_scan_enabled" = TRUE;

-- enable the use of dynamic proration of join cardinalities
ALTER SESSION SET "_first_k_rows_dynamic_proration" = TRUE;

-- force use of trunc for datefolding rewrite
ALTER SESSION SET "_force_datefold_trunc" = FALSE;

-- control new query rewrite features
ALTER SESSION SET "_force_rewrite_enable" = FALSE;

-- Force slave mapping for intra partition loads
ALTER SESSION SET "_force_slave_mapping_intra_part_loads" = FALSE;

-- executes concatenation of rollups using temp tables
ALTER SESSION SET "_force_temptables_for_gsets" = FALSE;

-- Force tmp segment loads
ALTER SESSION SET "_force_tmp_segment_loads" = FALSE;

-- enable full partition-wise join when TRUE
ALTER SESSION SET "_full_pwise_join_enabled" = TRUE;

-- enable group-by and aggregation using hash scheme
ALTER SESSION SET "_gby_hash_aggregation_enabled" = TRUE;

-- controls extensions to partition pruning for general predicates
ALTER SESSION SET "_generalized_pruning_enabled" = TRUE;

-- enables filter for global index with partition extended syntax
ALTER SESSION SET "_globalindex_pnum_filter_enabled" = TRUE;

-- enable anti/semi join for the GS query
ALTER SESSION SET "_gs_anti_semi_join_allowed" = TRUE;

-- enable/disable hash join
ALTER SESSION SET "_hash_join_enabled" = TRUE;

-- improved outer-join cardinality calculation
ALTER SESSION SET "_improved_outerjoin_card" = TRUE;

-- enable the improvements for computing the average row length
ALTER SESSION SET "_improved_row_length_enabled" = TRUE;

-- enable the use of index joins
ALTER SESSION SET "_index_join_enabled" = TRUE;

-- control kdt buffering for conventional inserts
ALTER SESSION SET "_kdt_buffering" = TRUE;

-- enable random distribution method for left of nestedloops
ALTER SESSION SET "_left_nested_loops_random" = TRUE;

-- treat LIKE predicate with bind as an equality predicate
ALTER SESSION SET "_like_with_bind_as_equality" = FALSE;

-- enable local communication costing when TRUE
ALTER SESSION SET "_local_communication_costing_enabled" = TRUE;

-- prohibit stats aggregation at compile/partition maintenance time
ALTER SESSION SET "_minimal_stats_aggregation" = TRUE;

-- allow rewrites with multiple MVs and/or base tables
ALTER SESSION SET "_mmv_query_rewrite_enabled" = TRUE;

-- enable/disable new algorithm for MJV with generalized outer joins
ALTER SESSION SET "_mv_generalized_oj_refresh_opt" = TRUE;

-- enable initial join orders based on new ordering heuristics
ALTER SESSION SET "_new_initial_join_orders" = TRUE;

-- enables the use of new cost estimate for sort
ALTER SESSION SET "_new_sort_cost_estimate" = TRUE;

-- OR expansion during optimization disabled
ALTER SESSION SET "_no_or_expansion" = FALSE;

-- sanity check on default selectivity for like/range predicate
ALTER SESSION SET "_oneside_colstat_for_equijoins" = TRUE;

-- adjust stats for skews across partitions
ALTER SESSION SET "_optim_adjust_for_part_skews" = TRUE;

-- TRUE to enable index [fast] full scan more often
ALTER SESSION SET "_optim_enhance_nnull_detection" = TRUE;

-- improves the way default equijoin selectivity are computed
ALTER SESSION SET "_optim_new_default_join_sel" = TRUE;

-- enable peeking of user binds
ALTER SESSION SET "_optim_peek_user_binds" = TRUE;

-- optimizer adaptive cursor sharing
ALTER SESSION SET "_optimizer_adaptive_cursor_sharing" = TRUE;

-- adjust selectivity for null values
ALTER SESSION SET "_optimizer_adjust_for_nulls" = TRUE;

-- Enables AW Join Push optimization
ALTER SESSION SET "_optimizer_aw_join_push_enabled" = TRUE;

-- Enables statistcs on AW olap_table table function
ALTER SESSION SET "_optimizer_aw_stats_enabled" = TRUE;

-- cost with cache statistics
ALTER SESSION SET "_optimizer_cache_stats" = FALSE;

-- optimizer cartesian join enabled
ALTER SESSION SET "_optimizer_cartesian_enabled" = TRUE;

-- disable cost based transformation query size restriction
ALTER SESSION SET "_optimizer_cbqt_no_size_restriction" = TRUE;

-- consider coalescing of subqueries optimization
ALTER SESSION SET "_optimizer_coalesce_subqueries" = TRUE;

-- enable selectivity estimation for builtin functions
ALTER SESSION SET "_optimizer_complex_pred_selectivity" = TRUE;

-- force index stats collection on index creation/rebuild
ALTER SESSION SET "_optimizer_compute_index_stats" = TRUE;

-- use cost-based transformation for whr clause in connect by
ALTER SESSION SET "_optimizer_connect_by_cb_whr_only" = FALSE;

-- combine no filtering connect by and start with
ALTER SESSION SET "_optimizer_connect_by_combine_sw" = TRUE;

-- use cost-based transformation for connect by
ALTER SESSION SET "_optimizer_connect_by_cost_based" = TRUE;

-- allow connect by to eliminate duplicates from input
ALTER SESSION SET "_optimizer_connect_by_elim_dups" = TRUE;

-- force correct computation of subquery selectivity
ALTER SESSION SET "_optimizer_correct_sq_selectivity" = TRUE;

-- enables  costing of filter predicates in IO cost model
ALTER SESSION SET "_optimizer_cost_filter_pred" = FALSE;

-- add cost of generating result set when #rows per key > 1
ALTER SESSION SET "_optimizer_cost_hjsmj_multimatch" = TRUE;

-- use join selectivity in choosing star transformation dimensions
ALTER SESSION SET "_optimizer_dim_subq_join_sel" = TRUE;
-- Transforms Distinct Aggregates to non-distinct aggregates
ALTER SESSION SET "_optimizer_distinct_agg_transform" = TRUE;

-- Eliminates redundant SELECT DISTNCT's
ALTER SESSION SET "_optimizer_distinct_elimination" = TRUE;

-- consider distinct placement optimization
ALTER SESSION SET "_optimizer_distinct_placement" = TRUE;

-- optimizer filtering join elimination enabled
ALTER SESSION SET "_optimizer_eliminate_filtering_join" = TRUE;

-- use improved density computation for selectivity estimation
ALTER SESSION SET "_optimizer_enable_density_improvements" = TRUE;

-- use extended statistics for selectivity estimation
ALTER SESSION SET "_optimizer_enable_extended_stats" = TRUE;

-- consider table lookup by nl transformation
ALTER SESSION SET "_optimizer_enable_table_lookup_by_nl" = TRUE;

-- push filters before trying cost-based query transformation
ALTER SESSION SET "_optimizer_enhanced_filter_push" = TRUE;

-- join pred pushdown on group-by, distinct, semi-/anti-joined view
ALTER SESSION SET "_optimizer_extend_jppd_view_types" = TRUE;

-- optimizer false predicate pull up transformation
ALTER SESSION SET "_optimizer_false_filter_pred_pullup" = TRUE;

-- use fast algorithm to traverse predicates for physical optimizer
ALTER SESSION SET "_optimizer_fast_access_pred_analysis" = TRUE;

-- use fast algorithm to generate transitive predicates
ALTER SESSION SET "_optimizer_fast_pred_transitivity" = TRUE;

-- use cost-based flter predicate pull up transformation
ALTER SESSION SET "_optimizer_filter_pred_pullup" = TRUE;

-- enable/disable filter predicate pushdown
ALTER SESSION SET "_optimizer_filter_pushdown" = TRUE;

-- free transformation subheap after each transformation
ALTER SESSION SET "_optimizer_free_transformation_heap" = TRUE;

-- enable/disable full outer to left outer join conversion
ALTER SESSION SET "_optimizer_full_outer_join_to_outer" = TRUE;

-- consider group-by placement optimization
ALTER SESSION SET "_optimizer_group_by_placement" = TRUE;
-- enables the embedded hints to be ignored
ALTER SESSION SET "_optimizer_ignore_hints" = FALSE;

-- improve table and partial overlap join selectivity computation
ALTER SESSION SET "_optimizer_improve_selectivity" = TRUE;

-- interleave join predicate pushdown during CBQT
ALTER SESSION SET "_optimizer_interleave_jppd" = TRUE;

-- optimizer join elimination enabled
ALTER SESSION SET "_optimizer_join_elimination_enabled" = TRUE;

-- use join factorization transformation
ALTER SESSION SET "_optimizer_join_factorization" = TRUE;

-- enable/disable sanity check for multi-column join selectivity
ALTER SESSION SET "_optimizer_join_sel_sanity_check" = TRUE;

-- enable merge join cartesian
ALTER SESSION SET "_optimizer_mjc_enabled" = TRUE;

-- force setting of optimizer mode for user recursive SQL also
ALTER SESSION SET "_optimizer_mode_force" = TRUE;

-- consider join-predicate pushdown that requires multi-level pushdown to base table
ALTER SESSION SET "_optimizer_multi_level_push_pred" = TRUE;

-- compute join cardinality using non-rounded input values
ALTER SESSION SET "_optimizer_new_join_card_computation" = TRUE;

-- null-aware antijoin parameter
ALTER SESSION SET "_optimizer_null_aware_antijoin" = TRUE;

-- Use subheap for optimizer or-expansion
ALTER SESSION SET "_optimizer_or_expansion_subheap" = TRUE;

-- Eliminates order bys from views before query transformation
ALTER SESSION SET "_optimizer_order_by_elimination_enabled" = TRUE;

-- enable/disable outer to inner join conversion
ALTER SESSION SET "_optimizer_outer_join_to_inner" = TRUE;

-- Enable transformation of outer-join to anti-join if possible
ALTER SESSION SET "_optimizer_outer_to_anti_enabled" = TRUE;

-- use cost-based query transformation for push pred optimization
ALTER SESSION SET "_optimizer_push_pred_cost_based" = TRUE;

-- reuse cost annotations during cost-based query transformation
ALTER SESSION SET "_optimizer_reuse_cost_annotations" = TRUE;
-- enable the use of first K rows due to rownum predicate
ALTER SESSION SET "_optimizer_rownum_pred_based_fkr" = TRUE;

-- account for self-induced caching
ALTER SESSION SET "_optimizer_self_induced_cache_cost" = FALSE;

-- enable/disable index skip scan
ALTER SESSION SET "_optimizer_skip_scan_enabled" = TRUE;

-- consider index skip scan for predicates with guessed selectivity
ALTER SESSION SET "_optimizer_skip_scan_guess" = FALSE;

-- enable/disable sort-merge join method
ALTER SESSION SET "_optimizer_sortmerge_join_enabled" = TRUE;

-- enable/disable sort-merge join using inequality predicates
ALTER SESSION SET "_optimizer_sortmerge_join_inequality" = TRUE;

-- enables unnesting of subquery in a bottom-up manner
ALTER SESSION SET "_optimizer_squ_bottomup" = TRUE;

-- enable/disable star transformation in with clause queries
ALTER SESSION SET "_optimizer_star_tran_in_with_clause" = TRUE;

-- optimizer star plan enabled
ALTER SESSION SET "_optimizer_starplan_enabled" = TRUE;

-- system statistics usage
ALTER SESSION SET "_optimizer_system_stats_usage" = TRUE;

-- consider table expansion transformation
ALTER SESSION SET "_optimizer_table_expansion" = TRUE;

-- retain equi-join pred upon transitive equality pred generation
ALTER SESSION SET "_optimizer_transitivity_retain" = TRUE;

-- try Star Transformation before Join Predicate Push Down
ALTER SESSION SET "_optimizer_try_st_before_jppd" = TRUE;

-- undo changes to query optimizer
ALTER SESSION SET "_optimizer_undo_changes" = FALSE;

-- enables unnesting of every type of subquery
ALTER SESSION SET "_optimizer_unnest_all_subqueries" = TRUE;

-- Unnesting of correlated set subqueries (TRUE/FALSE)
ALTER SESSION SET "_optimizer_unnest_corr_set_subq" = TRUE;

-- Unnesting of disjunctive subqueries (TRUE/FALSE)
ALTER SESSION SET "_optimizer_unnest_disjunctive_subq" = TRUE;

-- use rewritten star transformation using cbqt framework
ALTER SESSION SET "_optimizer_use_cbqt_star_transformation" = TRUE;
-- optimizer use feedback
ALTER SESSION SET "_optimizer_use_feedback" = TRUE;

-- Enables physical optimizer subheap
ALTER SESSION SET "_optimizer_use_subheap" = TRUE;

-- enable OR expanded plan for NVL/DECODE predicate
ALTER SESSION SET "_or_expand_nvl_predicate" = TRUE;

-- enable ordered nested loop costing
ALTER SESSION SET "_ordered_nested_loop" = TRUE;

-- enable broadcasting of small inputs to hash and sort merge joins
ALTER SESSION SET "_parallel_broadcast_enabled" = TRUE;

-- TRUE to obey force parallel query/dml/ddl under System PL/SQL
ALTER SESSION SET "_parallel_syspls_obey_force" = TRUE;

-- enable partial partition-wise join when TRUE
ALTER SESSION SET "_partial_pwise_join_enabled" = TRUE;

-- enable/disable partitioned views
ALTER SESSION SET "_partition_view_enabled" = TRUE;

-- push predicates into views before rewrite
ALTER SESSION SET "_pre_rewrite_push_pred" = TRUE;

-- enables predicate move-around
ALTER SESSION SET "_pred_move_around" = TRUE;

-- allow predicate elimination if set to TRUE
ALTER SESSION SET "_predicate_elimination_enabled" = TRUE;

-- enable projecting out unreferenced columns of a view
ALTER SESSION SET "_project_view_columns" = TRUE;

-- enable pushing join predicate inside a view
ALTER SESSION SET "_push_join_predicate" = TRUE;

-- enable pushing join predicate inside a union all view
ALTER SESSION SET "_push_join_union_view" = TRUE;

-- enable pushing join predicate inside a union view
ALTER SESSION SET "_push_join_union_view2" = TRUE;

-- enables pq for minus/interect operators
ALTER SESSION SET "_px_minus_intersect" = TRUE;

-- enables or disables parallel partition-based scan
ALTER SESSION SET "_px_partition_scan_enabled" = TRUE;

-- parallel partition wise group by enabled
ALTER SESSION SET "_px_pwg_enabled" = TRUE;

-- enables new pq for UNION operators
ALTER SESSION SET "_px_ual_serial_input" = TRUE;

-- perform the cost based rewrite with materialized views
ALTER SESSION SET "_query_cost_rewrite" = TRUE;
-- perform query rewrite before&after or only before view merging
ALTER SESSION SET "_query_rewrite_1" = TRUE;

-- perform query rewrite before&after or only after view merging
ALTER SESSION SET "_query_rewrite_2" = TRUE;

-- mv rewrite and drop redundant joins
ALTER SESSION SET "_query_rewrite_drj" = TRUE;

-- rewrite with cannonical form for expressions
ALTER SESSION SET "_query_rewrite_expression" = TRUE;

-- mv rewrite fresh partition containment
ALTER SESSION SET "_query_rewrite_fpc" = TRUE;

-- mv rewrite with jg migration
ALTER SESSION SET "_query_rewrite_jgmigrate" = TRUE;

-- allow query rewrite, if referenced tables are not dataless
ALTER SESSION SET "_query_rewrite_or_error" = FALSE;

-- perform general rewrite using set operator summaries
ALTER SESSION SET "_query_rewrite_setopgrw_enable" = TRUE;

-- prune frocol chain before rewrite after view-merging
ALTER SESSION SET "_query_rewrite_vop_cleanup" = TRUE;

-- enable CELL FPLIB filtering within rdbms
ALTER SESSION SET "_rdbms_internal_fplib_enabled" = FALSE;

-- enables removal of subsumed aggregated subquery
ALTER SESSION SET "_remove_aggr_subquery" = TRUE;

-- replace expressions with virtual columns
ALTER SESSION SET "_replace_virtual_columns" = TRUE;

-- Right Outer/Semi/Anti Hash Enabled
ALTER SESSION SET "_right_outer_hash_enable" = TRUE;

-- enable row shipping explain plan support
ALTER SESSION SET "_row_shipping_explain" = FALSE;

-- control rewrite self-join algorithm
ALTER SESSION SET "_selfjoin_mv_duplicates" = TRUE;

-- control simple view merging performed by the optimizer
ALTER SESSION SET "_simple_view_merging" = TRUE;

-- enable slave mapping when TRUE
ALTER SESSION SET "_slave_mapping_enabled" = TRUE;

-- if TRUE, use the AUTO size policy cost functions
ALTER SESSION SET "_smm_auto_cost_enabled" = TRUE;

-- push predicates through reference spreadsheet
ALTER SESSION SET "_spr_push_pred_refspr" = TRUE;

-- enable the use of subquery predicates to perform pruning
ALTER SESSION SET "_subquery_pruning_enabled" = TRUE;

-- enable the use of subquery predicates with MVs to perform pruning
ALTER SESSION SET "_subquery_pruning_mv_enabled" = FALSE;

-- bump estimated full table scan and index ffs cost by one
ALTER SESSION SET "_table_scan_cost_plus_one" = TRUE;

-- trace virtual columns exprs
ALTER SESSION SET "_trace_virtual_columns" = FALSE;

-- enables unnesting of complex subqueries
ALTER SESSION SET "_unnest_subquery" = TRUE;

-- enable the use of column statistics for DDP functions
ALTER SESSION SET "_use_column_stats_for_function" = TRUE;

-- overload virtual columns expression
ALTER SESSION SET "_virtual_column_overload_allowed" = TRUE;

-- enable SQL processing offload to cells
ALTER SESSION SET cell_offload_processing = TRUE;

-- defer segment creation to first insert
ALTER SESSION SET deferred_segment_creation = TRUE;

-- Enables/Disables internal conversions during DST upgrade
ALTER SESSION SET dst_upgrade_insert_conv = TRUE;

-- Usage of invisible indexes (TRUE/FALSE)
ALTER SESSION SET optimizer_use_invisible_indexes = FALSE;

-- Control whether to use optimizer pending statistics
ALTER SESSION SET optimizer_use_pending_statistics = FALSE;

-- force single instance execution
ALTER SESSION SET parallel_force_local = FALSE;

-- skip unusable indexes if set to TRUE
ALTER SESSION SET skip_unusable_indexes = TRUE;

-- always use this method for anti-join when possible
ALTER SESSION SET "_always_anti_join" = 'CHOOSE';

-- always use this method for semi-join when possible
ALTER SESSION SET "_always_semi_join" = 'CHOOSE';

-- use union all for connect by
ALTER SESSION SET "_connect_by_use_union_all" = 'TRUE';

-- Deferred constant folding mode
ALTER SESSION SET "_deferred_constant_folding_mode" = 'DEFAULT';

-- enable improved costing of index access using in-list(s)
ALTER SESSION SET "_optimizer_better_inlist_costing" = 'ALL';

-- enables cost-based query transformation
ALTER SESSION SET "_optimizer_cost_based_transformation" = 'LINEAR';

-- optimizer cost model
ALTER SESSION SET "_optimizer_cost_model" = 'CHOOSE';

-- optimizer extended cursor sharing
ALTER SESSION SET "_optimizer_extended_cursor_sharing" = 'UDO';

-- optimizer extended cursor sharing for relational operators
ALTER SESSION SET "_optimizer_extended_cursor_sharing_rel" = 'SIMPLE';

-- execute full outer join using native implementaion
ALTER SESSION SET "_optimizer_native_full_outer_join" = 'FORCE';

-- control or expansion approach used
ALTER SESSION SET "_optimizer_or_expansion" = 'DEPTH';

-- optimizer undo cost change
ALTER SESSION SET "_optimizer_undo_cost_change" = '11.2.0.3';

-- policy used for parallel execution on cluster(ADAPTIVE/CACHED)
ALTER SESSION SET "_parallel_cluster_cache_policy" = 'ADAPTIVE';

-- pivot implementation method
ALTER SESSION SET "_pivot_implementation_method" = 'CHOOSE';

-- specifies compile-time unfolding of sql model forloops
ALTER SESSION SET "_sql_model_unfold_forloops" = 'RUN_TIME';

-- expand queries with GSets into UNIONs for rewrite
ALTER SESSION SET "_union_rewrite_for_gs" = 'YES_GSET_MVS';

-- WITH subquery transformation
ALTER SESSION SET "_with_subquery" = 'OPTIMIZER';

-- Cell packet compaction strategy
ALTER SESSION SET cell_offload_compaction = 'ADAPTIVE';

-- Cell offload explain plan display
ALTER SESSION SET cell_offload_plan_display = 'AUTO';

-- optimizer mode
ALTER SESSION SET optimizer_mode = 'ALL_ROWS';

-- limit placed on degree of parallelism
ALTER SESSION SET parallel_degree_limit = 'CPU';

-- policy used to compute the degree of parallelism (MANUAL/LIMITED/AUTO)
ALTER SESSION SET parallel_degree_policy = 'MANUAL';

-- threshold above which a plan is a candidate for parallelization (in seconds)
ALTER SESSION SET parallel_min_time_threshold = 'AUTO';

-- allow rewrite of queries using materialized views if enabled
ALTER SESSION SET query_rewrite_enabled = 'TRUE';
-- perform rewrite using materialized views with desired integrity
ALTER SESSION SET query_rewrite_integrity = 'ENFORCED';

-- result cache operator usage mode
ALTER SESSION SET result_cache_mode = 'MANUAL';

-- enable the use of star transformation
ALTER SESSION SET star_transformation_enabled = 'FALSE';

-- statistics level
ALTER SESSION SET statistics_level = 'TYPICAL';

-- policy used to size SQL working areas (MANUAL/AUTO)
ALTER SESSION SET workarea_size_policy = 'AUTO';

-- settings for aggregation optimizations
ALTER SESSION SET "_aggregation_optimization_settings" = 0;

-- bloom filter pushing size upper bound
ALTER SESSION SET "_bloom_pushing_max" = 512;

-- number of elements in a bloom filter vector
ALTER SESSION SET "_bloom_vector_elements" = 0;

-- divisor for converting CPU cost to I/O cost
ALTER SESSION SET "_cpu_to_io" = 0;

-- disable direct path insert features
ALTER SESSION SET "_direct_path_insert_features" = 0;

-- max percentage of the shared pool to use for a mining model
ALTER SESSION SET "_dm_max_shared_pool_pct" = 1;

-- size of Frequent Itemset Counting work area
ALTER SESSION SET "_fic_area_size" = 131072;

-- number of blocks hash join will read/write at once
ALTER SESSION SET "_hash_multiblock_io_count" = 0;

-- set the ratio between global and local communication (0..100)
ALTER SESSION SET "_local_communication_ratio" = 50;

-- maximum no of groupings on materialized views
ALTER SESSION SET "_max_rwgs_groupings" = 8192;

-- nested loop fudge
ALTER SESSION SET "_nested_loop_fudge" = 100;

-- enable batching of the RHS IO in NLJ
ALTER SESSION SET "_nlj_batching_enabled" = 1;

-- standard block size used by optimizer
ALTER SESSION SET "_optimizer_block_size" = 8192;

-- cost factor for cost-based query transformation
ALTER SESSION SET "_optimizer_cbqt_factor" = 50;

-- force the optimizer to use the same degree of parallelism
ALTER SESSION SET "_optimizer_degree" = 0;

-- disable star transformation sanity checks
ALTER SESSION SET "_optimizer_disable_strans_sanity_checks" = 0;

-- controls the optimizer usage of extended stats
ALTER SESSION SET "_optimizer_extended_stats_usage_control" = 192;

-- Optimizer index bias over FTS/IFFS under first K rows mode
ALTER SESSION SET "_optimizer_fkr_index_cost_bias" = 10;

-- force the optimizer to use the specified number of instances
ALTER SESSION SET "_optimizer_instance_count" = 0;

-- controls the optimizer join order search algorithm
ALTER SESSION SET "_optimizer_join_order_control" = 3;

-- optimizer maximum join permutations per query block
ALTER SESSION SET "_optimizer_max_permutations" = 2000;

-- set minimum cached blocks
ALTER SESSION SET "_optimizer_min_cache_blocks" = 10;

-- number of groups above which we use nested rollup exec for gset
ALTER SESSION SET "_optimizer_nested_rollup_for_gset" = 100;

-- optimizer percent parallel
ALTER SESSION SET "_optimizer_percent_parallel" = 101;

-- push down distinct from query block to table
ALTER SESSION SET "_optimizer_push_down_distinct" = 0;

-- optimizer seed value for random plans
ALTER SESSION SET "_optimizer_random_plan" = 0;

-- Default value to use for rownum bind
ALTER SESSION SET "_optimizer_rownum_bind_default" = 10;

-- optimizer search limit
ALTER SESSION SET "_optimizer_search_limit" = 5;

-- optimizer star transformation minimum cost
ALTER SESSION SET "_optimizer_star_trans_min_cost" = 0;

-- optimizer star transformation minimum ratio
ALTER SESSION SET "_optimizer_star_trans_min_ratio" = 0;

-- Parallel scalability criterion for parallel execution
ALTER SESSION SET "_parallel_scalability" = 50;

-- unit of work used to derive the degree of parallelism (in seconds)
ALTER SESSION SET "_parallel_time_unit" = 10;

-- set the tq broadcasting fudge factor percentage
ALTER SESSION SET "_px_broadcast_fudge_factor" = 100;

-- least number of partitions per slave to start partition-based scan
ALTER SESSION SET "_px_partition_scan_threshold" = 64;
-- query mmv rewrite maximum number of cmaps per dmap in query disjunct
ALTER SESSION SET "_query_mmvrewrite_maxcmaps" = 20;

-- query mmv rewrite maximum number of dmaps per query disjunct
ALTER SESSION SET "_query_mmvrewrite_maxdmaps" = 10;

-- query mmv rewrite maximum number of in-lists per disjunct
ALTER SESSION SET "_query_mmvrewrite_maxinlists" = 5;

-- query mmv rewrite maximum number of intervals per disjunct
ALTER SESSION SET "_query_mmvrewrite_maxintervals" = 5;

-- query mmv rewrite maximum number of predicates per disjunct
ALTER SESSION SET "_query_mmvrewrite_maxpreds" = 10;

-- query mmv rewrite maximum number of query in-list values
ALTER SESSION SET "_query_mmvrewrite_maxqryinlistvals" = 500;

-- query mmv rewrite maximum number of region permutations
ALTER SESSION SET "_query_mmvrewrite_maxregperm" = 512;

-- cost based query rewrite with MVs fudge factor
ALTER SESSION SET "_query_rewrite_fudge" = 90;

-- query rewrite max disjuncts
ALTER SESSION SET "_query_rewrite_maxdisjunct" = 257;

-- result cache auto max size allowed
ALTER SESSION SET "_result_cache_auto_size_threshold" = 100;

-- result cache auto time threshold
ALTER SESSION SET "_result_cache_auto_time_threshold" = 1000;

-- row shipping column selection threshold
ALTER SESSION SET "_row_shipping_threshold" = 80;

-- Row source tree tracing level
ALTER SESSION SET "_rowsrc_trace_level" = 0;

-- Maximum IO size (in KB) used by sort/hash-join in auto mode
ALTER SESSION SET "_smm_auto_max_io_size" = 248;

-- Minimum IO size (in KB) used by sort/hash-join in auto mode
ALTER SESSION SET "_smm_auto_min_io_size" = 56;

-- maximum work area size in auto mode (serial)
ALTER SESSION SET "_smm_max_size" = 838860;

-- minimum work area size in auto mode
ALTER SESSION SET "_smm_min_size" = 1024;

-- maximum work area size in auto mode (global)
ALTER SESSION SET "_smm_px_max_size" = 2097152;

-- cost ratio for sort eimination under first_rows mode
ALTER SESSION SET "_sort_elimination_cost_ratio" = 0;
-- multi-block read count for sort
ALTER SESSION SET "_sort_multiblock_read_count" = 2;

-- sql compatability bit vector
ALTER SESSION SET "_sql_compatibility" = 0;

-- optimizer percent system index caching
ALTER SESSION SET "_system_index_caching" = 0;

-- size of in-memory hash work area
ALTER SESSION SET hash_area_size = 131072;

-- optimizer dynamic sampling
ALTER SESSION SET optimizer_dynamic_sampling = 2;

-- optimizer percent index caching
ALTER SESSION SET optimizer_index_caching = 0;

-- optimizer index cost adjustment
ALTER SESSION SET optimizer_index_cost_adj = 100;

-- size of in-memory sort work area retained between fetch calls
ALTER SESSION SET sort_area_retained_size = 0;

-- size of in-memory sort work area
ALTER SESSION SET sort_area_size = 65536;

/*************************************************************************************/

REM Default Bug Fix Control

-- ORDER BY sort elimination with OR expansion (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '399198:1';

-- distinct elimination (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '599680:1';

-- CBO do not count 0 rows partitions (ofe 8.1.6) (event 10135)
ALTER SESSION SET "_fix_control" = '1403283:1';

-- disable push predicate driven by func. index into partition view (event 38010)
ALTER SESSION SET "_fix_control" = '2194204:0';

-- push into table with RLS (ofe 9.2.0) (event 38017)
ALTER SESSION SET "_fix_control" = '2320291:1';

-- add(remove) cluster index for push view (ofe 8.1.7) (event 38020)
ALTER SESSION SET "_fix_control" = '2324795:1';

-- use OR'ed predicates in index filter (ofe 9.2.0) (event 0)
ALTER SESSION SET "_fix_control" = '2492766:1';

-- do not trigger bitmap plans if no protential domain index driver (ofe 8.1.7) (event 38026)
ALTER SESSION SET "_fix_control" = '2660592:1';

-- Use extended index caching discount (ofe 8.0.0) (event 38031)
ALTER SESSION SET "_fix_control" = '2663857:1';
-- No selectivity for source transitive equality join predicates (ofe 10.1.0) (event 0)
ALTER SESSION SET "_fix_control" = '3056297:1';

-- Check for obj# for named view estimated card (ofe 9.2.0.8) (event 38079)
ALTER SESSION SET "_fix_control" = '3118776:1';

-- account for join key sparsity in computing NL index access cost (ofe 10.1.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '3120429:1';

-- use cost cutoff for first_rows (ofe 10.1.0) (event 0)
ALTER SESSION SET "_fix_control" = '3151991:1';

-- IN-List costing problem in index join (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '3320140:1';

-- use fkr_1 for (NOT) EXISTS subquery (ofe 10.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '3335182:1';

-- Disable cartesian join on complex views (ofe 10.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '3426050:1';

-- enable tiny index improvements: consider small indexes as cachhe (event 10111)
ALTER SESSION SET "_fix_control" = '3499674:0';

-- Do not consider LIKE with leading wildcard as index key (ofe 10.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '3628118:1';

-- do not combine predicates from LNNVL (ofe 8.0.0) (event 38065)
ALTER SESSION SET "_fix_control" = '3746511:1';

-- Do not use SQL to check for FK integrity if FK in r/o tablespace (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '3801750:1';

-- Lift restriction on unnest subquery with a view (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '3834770:1';

-- multiple signatures for selectivity func (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '4134994:1';

-- SQ to view transform - remove dual from qbcfro (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4158812:1';

-- Eliminate unneeded bitmap conversion (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4168080:1';

-- generate transitive predicates across anti join predicates (ofe 10.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '4175830:1';
-- convert range scan to unique access if possible (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4273361:1';

-- Cache user-defined operator stats across transformations (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4279274:1';

-- outer query must have more than one table unless lateral view (ofe 10.1.0.5) (event 38073)
ALTER SESSION SET "_fix_control" = '4308414:1';

-- Extend 3628118 to cover peeked binds from cursor_sharing=similar (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4370840:1';

-- f()=f() => f() is not null, selectivity for f() is not null (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4386734:1';

-- Delayed constant filter node allocation (event 0)
ALTER SESSION SET "_fix_control" = '4444536:0';

-- Favor unique index in case of cost tie (ofe 9.2.0) (event 38082)
ALTER SESSION SET "_fix_control" = '4483240:1';

-- Discount FFS cost using optimizer_index_cost_adj. (event 38085)
ALTER SESSION SET "_fix_control" = '4483286:0';

-- ignore IS NOT NULL predicate as an index filter (ofe 10.2.0.2) (event 38077)
ALTER SESSION SET "_fix_control" = '4488689:1';

-- Eliminate unnessary sort in parallel cartesian merge join (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4507997:1';

-- Pick view card from view qb instead of parent qb (ofe 9.2.0) (event 38081)
ALTER SESSION SET "_fix_control" = '4519016:1';

-- Generate distinct view in SU if candidate for JPPD (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4519340:1';

-- Adjust inner card for post filters for outer joins (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4545802:1';

-- no selectivity for transitive inequality predicates (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4545833:1';

-- do not consider no sel predicates in join selectivity sanity (ofe 10.1.0) (event 0)
ALTER SESSION SET "_fix_control" = '4550003:1';
-- tbl$or$idx$part$num() predicate causing peformance problems (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4554846:1';

-- min # of join permutations for starting table, new initial order (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4556762:15';

-- do not re-evaluate density on rowcache reload (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4567767:1';

-- Use index heuristic for join pred being pushed (ofe 10.1.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '4569940:1';

-- coalesce multiple relational expressions with GREATEST/LEAST (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '4570921:1';

-- enable common expr elimination, pred move around for insert stmt (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4583239:1';

-- do not disable cartesian products if ORDERED hint is used (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4584065:1';

-- skip internal ref columns for index only check for update/delete (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '4595987:1';

-- Cost inlists as index filters as well as keys (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '4600710:1';

-- optimize top-level predicate chain (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4602374:1';

-- apafio - do not set DONE if the matching failed (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4605810:1';

-- do not clobber predicate during first-k row estimate phase (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4611850:1';

-- ANSI syntax prevents table elimination (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '4615392:1';

-- enable search of virtual expression in multiple indexes (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4619997:1';

-- Refine criteria for additional phase in JPPD (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4631959:1';
-- do not push predicates into deeply nested predicate trees (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4658342:1';

-- for cached NL table set tab_cost_io to zero (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4663698:1';

-- Use base NDV instead of scaled NDV when computing index selectiv (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '4663702:1';

-- use smallest table as first table in join card. initial ordering (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4663804:1';

-- consider subqueries for pruning only from optimizer-refined set (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4666174:1';

-- kkojcio: Get view card using kkotbS not kkotbC (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4676955:1';

-- Fix histogram type determination macro (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4704779:1';

-- Relax view merging security checks for SYS PL/SQL functions (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4705343:1';

-- Use inner table and index DOP for costing NL join (ofe 10.2.0.4) (event 38078)
ALTER SESSION SET "_fix_control" = '4708389:1';

-- Enable code optimization for bitmap access path (ofe 9.2.0) (event 38083)
ALTER SESSION SET "_fix_control" = '4711525:1';

-- Relax view merging security checks for domain indexes (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4716096:1';

-- avoid semantically redundant predicates to be used (ofe 9.2.0) (event 0)
ALTER SESSION SET "_fix_control" = '4717546:1';

-- kkoidc: add SI caching for index branch blocks (ofe 10.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '4722900:1';

-- consider mjc if equi-joined pred is dropped in kkoipt (ofe 10.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4728348:1';

-- treat ansi char constant as varchar2 if operator is not ANSI (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4752814:1';
-- Enable CBQT for CTAS statements (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4768040:1';

-- Disable unnesting of SQ under certain conditions (event 0)
ALTER SESSION SET "_fix_control" = '4872602:0';

-- FKR: also prorate index ABK (avg blocks per key) (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4878299:1';

-- Limit # of slave groups to DOP (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4881533:1';

-- remove restriction from first K row optimization (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4887636:1';

-- Only use relevant check constraints for transitive pred. generat (ofe 10.2.0.1) (event 14199)
ALTER SESSION SET "_fix_control" = '4900129:1';

-- allow index skip scan with no index keys (ofe 9.2.0.8) (event 0)
ALTER SESSION SET "_fix_control" = '4904838:1';

-- do not copy kcc of columns in non-view side of a JPPD (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '4904890:1';

-- Enable star plan for 2 column part pruning index (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '4908162:1';

-- Allow secure view merging if outside of view is zero-argument (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '4924149:1';

-- do not use hash unique for subqueries in update-set expression (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '4926618:1';

-- outer join table elimination (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '4967068:1';

-- upgrade to row-read access instead of row-write (event 38084)
ALTER SESSION SET "_fix_control" = '4969880:0';

-- remove null first element from multicolumn inlist if possible (ofe 9.2.0.8) (event 0)
ALTER SESSION SET "_fix_control" = '5005866:1';

-- Enable CBQT for INSERT statements (ofe 10.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '5014836:1';

-- add new predicate to the VC-EXPR mapping (ofe 9.2.0) (event 0)
ALTER SESSION SET "_fix_control" = '5015557:1';
-- inline view in a stored view (ofe 9.2.0) (event 0)
ALTER SESSION SET "_fix_control" = '5029464:1';

-- derive column statistics from a UNION(ALL) view (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '5029592:3';

-- try for subqueries before forcing in star trans with FACT hint (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '5084239:1';

-- use sql text from qbcqutxt for reparse (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5096560:1';

-- set leaf blocks to the number of blocks in the index extent map (event 0)
ALTER SESSION SET "_fix_control" = '5099019:0';

-- Consider subquery pruning using view containing single table pre (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5099909:1';

-- multiple signatures for selectivity func (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '5104624:1';

-- semi join table elimination (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5112260:1';

-- anti join table elimination (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5112352:1';

-- Make table elimination independent of CVM (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5112460:1';

-- peek at any foldable exprssion during pruning (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '5129233:1';

-- kkoDMcos: For PWJ on list dimension, use part/subpart bits (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5139520:1';

-- disable the fix for the bug # 5011764 (event 22284)
ALTER SESSION SET "_fix_control" = '5143477:0';

-- Enhance view merging security checks for PL/SQL functions (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '5195882:1';

-- do not push constant predicate into set query block (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5199213:1';

-- Allow predicate push for predicates that partition prune (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5220356:1';
-- Allow _optimizer_index_caching to affect IOT primary keys (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5236908:1';

-- Share single copy of coldef within an expression (event 38086)
ALTER SESSION SET "_fix_control" = '5240264:0';

-- avoid NL with fts on right side in fkr mode (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5240607:1';

-- undo unused inlist (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5259048:1';

-- correct selectivity of col LIKE func(:b1) (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5263572:1';

-- do not merge view with distinct into connect by query block (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5284200:0';

-- also try for sort eliminating index with maximum columns (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5288623:1';

-- Allow CBQT for queries with window functions (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5302124:1';

-- put false predicate ahead in the predicate chain (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5371452:1';

-- Limit join permutations considered to 2000 for star plans (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5383891:1';

-- Add heuristic for group-by placement (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5384335:1';

-- Remove restrictions on unsupported view structures for JPPD (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5385629:1';

-- Propagate interleaved CVM flag from CBQT analysis (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5387148:1';

-- add subheap for physical optimization (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5391505:1';

-- Favor rowid= over any other access path regardless of statistics (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5391942:1';

-- don't over-write prorated cardinalities on switch to Amode plan (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5394888:1';

-- prefer index access when joining first non 1-row table in K mode (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5395291:1';

-- Lift restriction on semi-join elimination (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5396162:1';

-- simplification of multiple OR conditions (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '5400639:1';

-- use guess quality from secondary index (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5406763:1';

-- use hash-based mapping in copy service (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '5416118:1';

-- In bitmap costing use real sel for transitive negated predicates (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5449488:1';

-- Do colocate join if columns in fro->frojand are on the same node (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5466973:1';

-- Skip OR chain to enable view merging (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5468809:1';

-- Wrong results from query with nested table (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '5475051:1';

-- discount for partitioned range scan in fkr mode (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5482831:1';

-- Use min repeat count in freq histogram to compute the density (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5483301:1';

-- relax type matching in pre-rewrite transitive predicate generati (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5505157:1';

-- Consider pushing into each of two views sharing join predicate (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5505995:1';

-- Relax semi/antijoin restrictions with remote tables (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5509293:1';

-- light check of gby validity in subquery (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '5520732:1';
-- Promote column min/max values in OJPPD for UNION [ALL] views (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5547058:1';

-- controls generating transitive predicates in presence of UDFs (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5547895:1';

-- Allow inner join table elimination on unique col (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5554865:1';

-- no view with having for group-by placement (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5567933:1';

-- ignore KKOIXMSU flag and match index filter preds with index key (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5570494:1';

-- do not discount branch io cost if inner table io cost is already (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5578791:1';

-- enable index prefetching for NLJ with unique scan as inner acces (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5585313:1';

-- Push USERENV filter predicate into view (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5593639:1';

-- use index keys as filters when considering index min/max (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5611962:1';

-- amend costing for index use to avoid sort with old FIRST_ROWS (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5618040:1';

-- do not push into UV if target table is outer joinded (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5620485:1';

-- disable union all transformation if qbc does not have whr (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5624216:1';

-- Relax equality operator restrictions for multicolumn inlists (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5634346:1';

-- Adjust join cardinality of join backs (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5648287:3';

-- set correlation flag if outer col is set func (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5650477:1';
-- consider new alternate index to avoid ORDER BY sort (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5657044:1';

-- adjust anti/semijoin index selectivity only if join preds as key (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5680702:1';

-- scale index num distinct keys with Watkins func in first_rows(k) (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5694984:1';

-- remove generated single table predicates before OR expansion (event 0)
ALTER SESSION SET "_fix_control" = '5705630:0';

-- do not load statistics for non access partitions (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5707608:1';

-- set IO cost for index skip scan to at least 1.0 (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5714944:1';

-- Peek at systimestamp at compile-time (ofe 11.2.0.1) (event 38044)
ALTER SESSION SET "_fix_control" = '5716785:1';

-- consider predicate with subquery when determine 1-row tables (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5741044:1';

-- avoid zero selectivity for negated predicate (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5741121:1';

-- improve selectivity for character strings of numeric data (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5762598:1';

-- Sort tables for initial join order during star transformation (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5838613:1';

-- compute avg col length for LONG RAW column (event 38087)
ALTER SESSION SET "_fix_control" = '5842686:0';

-- Eliminate group-by from [NOT] EXISTS subqueries (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5844495:1';

-- disallow CVM for top QB views for DELETE (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '5868490:1';

-- push constant filter predicates on PRIORs to connect by pump (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5872956:1';
-- Avoid unnecessary column stats load for partitioned tables (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5882954:1';

-- consider list of values dimensions during star transformation (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5884780:1';

-- no transitive generation across logical join check constraints (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5891471:1';

-- disable hash join for NEED1ROW subqueries (event 0)
ALTER SESSION SET "_fix_control" = '5892599:0';

-- assume final merge not materialized when estimating temp space s (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5893768:1';

-- enable nlj with func-based ix for join to connect by pump (no cb (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '5897486:1';

-- Extend push of ROWID filter predicates into views (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5902962:1';

-- Get SS lock on child(parent) for serial DML on parent(child) (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '5909305:1';

-- handle virtual columns when comparing row ordering for GBY (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5919513:1';

-- Enable equivalence classes for nested loop join columns (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '5922070:1';

-- Enable outer to inner join conversion for inlist (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '5923644:1';

-- Relax restrictions for SVM with multiply refd scalar subquery (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '5936366:1';

-- Change drop column, set unused to take X DML lock (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '5943234:1';

-- make index access more attractive in first_rows(k) (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5944076:1';

-- do not share rowid of gi for multiple objects (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5947231:1';
-- amend selectivity for match of a single-row frequency bucket (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5949981:1';

-- check dynamic sampling index selecticity for nested loops join (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5976822:1';

-- compact row vector of colocated join (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '5982893:1';

-- use subpartition-level statistics (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '5996801:1';

-- allow JPPD with Cartesian join (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6006300:1';

-- merge single-table anti-joined view (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6006457:1';

-- Add sort cost only to first OR branch (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6007259:1';

-- use nested loops to join to connect by pump if high cardinality (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6012093:1';

-- Allow semi-join elimination with multi column operand (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6020579:1';

-- Index MIN/MAX capping row sources for range partitioned tables (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6029469:1';

-- Do not consider sort-merge to eliminate ORDER BY with no join (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6042205:1';

-- Correction to join cardinality computation for equijoin predicat (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6051211:1';

-- hide negated predicate when trying full bitmap scan (event 0)
ALTER SESSION SET "_fix_control" = '6053861:0';

-- reconize empty joins with histograms (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '6055658:1';

-- call kkehsl() if string in LIKE operator does not have wild card (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6057611:1';

-- use density if estimated selectivity is 0 for range predicate (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6062266:1';

-- No skip scan with contiguous leading equality index keys (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6070954:1';

-- enable connect by cost-based trasnformation for fixed tables (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6073325:1';

-- Do not prorate out-of-range selectivity for single value hist (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6082745:1';

-- correct skip scan selectivity evaluation for BETWEEN predicate (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '6086930:1';

-- do not swap 1 row/leading tables (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6087237:1';

-- no parallel index range scan if single partition is accessed (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6119382:1';

-- Allow JPPD for union-all views with window functions (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6119510:1';

-- favor index only access over range scan (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6120483:1';

-- enhance checks for constant filter push into UNION ALL view (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6122894:1';

-- allocate ckydef on the compilation heap (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6133948:1';

-- Consider only simple column preds in subquery unnest heuristic (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6138746:1';

-- Do not timeout when querying rowcache for (sub)partition (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6141818:1';

-- amend fix of bug 3697218 for window func (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6146906:1';

-- estimation of overlap with histograms (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6151963:1';

-- Peek truncated binds under operators for LIKE predicates (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6163564:1';
-- use NO_SUBSTRB_PAD hint when building histograms (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '6163600:1';

-- replace primary key references during table elimination (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6167716:1';

-- Amend AJ/SJ index selectivity adjustment (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6188881:1';

-- Fix setting outOfRange indicator in sel. estimation (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6221403:1';

-- account for partition-extended names in first rows optimization (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '6236862:1';

-- Allow partition pushup for max/min operators (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6239039:1';

-- Fix out-of-bound value in self induced caching (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6239909:1';

-- use density if estimated selectivity is 0 for range predicate (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6239971:1';

-- Do not apply index caching if no real join access predicates exi (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6251917:1';

-- not use index ndk for selectivity estimation (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6267621:1';

-- Use optimizer_degree to determine SGBY pushdown (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6279918:1';

-- allow OR expansion in start with query block (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6282093:1';

-- allow pushing predicates from connect by query blocks into views (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6282944:1';

-- normalize varchar2 const as fixed CHAR if another operand is CHA (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6326934:1';

-- use combined selectivity of range predicates with binds (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6329318:1';
-- add pflags info into other_xml (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6365442:1';

-- Allow broadcast local distribution for ref-partitioning (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6368066:1';

-- remove distribution method optimization for insert/update qbc (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6376551:1';

-- Convert outer-join to inner-join if single set aggregate functio (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6377505:1';

-- disallow HASH GROUP BY for subquery (in filter) processing (event 0)
ALTER SESSION SET "_fix_control" = '6399597:0';

-- use recursive idx selectivity for partitioned table as well (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '6408301:1';

-- suppress staleness tracking of non-safe rewrite equivalences (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6418552:1';

-- use equivalence class when trying for order-by sort elimination (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6418771:1';

-- no join elimination for start with qb (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6429113:1';

-- prefer fully qualified unique index even if more expensive (event 0)
ALTER SESSION SET "_fix_control" = '6430500:0';

-- skip unusable indexes if hinted internally (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6434668:1';

-- do not store cost annotations for branch QBs in unnested subquer (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6438752:1';

-- selectively apply fkr on views (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6438892:1';

-- Relax index heuristic for JPPD in UNION[ALL] view (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '6439032:1';

-- No selectivity for some logically redundant predicates (event 0)
ALTER SESSION SET "_fix_control" = '6440977:0';
-- allow CBQT even if there is a query block inside a having clause (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6451322:1';

-- Remove unnecessary sort when view column refers to const operand (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6468287:1';

-- typecheck pushed predicate to convert decrypt operator (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6469667:1';

-- load and use statistics for hash sub-partitions (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '6472966:1';

-- enable PWJ on ref-part table and composite parent join (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6502845:1';

-- Improve range join selectivity (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6503543:1';

-- allow merging of view with (+) in OR clause (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6514189:1';

-- disallow CONNECT BY clauses that use ROWNUM or have no PRIORs (event 0)
ALTER SESSION SET "_fix_control" = '6520717:0';

-- don't expand NVL(DECODE) with constant second(third) argument (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6528872:1';

-- sort columns by id (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6530596:1';

-- allow dynamic sampling on fixed tables (event 0)
ALTER SESSION SET "_fix_control" = '6608941:0';

-- allow (+) in OR clause (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6610822:1';

-- cleanup qbciqb after xml rewrite (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6612471:1';

-- ensure outer joined operands are not marked as constant (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '6617866:1';

-- FKR: switch to A mode if leading is FTS (event 0)
ALTER SESSION SET "_fix_control" = '6626018:0';

-- allow table elimination in presence of join indexes (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6656356:1';
-- an operand of OPTTNN is null-safe for query unnesting (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6669103:1';

-- derive index statistics even if table is empty (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6670551:1';

-- Allow join elimination in presence of OR predicate chains (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6671155:1';

-- FKR: apply subquery filtering factor on all-rows cardinality (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6674254:1';

-- Enable unnesting of correlated subquery containing tbl$ predicat (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6681545:1';

-- check for log AND before disallowing join elimination (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6688200:1';

-- Account for chained rows when computing TA by ROWID from bitmap  (ofe 10.2.0.4) (event 0)
ALTER SESSION SET "_fix_control" = '6694548:1';

-- enable cardinality feedback-based cursor sharing (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6699059:1';

-- allow dynamic sampling on table functions (event 0)
ALTER SESSION SET "_fix_control" = '6708183:0';

-- Enable pushup through both dimensions for PWJ (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6714199:1';

-- Apply the pre 10.1 1000 expressions limit for multi-table insert (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '6720701:1';

-- allow parallelization of DFO consuming correlated variables (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6748058:1';

-- Change distribution method between Load and Query DFO's (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6751206:1';

-- enable expression replacement thru views (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '6754080:1';

-- intersect predicates across predicate subtrees (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6765823:1';
-- sample size in DS is at most equal to the partition sample size (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6766962:1';

-- generate transitive predicates across predicate subtrees (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6768660:1';

-- View merge if cursor is argument to table function (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6769711:1';

-- allow JPPD with empty single table branch (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6771838:1';

-- BETWEEN simplification for functions of constants (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6773613:1';

-- interleaved CVM is chosen even if interleaved JPPD is cheaper (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6774209:1';

-- allow view merging for inline views defined in WITH clause (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6776808:1';

-- Restrict transitive predicates for remote query blocks (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6778642:1';

-- consider predicate pushing underneath view with CONNECT BY (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6782437:1';

-- eliminate common subexpression for simple disjunct predicates (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6782665:1';

-- gracefully handle skew on nulls for outer-join (event 0)
ALTER SESSION SET "_fix_control" = '6808773:0';

-- eliminate redundant inlist predicates (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6818410:1';

-- pick the dimension with the highest # of granules for PPWJ (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6820988:1';

-- eliminate duplicate predicates across subtrees (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6827696:1';

-- change qksopCheckNoPrior to check for subqueries and not for fro (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6838105:1';
-- FKR: apply subquery filtering factor on all-rows cardinality (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6845871:1';

-- index cardinality estimates not taking into account NULL rows (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6897034:1';

-- eliminate check for number of elements in a row vector (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6904146:1';

-- enable PWJ for non-natural join orders on ref-part table (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6913094:1';

-- merge selectivity range for single predicate (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6917633:1';

-- use high watermark brokering for insert into single segment (event 0)
ALTER SESSION SET "_fix_control" = '6941515:0';

-- early filter pushdown in all query blocks (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6942476:1';

-- Fix inadequate PK/FK marking for tables in from clause (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6951776:1';

-- Enable exchange partition update global indexes to go parallel (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '6955210:1';

-- allow dynamic sampling when OR-expansion is used (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6956212:1';

-- Choose column group ndv over histograms of individual cols (event 0)
ALTER SESSION SET "_fix_control" = '6972291:0';

-- sanity check for # of rows before using it for selectivity estim (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6972987:1';

-- fix fast full scan index only determination (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '6980350:1';

-- bloom filter for hash join with broadcast left (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '6982954:1';

-- push join pred with single  UV branch not promoting index (event 0)
ALTER SESSION SET "_fix_control" = '6987082:0';

-- allow bind peeking during CBQT (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6990305:1';

-- share kccdef while copying standalone predicates (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '6994194:1';

-- Allow non-well-formed correlated predicates in unnesting (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7032684:1';

-- remove tbl join predicate for PWJ (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7043307:1';

-- allow APPROX_GLOBAL in presence of non-analyzed partitions (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7116357:1';

-- window function replaces having subquery (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7127530:1';

-- cost top-level AND'd subqueries inside of expressions (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7127980:1';

-- Correct concatenated index based join selectivity estimation (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7132036:1';

-- Fix costing for non prefixed local index (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7132684:1';

-- allow first K rows optimization for all CTAS and IAS (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7135745:1';

-- push or-chain with at least 1 non-constanct branch  into UV (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7138405:1';

-- check for decrypt-to-encrypt both sides of equality predicate (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7147087:1';

-- Allow fix of bug 2218788 for in-list predicates (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7148689:1';

-- Restrict use of disabled FFS on IOTs (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '7155968:1';

-- do not mark primary keys for DML  in absence of candidate qb (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7165898:1';

-- allow pushing of complex predicates to scan (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7168184:1';
-- do not raise ORA-12842 if the user so desires (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7170213:1';

-- No AJ/SJ index sel adj, if leading index col has non equality pr (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7176746:1';

-- bloom filter with broadcast left for partial parallel plan (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7199035:1';

-- plan change with INDEX_JOIN hint (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7208131:1';

-- unnest subquery embedded inside an expression (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '7215982:1';

-- FKR: prorate chained row count (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7236148:1';

-- NVL Optimization (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7237571:1';

-- cannot use a global index if part ext tab name and sampling (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7241819:1';

-- Include cost of subqueries in SET of UPDATE in total cost (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7249095:1';

-- No distinct elimination for connect by subquery (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7259468:1';

-- top view of insert as select is not positionable as well (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7263214:1';

-- use index cost adj when comparing skip scan with full table scan (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7272039:1';

-- allow skip scan costing for NL with non-join predicate (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '7277732:1';

-- Try to generate IS NOT NULL from LIKE with leading wildcard (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7281191:1';

-- extended cursor sharing for like predicates (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '7284269:1';

-- ignore bitmap_merge_area_size when running under auto PGA (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7289023:1';

-- Rank subquery filter based on cost (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7295298:1';

-- skip STRTCIOUT while checking NOT NULL (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7298570:1';

-- Allow multi-column null-aware antijoin (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7298626:1';

-- inject SORT BUFFER under FOR UPDATE (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7306637:1';

-- compress TRUE/FALSE predicate subtrees (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7314499:1';

-- remove predicates that are redundant because of subtrees (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7324224:1';

-- amend condition for 6120483 to require inlist index key (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7325597:1';

-- use equal-to-constant predicates with functional index keys (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7341616:1';

-- merge outerjoined lateral view with filter on left table (ofe 10.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '7345484:1';

-- adjust antijoin selectivity to favor over-estimate (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7356191:1';

-- use the number of elements in a collection as table cardinality (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7375077:1';

-- enable subquery pruning on ref-part table (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7375179:1';

-- early window function removal with CBQT (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7385140:1';

-- window function replaces uncorrelated subquery with view (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7388652:1';

-- sanity check for selectivity estimated for single predicate (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7414637:1';
-- no duplicate select list items in kkqtutlGenInlineView (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7426911:1';

-- try all pssible sort eliminating indexes (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7430474:1';

-- apply virtual column replacement after transformation (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7449971:1';

-- cap effective parallelism by NDV (event 0)
ALTER SESSION SET "_fix_control" = '7452823:0';

-- adjust DS level for large parallel tables based on the size (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7452863:1';

-- enable copy of lateral view for CBQT (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7499258:1';

-- identity operators for bind sharing with outer joins (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7512227:1';

-- enable complex view merging with correlation to a merged view (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7519687:1';

-- Eliminate unnecessary sort above iterator for single partition (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7521266:1';

-- enable JPPD for insert statements (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7524366:1';

-- disallow automatic first k-rows for subqueries with group-by (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7528216:1';

-- Remove redundant items from group-by list (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7534027:1';

-- add columns to sort row vector for parallel insert (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7534257:1';

-- ensure suffix elements match when testing for partition wise joi (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7539815:1';

-- transitive predicates is not generated for UNION ALL views' join (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7555510:1';

-- do not pull up UOP if DOI defined on it (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7556098:1';

-- Enable parallel PWJ with pushup of any level after absolute leve (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7558911:1';

-- set qbctjp to null (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7573526:1';

-- remove redundant IS [NOT] NULL predicates (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7576476:1';

-- make only the topmost window node positionable (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7576516:1';

-- return correct subpartition count for composite partitioned tabl (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7585456:1';

-- do not use dyn sampling index selectivity if not all keys sample (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7592673:1';

-- session crash due to jo->kkojopos is not reset at join abortion (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7597059:1';

-- Prune unreferenced view columns from select list (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7597159:1';

-- bloom filter costing takes account of join input swap (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7613118:1';

-- Wrong results from join elim with join pred under OR (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7628358:1';

-- defer cursor invalidation during the truncate operation (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7640597:1';

-- treat a single value column as having a frequency histogram (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '7641601:1';

-- Invoke CBQT star transformation before JPPD (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7650462:1';

-- amend index selectivity calculation for inlists (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7657126:1';

-- Disable group-by placement under certain conditions (event 0)
ALTER SESSION SET "_fix_control" = '7658097:0';
-- Do not use an existing outline when re-building an outline (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '7670533:1';

-- Extend subquery partition pruning to consider constant predicate (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7675944:1';

-- Disable CVM for distinct view when CBQT is invalid (event 0)
ALTER SESSION SET "_fix_control" = '7676897:0';

-- Additional call to view merging after table elimination (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7679161:1';

-- Table elimination for primary key self joins (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7679164:1';

-- peek sysdate when checking index usability (event 0)
ALTER SESSION SET "_fix_control" = '7679490:0';

-- Allow general constant expressions involving binds for LIKE as E (ofe 10.2.0.5) (event 38074)
ALTER SESSION SET "_fix_control" = '7696414:1';

-- don't buffer QC-produced DFO if possible (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7708267:1';

-- copy query block text position fields in copy service (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '7711900:1';

-- [no]parallel statement hint overrides parallel keyword in ddl (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '7718694:1';

-- Allow connect by prior predicates to be considered for pruning (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7831070:1';

-- allow in-list iterators for hash clusters (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '7834811:1';

-- master HV enqueues on instances participating in the load (event 0)
ALTER SESSION SET "_fix_control" = '8198783:0';

-- Improve selectivity of join preds on NVL - traverse predicate tr (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8202421:1';

-- limit or-expanded query block cardinality in first_rows(k) (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8213977:1';
-- perform additional CBQT phase for subquery unnesting (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8214022:1';

-- versions query for archiving for flashback archive (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8226666:1';

-- do not create bloom filter for broadcast if not pushable to scan (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8243446:1';

-- do not use 1/NDK as index selectivity with out-of-range keys (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8247017:1';

-- don't buffer sequence if DFO output is already buffered (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '8251486:1';

-- slave sorting and key sampling for parallel create/rebuild index (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8255423:1';

-- simplify range to equality for join predicates (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '8274946:1';

-- simplify disjoint range to false (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '8275023:1';

-- simplify range to inequality (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '8275054:1';

-- return correct partition range during subquery pruning (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8284930:1';

-- disable the permutation of join key by qkkPoesPUJoin() in kkfd.c (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8287870:1';

-- allow order-by elimination for DML statements (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8289316:1';

-- Enable new sample pct computation for histograms (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8318020:1';

-- use single row to cost index filter (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8323407:1';

-- Put virtual column predicates on index filter (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8328363:1';

-- correct Anti Join overlap selectivity (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8335178:1';

-- do not use statistics from unusable or invisible indexes (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8348392:1';

-- share LOAD buffer slots across partitions (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8348585:1';

-- parallel versions query for archiving for flashback archive (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '8349119:1';

-- Allow virtual columns in OR expansion index access (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8352378:1';

-- correct selectivity of aggr [not] exists subquery (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8355120:1';

-- Cardinality feedback with binds, group by, indexes (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8356253:1';

-- star transformation fact candidate should use two or more indexe (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8371884:1';

-- Lift restriction on lateral view merge in presence of cursor exp (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8373261:1';

-- allow join selectivity cdn sanity check when unanlyzed tables (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8408665:1';

-- fix query block registry for inline views (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8442891:1';

-- Peek binds in the having clause (ofe 11.2.0.1) (event 38044)
ALTER SESSION SET "_fix_control" = '8447850:1';

-- amend costing for index min/max access with filters (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8467123:1';

-- improve selectivity estimation for ACS (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8491399:1';

-- enable rownum optimization without partition pushup (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8500130:1';

-- Unnecessary calls to qksvcReplaceIndexExpr() (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8508056:1';
-- enable optkdustoopn operator for compare columns (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8514561:1';

-- Virtual column replacement for connect by and ansi join queries (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8515269:1';

-- amend outer join cardinality calculation for logical antijoin (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8519457:1';

-- early query edit checks use weak typecheck expression comparison (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8528517:1';

-- cost cutoff for bitmap OR chains based on best table access cost (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8531463:1';

-- do not restore cardinality if semi join elimination is selected (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '8531490:1';

-- handle virtual columns in query edit routines (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8532236:1';

-- Rewrite decode predicate to join (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8551880:1';

-- Enhance functional index checks when considering OR-expansion (ofe 11.1.0.7) (event 0)
ALTER SESSION SET "_fix_control" = '8557992:1';

-- allow SVM with multiply-referenced subquery (event 0)
ALTER SESSION SET "_fix_control" = '8560951:0';

-- drain table queues after slave reaches EOF (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8571403:1';

-- push filters through union all branches (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8578587:1';

-- Relax restriction on veiw merging for DML statements (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8580883:1';

-- disable hwm brokering for insert if distribution is PKEY (event 0)
ALTER SESSION SET "_fix_control" = '8589278:0';

-- using col stats for pred NVL() <op> const selectivity estimation (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8590021:1';
-- reject join predicate pushdown if parallel access path selected (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8595392:1';

-- Allow unique index access for multicolumn inlist (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8602185:1';

-- kkeRangeJoinSel should avoid using collapsed min/max column stat (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8602840:1';

-- adjust dop for in memory pq (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8609714:1';

-- Allow hash aggregation for insert select except for plsql calls (event 0)
ALTER SESSION SET "_fix_control" = '8619631:0';

-- group  predicates like col op const  of 1 NDV col (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8628970:1';

-- enable early replacement for virtual columns (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8629716:1';

-- new parallelization of concat (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8644935:1';

-- relax restriction for distinct union-all branches (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '8672915:1';

-- correctly prune duplicate operands in order by sort row vector (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8675087:1';

-- allow NLJ if there is no sub-query pruning (absolute dimension) (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '8683604:1';

-- Heuristic to enable full index scan used if table & index analyz (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8685327:1';

-- do not apply JF if it prevents JPPD (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8692170:1';

-- consider pushing if only shared predicates to push (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8693158:1';

-- fix for 7449971 not complete (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8706652:1';

-- try non-driver predicate only if advanced check requested (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8725296:1';

-- allow compile-time peeking of CURRENT_DATE / CURRENT_TIMESTAMP (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8760135:1';

-- enable parallel nested loop PWJ for ref-part tables (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8763472:1';

-- compute NDV for all columns in a multi-column join key using DS (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8767442:1';

-- better recognition of index only plans with virtual columns (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8773324:1';

-- use _optimizer_star_trans_min_ratio even if ST not hinted (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8792846:1';

-- threshold of table count to disable extended JPPD (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8800514:20';

-- single-column NAAJ, distribute right side by value (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8802198:1';

-- improved fake statistics for Index Advisor (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8812372:1';

-- relax restriction for non-nullness check (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8813674:1';

-- push HV enq init / HWM operations to slave processes (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8833381:1';

-- push rownum predicate into sortable domain index (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8836806:1';

-- sanity check for skip scan costing (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8855396:1';

-- enable pushing bloom filter through NLJ (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8890233:1';

-- apply index filter selectivity during skip scan costing (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8893626:1';

-- interleave TE with ST and JF (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8896955:1';
-- relax restriction on inequality join for group-by placement (GBP (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8900973:1';

-- correct search of state-space for group-by placement (GBP) (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8901237:1';

-- Incremental for tab subpart and local indexes (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8917507:7';

-- correct nested OR costing bug (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8919133:1';

-- allow tables with lob columns to support online add columns (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8927050:1';

-- write default storage attribute values to deferred_stg$ (event 0)
ALTER SESSION SET "_fix_control" = '8937971:0';

-- make stats for leaf level data appear very large in COTs (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8949971:1';

-- check indrebuild$ for dataobj# when applying undo if OIC mismatc (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '8951812:1';

-- enable better partition pushup in local bitamp join index creati (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '8961143:1';

-- set KKEGIXSL for unpartitioned global index (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8971829:1';

-- auto-capture only if literal replaced SQL parses recursively (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8973745:1';

-- align partition-wise gby DOP requirements with partition-wise jo (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8986163:1';

-- correct cost comparison for the additional phase for JPPD (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '8999317:1';

-- Process mqb (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9002661:1';

-- determine out of range values for simple binds (ofe 10.2.0.5) (event 0)
ALTER SESSION SET "_fix_control" = '9004800:1';

-- Context index to be picked on XMLType Columns (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9007859:1';

-- use 1/NDV+1/NROWS for col1 LIKE col2 selectivities (index driver (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9011016:1';

-- Do not allow Old JPPD for OJ view with window function (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9024933:1';

-- remove restriction on bind variables for table expansion (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9033718:1';

-- directly write synopses to disk in approximate NDV engine (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9038395:1';

-- perform round-robin granule allocation in terms of instances (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9039715:1';

-- use selected measures for AW LOOP OPTIMIZED looping strategy (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9041934:1';

-- improve selectivity for truncated character strings (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9047975:1';

-- Allow NAAJ for UPDATE and DELETE (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9052506:1';

-- search all query blocks for replacement candidates (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9053879:1';

-- enable Exadata projection optimization (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9065494:1';

-- amend histogram column tracking for multicolumn stats (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9069046:1';

-- don't use fake index stats as extended stats (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9081848:1';

-- compress predicate tree before cost-based query transformation (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9088510:1';

-- equi-partition load (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9092442:1';

-- use IO calibrate statistics to estimate time from cost (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9102474:1';
-- not to miss any partition when merging subpartition stats (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9103775:1';

-- allow range distribution in create of global partitioned index (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9106224:1';

-- allow subquery to appear on left side when generating inline vie (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9111170:1';

-- index filter ordering (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9116214:1';

-- produce more accurate stats for olap when stats has not been run (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9125151:1';

-- uncorrelated OR-ed unary predicates are OK for unnesting (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9143856:1';

-- allow distinct elim & distinct aggr transform for non-select stm (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9148171:1';

-- allow loading of rely constraints for all statement types (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9153459:1';

-- consider parallel cost for partition bitmap table access by rowi (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9171113:1';

-- move correlated filters from subquery to outer query (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9185228:1';

-- leaf blocks as upper limit for skip scan blocks (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9195582:1';

-- correct chunks computation (event 0)
ALTER SESSION SET "_fix_control" = '9196440:0';

-- allow bloom pruning and bloom filtering on the same join (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9203723:1';

-- share metadata for virtual columns when making copy (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9206747:1';

-- Don't use column density for selectivity with 1-bucket histogram (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9218587:1';
-- allow skip scan costing for semi/anti-join (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9227576:1';

-- eliminate unreferenced subqueries after view merging (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9239337:1';

-- do not reduce the IO slot size (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9240455:1';

-- relax conditions for logical antijoin (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9243499:1';

-- eliminate redundant join predicates in join elimination (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9245114:1';

-- generate transitive predicates for virtual column expressions (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9263333:1';

-- sanity check for derived ndv/cdn for inner join on range (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9265681:1';

-- disable the permutation of join key by qkkPoesPPUJoin() (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9270951:1';

-- do not sample columns which have statistics (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9272549:1';

-- buffer consumer DFO with a parallel table function (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9274675:1';

-- full outer join to outer join conversion (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9287401:1';

-- enable pruning for partitioned IOT rowid predicates (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9298010:1';

-- enhanced index unusable checks (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9300228:1';

-- ORACLE_LOADER: enable DIRECTIO option for data file reads (event 0)
ALTER SESSION SET "_fix_control" = '9301862:0';

-- use 1/NDV+1/NROWS for col1 LIKE col2 selectivities (table access (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9303766:1';

-- outer join JPPD allowed for function-based index access path (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9309281:1';

-- derive stats for sys generated UA view selectivity estimation (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9340120:1';

-- disable cardinality feedback for old JPPD (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9342979:1';

-- Control the memory used during query optimization (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9344055:1';

-- disable parallel execution for a qb with a constant false pred (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9344709:1';

-- clear sort merge joins paths noted in apafjo (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9355794:1';

-- free parallel slaves upon close by non-restartable row sources (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9356656:1';

-- JPPD for cartesian joins under fix control (event 0)
ALTER SESSION SET "_fix_control" = '9380298:0';

-- Treat CP differently from NLJ for parallel optimizations (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9381638:1';

-- Allow unique (ie. select distinct) pushdown (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9383967:1';

-- check for overflow before squaring large values (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9384170:1';

-- always return error for null end point expression (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9385634:1';

-- estimate expansion cost for entire or-chain (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '9407929:1';

-- enable VC replacement for nest operator (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9433490:1';

-- Do not consider NLJ from JPPD when checking for FCP (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9437283:1';

-- set OPNF2NOSEL bit for auto generated virtual column predicates (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9443476:1';
-- account for to_number/to_char cost after temp conversion (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9456688:1';

-- do not account for index filter cost if table is empty (event 0)
ALTER SESSION SET "_fix_control" = '9456746:0';

-- correct hint for index join from cardinality feedback (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9465425:1';

-- use cdn sanity check when unique colgroup on both sides of join (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9474259:1';

-- error logging specified with instead of trigger (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9476520:1';

-- edit check the view QB if it has a group-by (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9477688:1';

-- do not use histograms in join cardinality calculation (event 0)
ALTER SESSION SET "_fix_control" = '9495669:0';

-- Improve memory usage for versioned objects by freeing old versio (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9508254:1';

-- disable performance optimization for bug5504961 (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9547706:1';

-- store index filter selectivity/cost (event 0)
ALTER SESSION SET "_fix_control" = '9554026:0';

-- skip identity operator when generating NULL IS NOT NULL (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9569678:1';

-- Improve range join selectivity for predicates with round (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9577300:1';

-- Unpin older versioned object handles when creating a new version (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9578670:1';

-- enable functional indexes for index join (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9584723:1';

-- estimate selectivity for unique scan predicates (event 0)
ALTER SESSION SET "_fix_control" = '9593547:0';

-- fix typo in cost computation of subquery filters (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9593680:1';

-- allow peek on 2nd cursor if 1st cursor was a describe cursor (event 0)
ALTER SESSION SET "_fix_control" = '9630092:0';

-- cutoff of table count to disable interleaved CVM and JPPD (event 0)
ALTER SESSION SET "_fix_control" = '9659125:0';

-- Amend selectivity calculation for overlapping column ranges (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9668086:1';

-- Use kko_expcmo instead of expcmo in kkqr (ofe 11.2.0.3) (event 38049)
ALTER SESSION SET "_fix_control" = '9680430:1';

-- adjust for NULLs only once for NOT inlists (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9702850:1';

-- Use subquery costs in combined NO FILTERING with START WITH clau (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9716877:1';

-- don't go parallel if no operations are expensive enough (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9728438:1';

-- Don't use cross branch PQ for OR expanded plan (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9732434:1';

-- ignore missing in-memory metadata table in subquery pruning (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9748015:1';

-- fold bloom filter when offload to storage  (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9762592:3';

-- lift restriction : domain index indexonly mode for merged view (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9776736:1';

-- disallow slave group reuse in parallel query (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '9785632:1';

-- allow distinct aggregate transform with virtual cols (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9791810:1';

-- Sanity check when estimating range inner join (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9814067:1';

-- restriction on extended subquery partition pruning (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9829887:1';

-- disallow outer join oper (+) in CONNECT BY and START WITH clause (event 0)
ALTER SESSION SET "_fix_control" = '9832338:0';

-- rank predicates before costing (event 0)
ALTER SESSION SET "_fix_control" = '9833381:0';

-- do not set col count for OPNTPLS (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9841679:1';

-- Enable complex view merging if the order by has subquery (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9850461:1';

-- no first k rows in view under aggregate functions (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9881812:1';

-- use dynamic sampling for columns with wrong stats (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9898066:1';

-- Remove having clause subquery at all levels (ofe 11.2.0.2) (event 0)
ALTER SESSION SET "_fix_control" = '9912503:1';

-- do not rename OJ elimination query blocks after view merging (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9913117:1';

-- enhanced checks for ORDER BY DESC removal via join order (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9940732:1';

-- relax type matching for dates in transitive predicate generation (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9958518:1';

-- sanity check when estimating range inner join cardinality (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '9980661:1';

-- enable removal of group by in subquery for create table (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10004943:1';

-- do not use top level K rows if parent is a blocking operation (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10015652:1';

-- consistently use first or head piece scans for parallel scans (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '10026972:1';

-- Fix usage of transitive join predicate list in subquery pruning (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10038373:1';

-- clean stats if OJPPD rejected (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10041074:1';
-- costing of disjunctive subqueries (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10043801:1';

-- allow skip scan costing for PRIOR join in CONNECT BY query (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10080014:1';

-- send first row as early as possible for exists or not-exists que (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '10101489:1';

-- cardinality feedback should account for bloom filters (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10117760:1';

-- No selectivity for transitive inlist predicate from equijoin (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10134677:1';

-- constant predicate having empty string should be treated unknown (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10148457:1';

-- allow push into single table view, even if table is remote (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '10158107:1';

-- plan hash value ignores tables starting with SYS_TEMP (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10162430:1';

-- Limit on predicates in bind equiv context (raised to power of 2) (event 0)
ALTER SESSION SET "_fix_control" = '10182051:3';

-- consider parallel cost for partitioned local bitmap index access (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10192889:1';

-- better unusable index checking for reference partition pruning (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '10197666:1';

-- ignore OBY clumping for grand-total window functions (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10226906:1';

-- set gby cardinality 1 based on col=expr only if expr is constant (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10227392:1';

-- use range parallelism for window function count on a constant (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10230017:1';

-- join elimination is not sensitive to predicate order (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10232225:1';

-- support bind peeking at subpartition level in kkpapDIGetRange() (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10232623:1';

-- FKR: do not switch to Amode in presence of OBY/GBY and rownum (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10271790:1';

-- use larger round robin cnt & buffers for random local distributi (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10298302:1';

-- allow min/max optimization in presence of constant predicates (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10330090:1';

-- handle empty string with simplification of NVL (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10333395:1';

-- adjust density to data dictionary value on gathering statistics (event 0)
ALTER SESSION SET "_fix_control" = '10336499:0';

-- use heap sort in kkeOrderPredArr() (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10348427:1';

-- Virtual column replacement for connect by and ansi join queries (ofe 11.2.0.1) (event 0)
ALTER SESSION SET "_fix_control" = '10359631:1';

-- use actual partition count when pruning to more than one partiti (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10376744:1';

-- allow more OLAP tf view merging by disabling nnonfunc test (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10420220:1';

-- Skip index heuristic for JPPD in case of PBY (ofe 11.1.0.6) (event 0)
ALTER SESSION SET "_fix_control" = '10428278:1';

-- distinguish range and hash keys for clumping decisions (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '10428450:1';

-- adjust for the number of nulls when computing OR selectivity (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '10623119:1';

-- Do not recursively parse (reproduce plans) under slave SQL (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '10640430:1';

-- disable ACS checks after many executions (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11657468:1';

-- parallelize top-level union all if PDDL or PDML (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11668189:1';

-- compute avg col length for LONG RAW column (event 0)
ALTER SESSION SET "_fix_control" = '11676888:0';

-- fix selectivity of Table Lookup By NL view and dimensions (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11699884:1';

-- Enhance inline view merging security checks for PL/SQL functions (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11720178:1';

-- Fixed andp visit of qksopSetHighLogExp in kketac() (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11738631:1';

-- allow CBQT if all WITH views are inlined (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11740670:1';

-- support binds in ORDER BY sort elimination with OR expansion (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11741436:1';

-- skip SCG for query block with no aggregating columns (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11744086:1';

-- ref-part table transitive pruning (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11814265:1';

-- use union all view stats for colgroup cardinality sanity check (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11814428:1';

-- disallow HASH GROUP BY for subquery (in SELECT) processing (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11830663:1';

-- adjust NDV for list partition key column after pruning (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11834739:1';

-- null value is not accounted in NVL rewrite (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11843512:1';

-- no decrypt-to-encrypt for subquery column in GROUP BY and HAVING (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '11846314:1';

-- amend index cost compare with inlists as filters (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11853331:1';
-- use index filter inlists with extended statistics (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11876260:1';

-- conservatively allocate an ITL/distinct act txn for PDML (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11877160:1';

-- non top-level union is parallel if at least one branch is parall (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11881047:1';

-- do not reset column stats when table stats not yet loaded (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '11892888:1';

-- allow merging views with materialized query blocks (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '11935589:1';

-- use extended statistics for DISTINCT cardinality estimates (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12315002:1';

-- disable GBP for lateral oqb with disjunction (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12348584:1';

-- having subquery from any to single-row (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12352373:1';

-- update the index clustering factor (DS) if statistics do not exi (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12399886:1';

-- push predicate with NLS_SORT in window function (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12410972:1';

-- share PQ cursors for dbms_stats queries (ofe 8.0.0) (event 0)
ALTER SESSION SET "_fix_control" = '12432089:1';

-- Improve selectivity of predicates using CASE (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12432426:1';

-- disable index-only costing for row versions table (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12584007:1';

-- check inlist out-of-range values with extended statistics (ofe 11.2.0.3) (event 0)
ALTER SESSION SET "_fix_control" = '12591120:1';

/*************************************************************************************/

SPO OFF;
