SELECT /*+ BIND_AWARE */ COUNT(*) FROM
(SELECT * FROM sales WHERE cust_id > :b1 AND cust_id < :b2)
/
