REM Restores schema object stats for statement_id 61086 from local SQLT repository into data dictionary. Just execute "@sqlt_s61086_restore.sql" from sqlplus.
SPO sqlt_s61086_restore.log;
SET SERVEROUT ON;
TRUNCATE TABLE SQLTXPLAIN.SQLI$_STATTAB_TEMP;
ALTER SESSION SET optimizer_dynamic_sampling = 0;
ALTER SESSION SET EVENTS '10046 TRACE NAME CONTEXT FOREVER, LEVEL 12';
-- if you need to upload stats history so you can use SQLT XHUME you need to pass p_load_hist as Y
EXEC SQLTXADMIN.sqlt$a.import_cbo_stats(p_statement_id => 's61086', p_schema_owner => '&&tc_user.', p_include_bk => 'N', p_make_bk => 'N', p_load_hist => 'N');
ALTER SESSION SET SQL_TRACE = FALSE;
ALTER SESSION SET optimizer_dynamic_sampling = 2;
SET SERVEROUT OFF;
SPO OFF;
