-- @awr_r2_1_info.sql
-- @awr_r2_1_prompt.sql
@awr_r2_2_droptables.sql
@awr_r2_3_createmainr2tables-systemevent.sql
@awr_r2_4_createyaxis-aas.sql
@awr_r2_5_createxaxis-systemevent.sql
@awr_r2_6_populateanalyze.sql
@awr_r2_7_report-aas-systemevent.sql
