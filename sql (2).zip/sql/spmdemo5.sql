COL sql_handle NEW_V sql_handle
COL plan_name new_v plan_name
select sql_text, sql_handle, plan_name, enabled, accepted from dba_sql_plan_baselines where sql_text like '%BIND_AWARE%' and accepted = 'NO';

var report clob;
 
PAU

exec :report := dbms_spm.evolve_sql_plan_baseline('&sql_handle','&plan_name',verify => 'NO');

select sql_text, sql_handle, plan_name, enabled, accepted from dba_sql_plan_baselines where sql_text like '%BIND_AWARE%';
