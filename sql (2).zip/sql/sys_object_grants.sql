GRANT SELECT ON V_$SESSION TO CCF_ADMIN
/
GRANT SELECT ON V_$PARAMETER TO CCF_ADMIN
/
GRANT SELECT ON V_$DATABASE TO CCF_ADMIN
/
GRANT SELECT ON V_$TABLESPACE TO CCF_ADMIN
/
GRANT EXECUTE ON DBMS_LOCK TO CCF_ADMIN
/
GRANT EXECUTE ON DBMS_JOB TO CCF_BATCH, CCF_ADMIN
/
GRANT EXECUTE ON DBMS_IJOB TO CCF_USER, CCF_ADMIN, CCF_BATCH
/
GRANT EXECUTE ON DBMS_LOB TO CCF_USER, CCF_ADMIN, CCF_BATCH
/
GRANT EXECUTE ON DBMS_CRYPTO TO CCF_USER, CCF_ADMIN, CCF_BATCH
/
GRANT SELECT ON DBA_JOBS TO CCF_USER, CCF_BATCH, CCF_ADMIN
/
GRANT SELECT ON DBA_JOBS_RUNNING TO CCF_USER, CCF_ADMIN
/
GRANT SELECT ON V_$INSTANCE TO CCF_USER, CCF_ADMIN, CCF_BATCH
/ 
GRANT SELECT ON V_$MYSTAT TO CCF_USER, CCF_ADMIN, CCF_BATCH
/ 
GRANT SELECT ANY TRANSACTION TO CCF_ADMIN
/
GRANT SELECT ON DBA_ERRORS TO CCF_ADMIN, CCF_BATCH
/
GRANT SELECT ON USER_OBJECTS TO CCF_USER, CCF_ADMIN, CCF_BATCH
/
GRANT SELECT ON USER_SYNONYMS TO CCF_USER, CCF_ADMIN, CCF_BATCH
/
GRANT CREATE PROCEDURE TO CCF_ADMIN
/
GRANT CREATE ANY DIRECTORY TO CCF_ADMIN, CCF_INTERFACE, CCF_CUSTOMER, CCF_BATCH, CCF_USER 
/ 
GRANT DROP PUBLIC SYNONYM TO CCF_ADMIN
/
GRANT DROP PUBLIC DATABASE LINK TO CCF_ADMIN
/
GRANT CREATE JOB TO CCF_ADMIN
/
GRANT EXECUTE ON DBMS_RANDOM TO CCF_ADMIN
/
GRANT EXECUTE ON DBMS_UTILITY TO CCF_ADMIN
/
GRANT EXECUTE ON DBMS_LOGMNR TO CCF_ADMIN
/
GRANT CREATE MATERIALIZED VIEW TO CCF_ADMIN
/
GRANT ALTER SYSTEM TO CCF_ADMIN
/
begin
   dbms_network_acl_admin.create_acl (
   acl             => 'Ascade_Job_Access.xml',      -- Name of the access control list XML file
   description     => '',  -- Brief description
   principal       => 'CCF_ADMIN',               -- First user account or role being granted or denied permission
                                                 --   this is case sensitive,
                                                 --   but typically user names and roles are stored in upper-case letters
   is_grant        => TRUE,                      -- TRUE = granted, FALSE = denied
   privilege       => 'connect',                 -- connect or resolve, this setting is case sensitive,
                                                 --   so always enter it in lowercase
                                                 --    connect if user uses the UTL_TCP, UTL_HTTP, UTL_SMTP, and UTL_MAIL
                                                 --    resolve if user uses the UTL_INADDR
   start_date      => null,                      -- optional, null is the default
                                                 --   in format of timestamp_with_time_zone (YYYY-MM-DD HH:MI:SS.FF TZR)
                                                 --   for example, '2008-02-28 06:30:00.00 US/Pacific'
   end_date        => null                       -- optional, null is the default
   );
   commit;
exception when others then
   if SQLCODE = -31003 OR SQLCODE = -46212 then
   -- the acl already exists
      null;
   else
      raise;
   end if;   
end;
/
begin
	dbms_network_acl_admin.assign_acl (
	acl           => 'Ascade_Job_Access.xml', -- Name of the access control list XML file to be modified
	host          => '*',                   -- Network host to which this access control list will be assigned
														 -- This a host name or IP address or wild card name
	lower_port    => null,                  -- (optional)
	upper_port    => null);                 -- (optional)
	commit;
end;
/
begin
	-- really ensure that ccf_admin gets connect grant
   DBMS_NETWORK_ACL_ADMIN.ADD_PRIVILEGE('Ascade_Job_Access.xml', 'CCF_ADMIN', true, 'connect');	
	commit;
end;
/
-- Make sure we only gather automatic statistics for DB entities owned by ORACLE. We do custom statistics for our own entities.
BEGIN
  dbms_auto_task_admin.enable('auto optimizer stats collection', operation => NULL, window_name => NULL);
  dbms_stats.set_param('AUTOSTATS_TARGET', 'ORACLE');
END;
/
EXIT;
/
