
COL sql_handle NEW_V sql_handle;
select sql_text, sql_handle, plan_name, enabled, accepted from dba_sql_plan_baselines where sql_text like '%BIND_AWARE%';


var dropped_plans number;

exec :dropped_plans := dbms_spm.drop_sql_plan_baseline('&&sql_handle');

print dropped_plans
