SELECT /* spmbinds1 */ COUNT(*) FROM
(
SELECT * FROM sales WHERE channel_id = :b1
UNION
SELECT * FROM sales WHERE promo_id = :b2
)
/
