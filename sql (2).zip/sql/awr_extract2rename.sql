def _client="&1"

set feedback off term off head on und off trimspool on echo off lines 4000 colsep ','

spool top_events-all.csv
select INSTNAME, DB_ID, HOSTNAME, SNAP_ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, EVENT, EVENT_RANK, WAITS, TIME, AVGWT, PCTDBT, AAS, WAIT_CLASS
from awr_topevents_&_client
order by snap_id;
spool off
host sed -n -i '2,$ p' top_events-all.csv

spool cpuwl-all.csv
select INSTNAME, DB_ID, HOSTNAME, ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, CPU, CAP, DBT, DBC, BGC, RMAN, AAS, TOTORA, LOAD, TOTOS, ORACPUPCT , RMANCPUPCT, OSCPUPCT, OSCPUUSR, OSCPUSYS, OSCPUIO
from awr_cpuwl_&_client
order by id asc;
spool off
host sed -n -i '2,$ p' cpuwl-all.csv

spool sysstat-all.csv
select INSTNAME, DB_ID, HOSTNAME, ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, MEMGB, SGAGB, PGAGB, LOGONS, EXS, UCS, UCOMS, URS, LIOS
from awr_sysstat_&_client
order by id asc;
spool off
host sed -n -i '2,$ p' sysstat-all.csv

spool topsqlx-all.csv
select INSTNAME, DB_ID, HOSTNAME, SNAP_ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, AAS, ELAP, ELAPEXEC, CPUT, IOWAIT, APPWAIT, CONCURWAIT, CLWAIT, BGET, DSKR, DPATH, ROWP, EXEC, PRSC, PXEXEC, ICBYTES, OFFLOADBYTES, OFFLOADRETURNBYTES, FLASHCACHEREADS, UNCOMPBYTES, TIME_RANK, SQL_ID, PHV, MODULE, SQL_TEXT
from awr_topsqlx_&_client
order by snap_id asc;
spool off
host sed -n -i '2,$ p' topsqlx-all.csv

spool iowl-all.csv
select INSTNAME, DB_ID, HOSTNAME, ID, TO_CHAR(TM,'MM/DD/YY HH24:MI:SS') TM, INST, DUR, SIORS, MIORS, TIORMBS, SIOWS, MIOWS, TIOWMBS, IOREDO, REDOSIZESEC, FLASHCACHE, CELLPIOB, CELLPIOBSS, CELLPIOBPREOFF, CELLPIOBSI, CELLIOUNCOMB, CELLPIOBS, CELLPIOBSRMAN
from awr_iowl_&_client
order by id asc;
spool off
host sed -n -i '2,$ p' iowl-all.csv



