-- run_all.sql
-- Karl Arao, Oracle ACE (bit.ly/karlarao), OCP-DBA, RHCE
-- http://karlarao.wordpress.com
--

@run_awr_topevents.sql
@run_awr_sysstat.sql
@run_awr_sgapga.sql
@run_awr_cpuwl.sql
@run_awr_iowl.sql
@run_awr_storagesize.sql
@run_awr_services.sql
@run_awr_topsql.sql

exit


